﻿using irm_backend.Models;
using irm_backend.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace irm_backend.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]

    public class CustomerController : ControllerBase
    {
        #region
        private readonly ICustomer Service;

        public CustomerController(ICustomer _Service)
        {
            Service = _Service;

        }
        #endregion
        [HttpPost]
        [ActionName("addComplaint")]
        public IActionResult addComplaint([FromForm] customerModel customer,IFormFile file)
        {
            DataTable dt = Service.addComplaint(customer,file);
            if (dt == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        [HttpPost]
        [ActionName("viewComplaint")]
        public IActionResult viewComplaint(customerModel customer)
        {
            DataTable dt=Service.viewComplaint(customer);
            if (dt == null)
            {
                return StatusCode(500, "Contact the Admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Cannot post your complaint, something went wrong");
            }
        }

        [HttpPost]
        [ActionName("listComplaint")]
        public IActionResult listComplaint(customerModel customer)
        {
            DataTable dt = Service.listComplaint(customer);
            if (dt==null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count>0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot list complaint");
            }
        }
        [HttpPost]
        [ActionName("recentListComplaint")]
        public IActionResult recentListComplaint(customerModel customer)
        {
            DataTable dt = Service.recentListComplaint(customer);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot show recent complaints");
            }
        }

        [HttpPost]
        [ActionName("updateComplaint")]
        public IActionResult updateComplaint(customerModel customer)
        {
            DataTable dt = Service.updateComplaint(customer);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot update complaints");
            }
        }

    }
}
