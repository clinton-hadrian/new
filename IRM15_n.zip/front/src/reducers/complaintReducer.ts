import {
  USER_LOGIN_SUCCESS,
  USER_LOGIN_REQUEST,
  USER_LOGIN_FAILED,
  USER_LOGIN_RESET,
} from "../constants/userConstant";
import { AnyAction } from "@reduxjs/toolkit";

export const userLoginReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case USER_LOGIN_REQUEST:
      return { loading: true };

    case USER_LOGIN_SUCCESS:
      return { loading: false, response: action.payload };

    case USER_LOGIN_FAILED:
      return { loading: false, error: action.payload };

    case USER_LOGIN_RESET:
      return {};

    default:
      return state;
  }
};
