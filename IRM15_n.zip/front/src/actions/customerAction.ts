import axios from "axios";
import {
  ADD_COMPLAINT_FAILED,
  ADD_COMPLAINT_REQUEST,
  ADD_COMPLAINT_SUCCESS,
  LIST_COMPLAINT_FAILED,
  LIST_COMPLAINT_REQUEST,
  LIST_COMPLAINT_SUCCESS,
  RECENT_LIST_COMPLAINT_FAILED,
  RECENT_LIST_COMPLAINT_REQUEST,
  RECENT_LIST_COMPLAINT_SUCCESS,
  UPDATE_COMPLAINT_FAILED,
  UPDATE_COMPLAINT_REQUEST,
  UPDATE_COMPLAINT_SUCCESS,
  VIEW_COMPLAINT_FAILED,
  VIEW_COMPLAINT_SUCCESS,
} from "../constants/customerConstant";
import { API } from "../data";

export const addComplaintAction = (formData: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: ADD_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(`${API}/Customer/addComplaint`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    dispatch({
      type: ADD_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: ADD_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const listComplaintAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: LIST_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(`${API}/Customer/listComplaint`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    dispatch({
      type: LIST_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: LIST_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const recentListComplaintAction =
  (form: any) => async (dispatch: any) => {
    try {
      dispatch({
        type: RECENT_LIST_COMPLAINT_REQUEST,
      });

      const { data } = await axios.post(
        `${API}/Customer/recentListComplaint`,
        form,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      dispatch({
        type: RECENT_LIST_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: RECENT_LIST_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const viewComplaintAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: UPDATE_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(`${API}/Customer/viewComplaint`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    dispatch({
      type: VIEW_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: VIEW_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const updateComplaintAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: UPDATE_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(`${API}/Customer/updateComplaint`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    dispatch({
      type: UPDATE_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: UPDATE_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};
