import { Alert } from "@mui/material";
import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import Fade from '@mui/material/Fade';
import Slide, { SlideProps } from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';

function SlideTransition(props: SlideProps) {
  return <Slide {...props} direction="down" />;
}

const SnackBar = (props: any) => {

  return (
    <Snackbar
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      style={{ width: "25%" }}
      TransitionComponent={SlideTransition}
      onClose={props.handleClose}
      autoHideDuration={5000}
      open={props.open}>
      <Alert sx={{ width: '100%' }}  style={{ width: "100%" }} severity={props.severity}>{props.message}</Alert>
    </Snackbar>
  );
};

export default SnackBar;
