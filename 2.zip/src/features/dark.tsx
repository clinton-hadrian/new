import { createSlice } from "@reduxjs/toolkit";

import React from "react";

const darkSlice = createSlice({
  name: "darkTheme",
  initialState: { value: "" },
  reducers: {
    changeTheme: (state, action) => {
      state.value = action.payload;
    },
  },
});

export const { changeTheme } = darkSlice.actions;
export default darkSlice.reducer;
