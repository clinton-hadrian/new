import React from 'react'

const userLayout = () => {
  return (
    <div>userLayout</div>
  )
}

export default userLayout