import axios from "axios"
import { ADD_COMPLAINT_REQUEST } from "../constants/customerConstant"
import { API } from "../data"


export const addComplaintAction=(form:any)=> async(dispatch:any)=>{

    try{
        dispatch({
            type:ADD_COMPLAINT_REQUEST
        })

        const {data}=await axios(`${API}/`)
    }

}