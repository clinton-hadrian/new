﻿using irm_backend.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Interfaces
{
    interface ICustomer
    {
        DataTable addComplaint (customerModel customer);
        DataTable viewComplaint (customerModel customer);
        DataTable updateComplaint(customerModel customer);
        DataTable listComplaint(customerModel customer);
    }
}
