﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Models
{
    public class customerModel
    {
        public string investorName {get;set;}
        public string companyName { get; set; }
        public string folioDemat { get; set; }
        public string queryType { get; set; }
        public string query { get; set; }
        public string problemStatement { get; set; }
        public byte[] mediaDocument { get; set; }
    }
}
