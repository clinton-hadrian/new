import {
  Grid,
  TextField,
  Typography,
  Radio,
  Autocomplete,
  Input,
} from "@mui/material";
// import Autocomplete from "@mui/material/Autocomplete";
// import Autocomplete from "@material-ui/lab/Autocomplete";
import Fab from "@mui/material/Fab";
import { ErrorMessage, useFormik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import * as Yup from "yup";

import AddIcon from "@mui/icons-material/Add";
import InputLabel from "@mui/material/InputLabel";
import Button from "@mui/material/Button";
import AttachmentRoundedIcon from "@mui/icons-material/AttachmentRounded";
import Tooltip from "@mui/material/Tooltip";
import FormLabel from "@mui/material/FormLabel";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { RadioRounded } from "@mui/icons-material";
import { Dispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from "react-redux";
import { addComplaintAction } from "../actions/customerAction";
import pdf from "../images/pdf-file.png"

// const folioValidation = Yup.string()
//   .required("Folio or Demat account number is required")
//   .matches(/^[0-9]{8}$/, "Folio must be 8 digits")

// const demantValidation = Yup.string()
//   .required("Folio or Demat account number is required")
//   .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")

// const folioOrDematValidation = Yup.mixed().oneOf(
//   [folioValidation, demantValidation],
//   "Invalid Folio or Demat number"
// );

const supportedFormats = ["png", "jpeg", "pdf", "jpg"];
const supportSize = 1000000;

interface props {
  customerName: string;
}

// let files: File[] = [];

const AddComplaint: React.FC<props> = (props) => {
  const dispatch: Dispatch<any> = useDispatch();
  const sendMobileOTPSelector = useSelector(
    (state: any) => state.sendMobileOTP
  );

  

  const addProfileSelector = useSelector((state: any) => state.addProfile);

  const [fileName, setFileName] = useState("");

  const [images, setImages] = useState<JSX.Element[]>([]);

  const [files, setFiles] = useState<File[]>([]);

  const delImage = (index: number) => {
    // Remove the file at the given index and create a new array with the remaining files
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
    showImages(newFiles);
    const newFileNames = newFiles.map((file) => file.name).join(", ");
    setFileName(newFileNames);
    // const deletedFile = files[index];
    // setFileName(prevFileName => {
    //   const fileNameArr = prevFileName.split(", ");
    //   const fileIndex = fileNameArr.indexOf(deletedFile.name);
    //   if (fileIndex !== -1) {
    //     fileNameArr.splice(fileIndex, 1);
    //     return fileNameArr.join(", ");
    //   } else {
    //     return prevFileName;
    //   }
    // });
 
  };
 
  const showImages = (files: File[]) => {
    const imageElements = files.map((file, index) => (
      <div className="image" key={file.name}>
         {file.type === "application/pdf" ? (
        <img src={pdf} alt="PDF" />
      ) : (
        <img src={URL.createObjectURL(file)} alt={file.name} />
      )}
      <span onClick={() => delImage(index)}>×</span>
      </div>
    ));
    setImages(imageElements);
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const complaintFormik = useFormik({
    initialValues: {
      investorName: "",
      companyName: "",
      folioDemat: "",
      queryType: "single query",
      query: "",
      problemStatement: "",
      mediaDocument: "",
    },

    validationSchema: Yup.object().shape({
      investorName: Yup.string()
        .required("Investor name is required")
        .matches(/^[a-zA-Z]+$/, "Name should not contain numbers"),

      companyName: Yup.string().required("Company name is required"),

      folioDemat: Yup.string().test(
        "len",
        "Invalid Folio or Demat account number",
        (val: string | undefined) =>
          val ? val.length === 8 || val.length === 16 : false
      ),
      problemStatement: Yup.string().required("Problem statement is required"),

      // query: Yup.string().required("query field is required"),

      // mediaDocument: Yup.mixed()
      //   .required("File is required")
      //   .test(
      //     "file-size",
      //     "File should be 1MB or lower",
      //     (values) => values && values.size <= supportSize
      //   )
      //   .test(
      //     "test-format",
      //     "Files should be PNG, JPEG, PDF",
      //     (values) =>
      //       values && supportedFormats.includes(values.type.split("/")[1])
      //   ),
    }),

    onSubmit: (value) => {
      const formData = new FormData();
      formData.append(
        "customerId",
        sendMobileOTPSelector.response &&
          sendMobileOTPSelector.response[0]["ID"]
          ? sendMobileOTPSelector.response[0]["ID"]
          : addProfileSelector.response && addProfileSelector.response[0]["ID"]
      );
      formData.append("investorName", value.investorName);
      formData.append("companyName", value.companyName);
      formData.append("folioDemat", value.folioDemat);
      formData.append("queryType", value.queryType);
      formData.append("problemStatement", value.problemStatement);
      files.forEach((file)=>formData.append("file",file))
      console.log(files);
      dispatch(addComplaintAction(formData));
    },
  });

  const { customerName } = props;

  const [inputValue, setInputValue] = React.useState("");
  const [selectedOption, setSelectedOption] = React.useState<{
    label: string;
    id: number;
  } | null>(null);

  return (
    <div>
      <Grid container spacing={3} sx={{ p: 0 }}>
        <Grid item xs={12}>
          <Typography
            variant="h3"
            style={{
              fontFamily: "Inter",
              fontWeight: "bold",
              fontSize: "1.8rem",
            }}
            gutterBottom
          >
            Hi, {customerName}. We are here to assist you !
            <Typography
              gutterBottom
              variant="h4"
              style={{
                fontFamily: "Inter",
                fontWeight: "300",
                fontSize: "1rem",
                marginTop: 5,
              }}
            >
              Please complete the form below for your complaints
            </Typography>
          </Typography>
        </Grid>
        <Grid item xs={12} md={12}>
          <TextField
            type="text"
            value={complaintFormik.values.investorName}
            name="investorName"
            onBlur={complaintFormik.handleBlur}
            label="Investor Name"
            onChange={complaintFormik.handleChange}
            placeholder="Enter Investor Name"
            fullWidth
            error={Boolean(
              complaintFormik.touched.investorName &&
                complaintFormik.errors.investorName
            )}
            helperText={
              complaintFormik.touched.investorName &&
              complaintFormik.errors.investorName
            }
          />
        </Grid>
        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.companyName &&
                complaintFormik.errors.companyName
            )}
            id="company-login"
            type="text"
            value={complaintFormik.values.companyName}
            name="companyName"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter Company Name"
            helperText={
              complaintFormik.touched.companyName &&
              complaintFormik.errors.companyName
            }
            label="Company on which shares held"
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.folioDemat &&
                complaintFormik.errors.folioDemat
            )}
            id="folio-login"
            type="numeric"
            value={complaintFormik.values.folioDemat}
            name="folioDemat"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter Folio No / Demat ACC No"
            helperText={
              complaintFormik.touched.folioDemat &&
              complaintFormik.errors.folioDemat
            }
            label="Folio Number (or) Demat Account Number"
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <FormLabel>Your Selection Type ?</FormLabel>
          <RadioGroup
            row
            name="queryType"
            value={complaintFormik.values.queryType}
            onChange={complaintFormik.handleChange}
          >
            <FormControlLabel
              value="single query"
              control={<Radio />}
              label="Single Query"
            />
            <FormControlLabel
              value="multiple query"
              control={<Radio />}
              label="Multiple Query"
            />
          </RadioGroup>
        </Grid>

        <Grid item xs={12} md={12}>
          <Autocomplete
            options={queries}
            getOptionLabel={(option) => option.label}
            value={selectedOption}
            onChange={(event, newValue) => {
              setSelectedOption(newValue);
              complaintFormik.setFieldValue("query", newValue?.label);
            }}
            isOptionEqualToValue={(option, value) =>
              option.label === value.label
            }
            inputValue={inputValue}
            onInputChange={(event, newInputValue) => {
              setInputValue(newInputValue);
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                name="query"
                value={complaintFormik.values.query}
                label="Queries"
                variant="outlined"
                fullWidth
              />
            )}
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.problemStatement &&
                complaintFormik.errors.problemStatement
            )}
            id="conteproblemStatementnt"
            type="text"
            value={complaintFormik.values.problemStatement}
            name="problemStatement"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter your Problem Statement here"
            helperText={
              complaintFormik.touched.problemStatement &&
              complaintFormik.errors.problemStatement
            }
            label="Problem Statement"
            multiline
            rows={4}
          />
        </Grid>

        <Grid item xs={12}>
          <InputLabel htmlFor="upload-photo" />
          <TextField
          inputProps={{multiple:true}} 
            className="inputField"
            style={{ display: "none" }}
            id="upload-photo"
            name="mediaDocument"
            type="file"
            inputRef={fileInputRef}
            onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
              const mediaDocument = event.target.files?.[0];
              if (mediaDocument) {
                 
                complaintFormik.handleChange({
                  target: {
                    name: "mediaDocument",
                    value: event.target.files,
                  },
                });
              }
              const selectedFiles = event.target.files;
              if (selectedFiles) {
                // Update the files array using the state updater function to add new files
                setFiles(prevFiles => [...prevFiles, ...Array.from(selectedFiles)]);
              //   const selectedFileNames = Array.from(selectedFiles)
              //   .map((file) => file.name)
              //   .join(", ");
              // setFileName(selectedFileNames);
              setFileName(prevFileName => prevFileName + ", " + Array.from(selectedFiles).map(file => file.name).join(", "));

                showImages([...files, ...Array.from(selectedFiles)]);
              }}}
            // value={complaintFormik.values.mediaDocument}
            // error={Boolean(
            //   complaintFormik.touched.mediaDocument &&
            //     complaintFormik.errors.mediaDocument
            // )}
            // helperText={
            //   complaintFormik.touched.mediaDocument &&
            //   complaintFormik.errors.mediaDocument
            // }
          />

          <Tooltip title="Attachment" placement="right">
            <Fab
              id="custom-button"
              color="primary"
              size="small"
              component="span"
              aria-label="add"
              variant="extended"
              sx={{ borderRadius: "50%" }}
              onClick={() => {
                fileInputRef.current?.click();
              }}
            >
              <AttachmentRoundedIcon />
            </Fab>
          </Tooltip>
          <span style={{ marginLeft: "1.5rem" }} id="custom-text">
            {fileName}
          </span>
          <div className="img-container">{images}</div>
        </Grid>

        <Grid item xs={12} md={12}>
          <Button
            disableElevation
            // disabled={isSubmitting}
            size="large"
            type="submit"
            variant="contained"
            color="primary"
            sx={{ borderRadius: "15px" }}
            onClick={() => {
              complaintFormik.handleSubmit();
            }}
            fullWidth
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </div>
  );
};

const queries = [
  { label: "Updation of Change of address", id: 1 },
  { label: "Updation  of KYC", id: 2 },
  { label: "Share certificate Lost", id: 3 },
  { label: "Shareholder/s deceased", id: 4 },
  { label: "IEPF Claim", id: 5 },
  { label: "Status of documents submitted", id: 6 },
  { label: "Name Change/ Correction", id: 7 },
  { label: "Non-receipt of New certificate (company name change)", id: 8 },
  { label: "Non-receipt of stickers  (company name change)", id: 9 },
  { label: "Non-receipt of Dividends", id: 10 },
  { label: "Non-receipt of Demat Rejected Documents", id: 11 },
  { label: "Status of demat request", id: 12 },
  { label: "Non-receipt of Rights shares", id: 13 },
  { label: "Status of IPO allotment", id: 14 },
  { label: "Status of shares", id: 15 },
  { label: "Non-receipt of annual report", id: 16 },
];

export default AddComplaint;

// customerId:
//   sendMobileOTPSelector.response &&
//   sendMobileOTPSelector.response[0]["ID"]
//     ? sendMobileOTPSelector.response[0]["ID"]
//     : addProfileSelector.response &&
//       addProfileSelector.response[0]["ID"],
// investorName: value.investorName,
// companyName: value.companyName,
// folioDemat: value.folioDemat,
// queryType: value.queryType,
// query: value.query,
// problemStatement: value.problemStatement,
// fileName: fileName,
// mediaDocument: value.mediaDocument,
