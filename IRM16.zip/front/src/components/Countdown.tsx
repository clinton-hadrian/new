import React, { useState, useEffect } from 'react';
import {Typography ,Box} from "@mui/material";

const Countdown = () => {
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [text,setText]=useState("Code will expire in")
  const [isCountdownActive, setIsCountdownActive] = useState(true);
  let intervalId: number | undefined;

  useEffect(() => {
    if (isCountdownActive) {
      intervalId = window.setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            setText("Code has expired");
            clearInterval(intervalId);
            setIsCountdownActive(false);
            return;
          }
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
       
      }
    };
  }, [minutes, seconds, isCountdownActive]);

  return (
    <>
   <Box
        component="div"
        sx={{
          display: "flex",
          direction: "row",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
          width: "20rem",
          height: 30,
        }}
      >
        <Box
          component="div"
          sx={{
            // backgroundColor: "#2C74B3",
            borderBottom: "50px solid #0A2647",
            borderLeft: "25px solid transparent",
            borderRight: "25px solid transparent",
            height: 0,
            // width: "250%",
            position: "absolute",
            // top: 10,
            bottom: -33,
            color: "#fff",
          }}
        >
          <Typography
            variant="h6"
            sx={{ fontFamily: "inter", fontWeight: "400", mt: 1,mx:1 }}
          >
            {text} {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
          </Typography>
          {/* <div></div> */}
        </Box>
      </Box>
    </>
    
  );
};

export default Countdown;