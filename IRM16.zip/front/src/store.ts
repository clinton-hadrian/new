import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { addProfileReducer, resendOTPReducer } from "./reducers/authReducer";
import {
  sendMobileOTPReducer,
  verifyMobileOTPReducer,
  getProfileReducer
} from "./reducers/authReducer";
import { userLoginReducer } from "./reducers/complaintReducer";
import {
  addComplaintReducer,
  listComplaintReducer,
  recentListComplaintReducer,
  updateComplaintReducer,
  viewComplaintReducer,
} from "./reducers/customerReducer";
import { changeThemeReducer } from "./reducers/themeReducer";

const rootReducer = combineReducers({
  theme: changeThemeReducer,
  sendMobileOTP: sendMobileOTPReducer,
  resendOTP:resendOTPReducer,
  userLogin: userLoginReducer,
  addProfile: addProfileReducer,
  getProfile: getProfileReducer,
  verifyMobileOTP: verifyMobileOTPReducer,
  addComplaint: addComplaintReducer,
  viewComplaint: viewComplaintReducer,
  listComplaint: listComplaintReducer,
  recentListComplaint: recentListComplaintReducer,
  updateComplaint: updateComplaintReducer,

});

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
});

// const themeValue = localStorage.getItem("theme")
//   ? localStorage.getItem("theme")
//   : "light";
// const initialReducer = {
//   theme: { mode: themeValue },
// };

export default store;
