﻿using irm_backend.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Interfaces
{
    public interface IAuth
    {
        DataTable sendMobileOTP(sendMobileOTPModel sendMobileOTP);
        DataTable resendOTP(sendMobileOTPModel sendMobileOTP);
        DataTable OTPVerification(sendMobileOTPModel sendMobileOTP);
        DataTable addProfile(sendMobileOTPModel sendMobileOTP);
        DataTable getProfile(sendMobileOTPModel sendMobileOTP);
        
    }
}
