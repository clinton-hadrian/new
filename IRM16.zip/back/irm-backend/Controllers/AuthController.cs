﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        #region
        private readonly IAuth Service;

        public AuthController(IAuth _Service)
        {
            Service = _Service;

        }
        #endregion
        [HttpPost]
        [ActionName("sendMobileOTP")]
        public IActionResult sendMobileOTP([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable table = Service.sendMobileOTP(sendMobileOTP);
            if (table == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (table.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(table));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        [HttpPost]
        [ActionName("resendOTP")]
        public IActionResult resendOTP([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable table = Service.resendOTP(sendMobileOTP);
            if (table == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (table.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(table));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        [HttpPost]
        [ActionName("OTPVerification")]

        public IActionResult OTPVerification([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable dt = Service.OTPVerification(sendMobileOTP);
            if (dt == null)
            {
                return StatusCode(500, "Contact the Admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));

            }
            else
            {
                return StatusCode(404, "Please enter correct OTP");
            }
        }

        [HttpPost]
        [ActionName("addProfile")]

        public IActionResult addProfile([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable dt = Service.addProfile(sendMobileOTP);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Please Enter Valid Name and Email");
            }

        }

        [HttpPost]
        [ActionName("getProfile")]

        public IActionResult getProfile([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable dt = Service.getProfile(sendMobileOTP);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Please Enter Valid Name and Email");
            }

        }

    }
}
