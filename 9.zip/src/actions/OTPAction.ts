import axios from "axios";
import { OTP_FAILED, OTP_REQUEST, OTP_SUCCESS } from "../constants/OTPConstant";
import { API } from "../data";

export const OTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: OTP_REQUEST,
    });

    const { data } = await axios.post(`${API}/Auth/OTPVerification`, form, {
      headers: { "Content-Type": "application/json" },
    });

    dispatch({
      type: OTP_SUCCESS,
      payload: data,
    });

    sessionStorage.setItem("isLoggedIn", "true");
  } catch (error: any) {
    dispatch({
      type: OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};
