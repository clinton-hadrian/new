import  axios  from "axios"
import { USER_LOGIN_FAILED, USER_LOGIN_REQUEST, USER_LOGIN_SUCCESS } from "../constants/userLogin"
import { API } from "../data"


export const userLoginAction=(form:any)=>async(dispatch:any)=>{
    try{

        dispatch({
            type:USER_LOGIN_REQUEST,
        })

        const {data} = await axios.post(`${API}/Auth/userLogin`,
        {form},
        {
            headers:{"content-type":"application-json"}
        }
        )

        dispatch({
            type:USER_LOGIN_SUCCESS,
            payload:data
        })
        
    }
    catch(error){
        dispatch({
            type:USER_LOGIN_FAILED,
            payload:error
        })
    }
}