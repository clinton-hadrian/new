import { Alert, Typography } from "@mui/material";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert, { AlertProps } from "@mui/material/Alert";

const SnackBar = (props: any) => {
  return (
    <Snackbar
      anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
      onClose={props.handleClose}
      autoHideDuration={3000}
      open={props.open}>
      <Alert severity={props.severity}>{props.message}</Alert>
    </Snackbar>
  );
};

export default SnackBar;
