import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { sendMobileOTPReducer } from "./reducers/authReducer";
import { userLoginReducer } from "./reducers/complaintReducer";
import { OTPReducer } from "./reducers/OTPReducer";
//import darkReducer from "./reducers/dark";
import { changeThemeReducer } from "./reducers/themeReducer";
import { persistStore, persistCombineReducers } from "redux-persist";
import storage from "redux-persist/lib/storage";

const persistConfig = {
  key: "root",
  storage,
};

const rootReducer = persistCombineReducers(persistConfig, {
  theme: changeThemeReducer,
  sendMobileOTP: sendMobileOTPReducer,
  userLogin: userLoginReducer,
  OTP: OTPReducer,
});

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
});

export const persistor = persistStore(store);

const themeValue = localStorage.getItem("theme")
  ? localStorage.getItem("theme")
  : "light";
const initialReducer = {
  theme: { mode: themeValue },
};

export default store;
