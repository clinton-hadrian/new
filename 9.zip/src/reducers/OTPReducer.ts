import { AirTwoTone } from "@mui/icons-material";
import { AnyAction } from "@reduxjs/toolkit";
import { LOGOUT, OTP_FAILED, OTP_REQUEST, OTP_SUCCESS } from "../constants/OTPConstant";
import { persistStore, persistReducer } from 'redux-persist';
import sessionStorage from 'redux-persist/lib/storage/session';

const persistConfig = {
    key: 'OTP',
    storage: sessionStorage,
    whitelist: ['isLoggedIn']
  };

export const OTPReducer = persistReducer(persistConfig, (state = {isLoggedIn:false}, action: AnyAction) => {

  switch (action.type) {
    case OTP_REQUEST:
      return { loading: true };
    case OTP_SUCCESS:
      return { loading: false, response: action.payload,  isLoggedIn: true, };
      case LOGOUT:
        return {loading:false, response:action.payload, isLoggedIn:false}
    case OTP_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
});
