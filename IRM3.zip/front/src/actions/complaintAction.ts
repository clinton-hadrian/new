import React from 'react'

const complaintAction = () => {
  return (
   complaintAction
  )
}

export default complaintAction