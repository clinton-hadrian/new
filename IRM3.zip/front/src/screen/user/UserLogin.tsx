import React, { Fragment, useState } from "react";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import VpnKeyIcon from "@mui/icons-material/VpnKey";
import {
  Button,
  Box,
  Typography,
  CardContent,
  TextField,
  Paper,
  Grid,
  InputAdornment,
} from "@mui/material";

import * as Yup from "yup";
import phone from "yup-phone";
import { ErrorMessage, useFormik } from "formik";
import IconButton from "@mui/material/IconButton";
import {
  Email,
  LockOpen,
  Visibility,
  VisibilityOff,
  ArrowForward,
} from "@mui/icons-material";

interface props {
  email: string;
  password: string;
}

const otpBorder = {
  width: "20%",
  margin: "0 5px",
  borderRadius: "15px",
  borderColor: "#a084dc",
  borderStyle: "solid",
  borderWidth: "2px",
  max: "9",
  min: "0",
  textAlign: "center",
};

const UserLogin = () => {
  const [otpVisible, setOTPVisible] = useState<Boolean>(false);
  const [otpError, setOTPError] = useState<string>("");
  const [numberAndEmail, setNumberAndEmail] = useState<props>({
    email: "",
    password: "",
  });

  const userFormik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: Yup.object().shape({
      email: Yup.string()
        .required("Please enter the email number")
        .email("Invalid email address"),
      // password:Yup.string()
      // .min(8, 'Password must be at least 8 characters long')
      // .max(255, 'Password must be less than 255 characters')
      // .matches(/^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9])(?=.*[a-z]).{8,}$/, 'Must contain 1 uppercase, 1 special, 1 lowercase and 1 digit')
      // .required('Password is required'),
      password: Yup.string().required("Password Required"),
    }),
    onSubmit: (value) => {
      console.log(value);
    },
  });

  return (
    <Fragment>
      <Paper
        style={{
          borderRadius: "20px",
          borderColor: "black",
          borderStyle: "Solid",
          borderWidth: "2px",
        }}
        elevation={20}
        sx={{ p: 2 }}>
        <CardContent sx={{ textAlign: "center" }}>
          <Box
            sx={{
              "& MuiButtonBase-root ": {
                margin: 1,
                width: "100%",
                position: "relative",
              },
              "& .MuiTypography-root ": {
                textAlign: "left",
                mb: 4,
              },
              position: "relative",
            }}>
            <Typography
              style={{
                fontFamily: "Inter",
                fontSize: "1.8rem",
                fontWeight: "bold",
              }}
              variant="h4"
              gutterBottom>
              Welcome back..
              <Typography
                style={{
                  fontFamily: "Inter",
                  fontSize: "1rem",
                  fontWeight: 300,
                  marginTop: 5,
                }}
                variant="h1"
                gutterBottom>
                Please enter you email and password
              </Typography>
            </Typography>
            <TextField
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Email />
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 2 }}
              id="email"
              label="Email"
              placeholder="Enter Email"
              name="email"
              value={userFormik.values.email}
              onChange={(e) => {
                userFormik.setFieldValue("email", e.target.value);
              }}
              onBlur={userFormik.handleBlur}
              error={Boolean(
                userFormik.errors.email && userFormik.touched.email
              )}
              helperText={userFormik.touched.email && userFormik.errors.email}
              fullWidth
            />

            <TextField
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockOpen />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment onClick={() => {}} position="end">
                    <Visibility />
                  </InputAdornment>
                ),
              }}
              id="password"
              type="password"
              value={userFormik.values.password}
              name="password"
              onBlur={userFormik.handleBlur}
              onChange={(e) => {
                userFormik.setFieldValue("password", e.target.value);
              }}
              placeholder="Enter password"
              fullWidth
              error={Boolean(
                userFormik.touched.password && userFormik.errors.password
              )}
              helperText={
                userFormik.touched.password && userFormik.errors.password
              }
              label="Password"
            />
             <Grid container>
              <Grid item xs={6}  md={6}>
              <Box
              sx={{
                justifyContent: "left",
                alignItems: "start",
                alignContent: "start",
                textAlign: "start ",
                mt: 3,
              }}>
              
                  
                <Button variant="text">Forgot password?</Button>
             
             
            </Box>

              </Grid>
              <Grid item xs={6} md={6}>
              <Box
              sx={{
                justifyContent: "right",
                alignItems: "end",
                alignContent: "end",
                textAlign: "end ",
                mt: 2,
              }}>
              <Button
               
                sx={{
                  borderRadius: "25px",
                }}
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {}}
                endIcon={<ArrowForward />}>
                  
                Login
             
              </Button>
            </Box>

              </Grid>
             </Grid>
           
          </Box>
        </CardContent>
      </Paper>
    </Fragment>
  );
};
export default UserLogin;
