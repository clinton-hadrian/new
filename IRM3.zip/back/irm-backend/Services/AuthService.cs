﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class AuthService : IAuth
    {
        private readonly string _connectionString;
        SendSMS SendSMS=new SendSMS();
        public AuthService(IConfiguration _configuration)
        {
            _connectionString = _configuration.GetConnectionString("crestCon");

        }

        public DataTable sendMobileOTP(sendMobileOTPModel sendMobileOTP)
        {
           
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        var otp = new Random().Next(100000, 999999).ToString();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = sendMobileOTP.mobile;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = otp;
                        cmd.Parameters.Add("TYPED_OTP",OracleDbType.Varchar2).Value = sendMobileOTP.otp;

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                        SendSMS.SendOTP(sendMobileOTP.mobile,otp);



                    }
                }

                return dt;
            }
            catch(Exception ex)
            {
                return null;
                
            }

          
           

        }
    }
}
