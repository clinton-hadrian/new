﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class SendSMS
    {
       // private readonly string url;
        //public SendSMS(IConfiguration configuration)
        //{
        //    url = configuration.GetSection("MOBILE_SMS").Value;
        //}

        

        public void SendOTP(string mobileno, string OTP)
        {
            string tomobileno = mobileno;
            string Msg = "Dear User, Your OTP for SPARK registration is " + OTP + " by Cameo";
            //string Msg = "Dear User, Your OTP for Rights issue is " + OTP + " by Cameo";
            string Uname = "CameoSMS";
            string Pwd = "Cameo10";
            string ProId = "71";

            string url = "http://180.179.33.131/boansms/Boansmsinterface.aspx?";
            url += "mobileno=" + tomobileno + "&";
            url += "smsmsg=" + Msg + "&";
            url += "uname=" + Uname + "&";
            url += "pwd=" + Pwd + "&";
            url += "pid=" + ProId;

            string s = string.Empty;
            try
            {
                WebClient client = new WebClient();
                string baseurl = url;
                Stream data = client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                s = reader.ReadToEnd();
                data.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
              //  DAL.Log("SendSMS :" + ex.Message);
                throw;
            }
        }
    }
}
