﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Models
{
    public class FileModels
    {
        public int fileId { get; set; }
        public int complaintId { get; set; }
        public int messageId { get; set; }
        public string fileName { get; set; }
        public string createdBy { get; set; }
        public string roleName { get; set; }
        public string fileOrigin { get; set; }
        public int multipleQueryId { get; set; } 



    }
}
