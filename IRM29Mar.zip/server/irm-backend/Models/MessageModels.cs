﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Models
{
    public class MessageModels
    {
      
        public int? messageId { get; set; }
        public int complaintId { get; set; }
        public string message { get; set; }
        
    }
}
