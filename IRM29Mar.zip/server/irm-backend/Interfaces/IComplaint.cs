﻿using irm_backend.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Interfaces
{
    public interface IComplaint
    {
        DataTable addComplaint(customerModel customer, IFormFile[] files, string customerId, string role);
        DataTable viewComplaint(customerModel customer);
        DataTable updateComplaint(customerModel customer);
        DataTable listComplaint(customerModel customer);
        DataTable recentListComplaint(string customerId);
        DataTable recentAllComplaint();
        DataTable closedListComplaint(string customerId);
        DataTable closedAllComplaint();
        DataTable company();
        DataTable singleQuery();
        DataTable multipleQuery(customerModel customer);
        DataTable attendListComplaint(string customerId);
        DataTable attendAllComplaint();

    }
}
