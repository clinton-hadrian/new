﻿using irm_backend.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Interfaces
{
    public interface IMessage
    {
        DataTable postMessage(MessageModels message, IFormFile[] files, string customer_user_id, string roleName);
        DataTable viewMessage(MessageModels message, string customer_user_id, string roleName);
        DataTable viewFile(FileModels file, string customer_user_id, string roleName);
        DataTable viewMessageFile(FileModels file, string customer_user_id, string roleName);
        DataTable closeComplaint(MessageModels message, string customer_user_id, string roleName);
        DataTable checkMessage(MessageModels message);
    }
}
