﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class AuthService : IAuth
    {
        private readonly string _connectionString;
        private IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        JwtTokenService jwt = new JwtTokenService();
        CreateErrorLog error = new CreateErrorLog();
        SendSMS SendSMS=new SendSMS();
        public AuthService(IConfiguration _configuration,IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _connectionString = _configuration.GetConnectionString("crestCon");
            _config = _configuration;
        }

        //private string GenerateToken(sendMobileOTPModel sendMobileOTP)
        //{
        //    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
        //    var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        //    var token = new JwtSecurityToken(_config["Jwt:Issuer"], _config["Jwt:Audience"], null,
        //        expires: DateTime.Now.AddMinutes(1),
        //        signingCredentials: credentials);
        //    return new JwtSecurityTokenHandler().WriteToken(token);
        //}

        public DataTable sendMobileOTP(sendMobileOTPModel sendMobileOTP)
        {
           
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                      //  var otp = new Random().Next(100000, 999999).ToString();
                        var otp = (111111).ToString();
                        var flag = 1;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = sendMobileOTP.mobile;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = otp;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = flag;
                        cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        //  cmd.Parameters["ARG_OUTPUT"].Value.ToString(); 
                
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);

                        con.Close();
                        SendSMS.SendOTP(sendMobileOTP.mobile,otp);

                    }
                }

                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
                
            }      

        }

        public DataTable OTPVerification(sendMobileOTPModel sendMobileOTP)
        {
            
                        try
                        {
                            DataTable dt = new DataTable();
                            DataTable dt1 = new DataTable();
                            using (OracleConnection con = new OracleConnection(_connectionString))
                            {
                                using (OracleCommand cmd = con.CreateCommand())
                                {
                                    con.Open();
                                    var flag = 2;
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.CommandText = "MOBILE_AND_OTP";
                                    cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = DBNull.Value;
                                    cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = sendMobileOTP.mobile;
                                    cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = sendMobileOTP.otp;
                                    cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = flag;
                                    cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = String.Empty;
                                    cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                                    cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                                    oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            dt1.Columns.Add("TOKEN");
                            dt1.Columns.Add("EXISTUSER");
                            dt1.Columns.Add("ROLE");
                            dt1.Rows.Add(jwt.generateToken("CUSTOMER", dt.Rows[0]["ID"].ToString()), dt.Rows[0]["EXISTUSER"].ToString(), "CUSTOMER");
                        }
                                    con.Close();
                                }
                            }
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;
                }
                        }
                        catch (Exception ex)
                        {
                error.errorLog(ex.Message);
                return null;
                        }
                    
        }


        public DataTable addProfile(sendMobileOTPModel sendMobileOTP)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        var flag = 3;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = sendMobileOTP.mobile;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = flag;
                        cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = sendMobileOTP.name;
                        cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = sendMobileOTP.email;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
            }

        public DataTable getProfile(string ID)
        { 
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = ID;
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 4;
                        cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
        }

        public DataTable updateProfile(sendMobileOTPModel sendMobileOTP)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        var flag = 5;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = sendMobileOTP.profileID;
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = flag;
                        cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = sendMobileOTP.name;
                        cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = sendMobileOTP.email;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
        }

        public DataTable resendOTP(sendMobileOTPModel sendMobileOTP)
        {
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        //var otp = new Random().Next(100000, 999999).ToString();
                        var flag = 0;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MOBILE_AND_OTP";
                        cmd.Parameters.Add("ARG_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MOBILE", OracleDbType.Varchar2).Value = sendMobileOTP.mobile;
                        cmd.Parameters.Add("ARG_OTP", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = flag;
                        cmd.Parameters.Add("ARG_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        //  cmd.Parameters["ARG_OUTPUT"].Value.ToString(); 

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);

                        con.Close();
                        if (dt.Rows.Count > 0)
                        {
                            SendSMS.SendOTP(dt.Rows[0]["MOBILE"].ToString(), dt.Rows[0]["OTP"].ToString());
                            dt1.Columns.Add("MOBILE");
                            dt1.Rows.Add(dt.Rows[0]["MOBILE"].ToString());
                        }

                    }
                }

                return dt1;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;

            }
        }

        public DataTable sendCredentials(sendMobileOTPModel sendMobileOTP)
        {

            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                   
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "USER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = 1;
                        cmd.Parameters.Add("ARG_USERNAME", OracleDbType.Varchar2).Value = sendMobileOTP.userName;
                        cmd.Parameters.Add("ARG_PASSWORD", OracleDbType.Varchar2).Value = sendMobileOTP.password ;
                        cmd.Parameters.Add("ARG_USER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
         

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            dt1.Columns.Add("TOKEN");
                            dt1.Columns.Add("USERNAME");
                            dt1.Columns.Add("USER_ID");
                            dt1.Columns.Add("ROLE");
                            dt1.Rows.Add(jwt.generateToken("USER", dt.Rows[0]["ID"].ToString()), dt.Rows[0]["USERNAME"].ToString(),dt.Rows[0]["ID"].ToString(), "USER");
                        }
                        con.Close();
                       

                    }
                }       
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;

                }
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;

            }

        }


    }

    }






/* var status = new OracleParameter
                        {
                            ParameterName = "ARG_OUTPUT",
                            Direction = ParameterDirection.Output,
                            OracleDbType = OracleDbType.Varchar2,
                            Size = 200

                        };
                        cmd.Parameters.Add(status); */