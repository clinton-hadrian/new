﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class CreateErrorLog
    {
        public void errorLog(string errorMessage)
        {
            string fileNamePath= @"\\172.16.16.120\share\IRMErrors\errorLog.txt";
            if (!File.Exists(fileNamePath))
            {
                using (FileStream fs = File.Create(fileNamePath))
                {
                    byte[] info = new UTF8Encoding(true).GetBytes(DateTime.Now.ToString() + "-" + errorMessage);
                    fs.Write(info, 0, info.Length);
                    fs.Close();
                    
                }
            }
            else
            {
                using(StreamWriter sw = File.AppendText(fileNamePath))
                {
                    sw.WriteLine(DateTime.Now.ToString() + "-" + errorMessage+"#\r\n#");
                    sw.Close();
                }
            }
          
        }
    }
}
