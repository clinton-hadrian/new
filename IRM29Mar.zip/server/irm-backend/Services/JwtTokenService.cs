﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class JwtTokenService
    {
        public string generateToken(string role,string id)
        {
            var claims = new[]
              {
            new Claim(ClaimTypes.NameIdentifier,id),
            new Claim(ClaimTypes.Role, role)
        };

            // Generate a JWT token
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("secretKEEE0123456789abcdefghijklmnopqrstuvwxyz"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: "http://localhost:58535/",
                audience: "http://localhost:58535/",
                claims: claims,
                expires: DateTime.Now.AddDays(1),
                signingCredentials: creds
            );
           string generatedToken = new JwtSecurityTokenHandler().WriteToken(token);

            // Return token to the client
            //return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
            return generatedToken;
        }

        public bool verifyToken(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("secretKEEE0123456789abcdefghijklmnopqrstuvwxyz"));
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    IssuerSigningKey = key,
                    ValidIssuer = "http://localhost:58535/",
                    ValidAudience = "http://localhost:58535/",
                    // set clockskew to zero so tokens expire exactly at token expiration time.
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string getItem(string Token,int claim)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken token = tokenHandler.ReadJwtToken(Token) as JwtSecurityToken;
                var check= token.Claims;
                int index = 0;
                string data="";
                foreach(var val in check)
                {
                    if (index==claim)
                    {
                        data = val.Value;
                        break;
                    }
                    index++;
                }
                return data;
            }
            catch (Exception ex)
            {
                return null;
            }
           
        }
    }
    }

