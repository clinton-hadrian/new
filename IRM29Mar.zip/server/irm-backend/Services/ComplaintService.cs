﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Services
{
   
        public class ComplaintService : IComplaint
        {
            private readonly string _connectionString;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly SendMail _sendMail;

        CreateErrorLog create = new CreateErrorLog();


        public ComplaintService(IConfiguration _configuration,IHostingEnvironment hostingEnvironment)
        {
            _connectionString = _configuration.GetConnectionString("CrestCon");
            _sendMail = new SendMail(hostingEnvironment, _configuration);

        }

        //public ComplaintService(SendMail sendMail)
        //{
        //    _sendMail = sendMail;
        //}



        public DataTable addComplaint(customerModel customer, IFormFile[] files, string customerId, string role)
            {

            string complaintId=string.Empty;
            int cusId = 0;
            int id = int.Parse(customerId);
            if (role == "USER")
            {
                cusId = 0;
            }
            else
            {
                cusId = int.Parse(customerId);
            }

                string roleName = role;
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                DataTable dt2 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                         {
                             con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "MULTIPLE_QUERY_PROCEDURE";
                        cmd.BindByName = true;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = id;
                         cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = roleName;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt1);
                        int N = Convert.ToInt32(dt1.Rows[0]["MULTIPLE_QUERY_ID"].ToString());
                        int length = customer.query.Length;

                        if (customer.query.Length > 1)
                         {
                           
                                using (OracleCommand cmd1 = con.CreateCommand())
                            {
                                foreach (var q in customer.query)
                                {
                                         cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.CommandText = "CUSTOMER_PROCEDURE";
                                    cmd1.BindByName = true;
                                    cmd1.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                                    cmd1.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = id;
                                    cmd1.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = roleName;
                                    cmd1.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = customer.customerMobile;
                                    cmd1.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = customer.customerEmail;
                                    cmd1.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                                    cmd1.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = cusId;
                                    cmd1.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = customer.investorName;
                                    cmd1.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = customer.companyName;
                                    cmd1.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = customer.folioDemat;
                                    cmd1.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = customer.pan;
                                    cmd1.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = N;
                                    cmd1.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = "TRUE";
                                    cmd1.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = q;
                                    cmd1.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = customer.problemStatement;
                                    cmd1.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                                    cmd1.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                                    OracleDataAdapter oda1 = new OracleDataAdapter(cmd1);
                                   
                                        oda1.Fill(dt);
                                    
                                    cmd1.Parameters.Clear();
                                    length--;

                                }

                               
                            }
                        }
                        else
                        {
                            using (OracleCommand cmd1 = con.CreateCommand())
                            {
                                cmd1.CommandType = CommandType.StoredProcedure;
                                cmd1.CommandText = "CUSTOMER_PROCEDURE";
                                cmd1.BindByName = true;
                                cmd1.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                                cmd1.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = id;
                                cmd1.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = roleName;
                                cmd1.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = customer.customerMobile;
                                cmd1.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = customer.customerEmail;
                                cmd1.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                                cmd1.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = cusId;
                                cmd1.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = customer.investorName;
                                cmd1.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = customer.companyName;
                                cmd1.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = customer.folioDemat;
                                cmd1.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = customer.pan;
                                cmd1.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = customer.problemStatement;
                                cmd1.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                                cmd1.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                                cmd1.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = 0;
                                cmd1.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = "FALSE";
                                cmd1.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = customer.query[0].ToString();
                                OracleDataAdapter oda2 = new OracleDataAdapter(cmd1);
                                oda2.Fill(dt);
                                cmd1.Parameters.Clear();
                            }
                        }
                        con.Close();
                        if (files.Length > 0)
                        {
                            if (customer.query.Length > 1)
                            {
                                insertFiles(files,"0", N, customerId, roleName);
                            }
                            else
                            {
                                insertFiles(files, dt.Rows[0]["COMPLAINT_ID"].ToString(),0, customerId, roleName);
                            }
                                }
                            }
                        }
                if (customer.query.Length > 1) {
                    foreach (DataRow row in dt.Rows)
                    {
                        complaintId += $"#{row["COMPLAINT_ID"].ToString().PadLeft(4, '0')}";

                        if (row != dt.Rows[dt.Rows.Count - 1])
                        {
                            complaintId += ",";
                        }
                    }
                }
                else
                {
                    complaintId = $"#{dt.Rows[0]["COMPLAINT_ID"].ToString().PadLeft(4,'0')}";
                }

                _sendMail.SendMail_ComplaintSubmit(dt.Rows[0]["EMAIL"].ToString().ToLower(), complaintId);

                return dt;
                }
                catch (Exception ex)
                {
                    create.errorLog(ex.Message.ToString());
                return null;
                }

            }

            public void insertFiles(IFormFile[] files, string complaint_id,int multiple_query_id, string createdName, string roleName)
            {
                int compId = Convert.ToInt32(complaint_id);
                int length = files.Length + 1;
            string fileName;
                try
                {
                    foreach (var f in files)
                    {
                        using (OracleConnection con = new OracleConnection(_connectionString))
                        {
                            using (OracleCommand cmd = con.CreateCommand())
                            {
                                con.Open();
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "COMMON_PROCEDURE";
                                cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                                cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                                cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                                
                                cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = 0;
                                cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                                cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = f.FileName;
                            if (multiple_query_id == 0)
                            {
                                 fileName = "comp_id_" + complaint_id + "_" + length + "" + Path.GetExtension(f.FileName);
                            }
                            else
                            {
                                 fileName = "mul_query_id_" + multiple_query_id + "_" + length + "" + Path.GetExtension(f.FileName);
                            }
                                cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = fileName;


                                string networkPath = @"\\172.16.16.120\Share\IRMfiles\";
                                // string networkPath = @"F:\Share\IRMfiles\";
                                string fullPath = Path.Combine(networkPath, fileName.ToUpper());
                                using (FileStream fs = new FileStream(fullPath, FileMode.Create))
                                {
                                    f.CopyTo(fs);
                                }

                                string[] filesNames = files.Select(file => file.FileName).ToArray();
                                string fileNames = string.Join(",", filesNames);

                                cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                                cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                                cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = "complaint";
                                cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = f.ContentType;
                            cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = multiple_query_id;

                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                                OracleDataAdapter oda = new OracleDataAdapter(cmd);
                                length--;
                                using (OracleDataReader reader = cmd.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        Console.WriteLine(reader.GetString(0)); //Assuming the output is a single string value
                                    }
                                }
                                con.Close();


                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    create.errorLog(ex.Message.ToString());
                    Console.WriteLine(ex.Message);
                }
            }


            public DataTable viewComplaint(customerModel customer)
            {
                try
                {
                    DataTable dt = new DataTable();
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();
                            string id = customer.complaintId.ToString().TrimStart('0');
                            int compId = Convert.ToInt32(id);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "CUSTOMER_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 2;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                            cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            oda.Fill(dt);

                            //string[] fileNameArr = dt.Rows[0]["FILE_NAME"].ToString().Split(',');
                            //dt.Columns.Add("FILE_URLS");
                            //DataRow newRow = dt.NewRow();
                            //newRow["FILE_URLS"] = string.Join(",", fileNameArr.Select(fileName => Path.Combine(@"F:\Share\IRMFiles\", fileName.ToLower().Trim())));
                            //dt.Rows.Add(newRow);

                            con.Close();

                        }


                    }
                    return dt;
                }
                catch (Exception ex)
                {
                    create.errorLog(ex.Message.ToString());
                    return null;
                }
            }

            public DataTable recentListComplaint(string customerId)
            {
                int id = int.Parse(customerId);
                try
                {
                    DataTable dt = new DataTable();
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "CUSTOMER_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 3;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = id;
                            cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            oda.Fill(dt);
                            con.Close();
                        }
                    }
                    return dt;
                }
                catch (Exception ex)
                {
                    create.errorLog(ex.Message.ToString());
                    return null;
                }
            }

        public DataTable recentAllComplaint()
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 4;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable closedListComplaint(string customerId)
        {
            int id = int.Parse(customerId);
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 5;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = id;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable closedAllComplaint()
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 6;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable company()
        {
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.BindByName = true;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 7;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            dt1.Columns.Add("label");
                            dt1.Columns.Add("id");

                            foreach (DataRow row in dt.Rows)
                            {
                                dt1.Rows.Add(row["COMPANYNAME"].ToString(), row["ID"].ToString());
                            }
                        }
                        con.Close();
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;

                }
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }
        public DataTable singleQuery()
        {
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.BindByName = true;
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 8;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            dt1.Columns.Add("label");
                            dt1.Columns.Add("id");

                            foreach (DataRow row in dt.Rows)
                            {
                                dt1.Rows.Add(row["DESCRIPTION"].ToString(), row["CODE"].ToString());
                            }
                        }
                        con.Close();
                    }
                }
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;

                }
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable multipleQuery(customerModel customer)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        string id = customer.complaintId.ToString().TrimStart('0');
                        int compId = Convert.ToInt32(id);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 9;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;

                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);

                        //string[] fileNameArr = dt.Rows[0]["FILE_NAME"].ToString().Split(',');
                        //dt.Columns.Add("FILE_URLS");
                        //DataRow newRow = dt.NewRow();
                        //newRow["FILE_URLS"] = string.Join(",", fileNameArr.Select(fileName => Path.Combine(@"F:\Share\IRMFiles\", fileName.ToLower().Trim())));
                        //dt.Rows.Add(newRow);

                        con.Close();

                    }


                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable attendListComplaint(string customerId)
        {
            int id = int.Parse(customerId);
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 10;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = id;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable attendAllComplaint()
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 11;
                        cmd.Parameters.Add("ARG_CREATED_BY", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CREATED_ROLE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_MOBILE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_CUSTOMER_EMAIL", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }


        public DataTable updateComplaint(customerModel customer)
            {
                throw new NotImplementedException();
            }

            public DataTable listComplaint(customerModel customer)
            {
                throw new NotImplementedException();
            }

        //public void createErrorLog(string errorMessage)
        //{
        //    string fileNamePath = @"F:\share\IRMErrors";
        //    if (!File.Exists(fileNamePath))
        //    {
        //        using (FileStream fs = File.Create(fileNamePath))
        //        {
        //            byte[] info = new UTF8Encoding(true).GetBytes(DateTime.Now.ToString() + "-" + errorMessage);
        //            fs.Write(info, 0, info.Length);
        //        }

        //    }
        //    else
        //    {
        //        using (StreamWriter sw = File.AppendText(fileNamePath))
        //        {
        //            sw.WriteLine(DateTime.Now.ToString() + "-" + errorMessage);
        //        }
        //    }
        //}


        //string cId = dt.Rows[0]["COMPLAINT_ID"].ToString();
        //    string email = dt.Rows[0]["EMAIL"].ToString().ToLower();
        //   _sendMail.SendMail_ComplaintSubmit(email,cId);

    }
}


