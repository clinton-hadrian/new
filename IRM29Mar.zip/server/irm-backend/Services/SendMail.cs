﻿using irm_backend.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Services
{
   
   public class SendMail
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _config;


        public SendMail(IHostingEnvironment hostingEnvironment, IConfiguration config)
        {
            _hostingEnvironment = hostingEnvironment;
            _config = config;
        }

        public void SendMail_ComplaintSubmit(string Email,string complaintId)

        {
            string webRootPath = _hostingEnvironment.WebRootPath;

            CreateErrorLog error = new CreateErrorLog();

            //     private readonly string _connectionString;
            //public SendMail_Cameo(IConfiguration _configuration)
            //{
            //    _connectionString = _configuration.GetConnectionString("CrestCon");
            //}


            System.Net.Mail.MailMessage mail;

            System.Net.Mail.SmtpClient mailClnt;

            string _MailContent;

         

                _MailContent = System.IO.File.ReadAllText(webRootPath + "mailTemplates/ComplaintSubmittedByCustomer.html");

         


            mail = new System.Net.Mail.MailMessage();

            mailClnt = new System.Net.Mail.SmtpClient(this._config.GetValue<string>("EmailSettings:SMTPMail"));


         
            //mailClnt = new System.Net.Mail.SmtpClient("210.18.91.214");

            mailClnt.Credentials = new System.Net.NetworkCredential(this._config.GetValue<string>("EmailSettings:UserName"), this._config.GetValue<string>("EmailSettings:Password").ToString());

            string toId, mailsender, mailSubject;

            toId = Email;

            mailsender = (this._config.GetValue<string>("EmailSettings:DisplayName")) + " < " + (this._config.GetValue<string>("EmailSettings:UserName")) + ">";// ConfigurationManager.AppSettings["FromMail"].ToString();

            mailSubject = "Complaint Submitted Successfully";

            mail.From = new System.Net.Mail.MailAddress(mailsender);

            mail.To.Add(new System.Net.Mail.MailAddress(toId));

            //mail.Bcc.Add(ConfigurationManager.AppSettings["UserBCC"].ToString());

            mail.Subject = mailSubject;

            //_MailContent = _MailContent.Replace("{{url}}", "\"" + "http://192.168.0.121:5252/" + "\"");
            _MailContent = _MailContent.Replace("{{url}}", $"http://192.168.0.121:5252");
            _MailContent = _MailContent.Replace("{{DATETIME}}", DateTime.Now.ToString());
            _MailContent = _MailContent.Replace("{{COMPLAINT_ID}}", complaintId);

            mail.Body = _MailContent;

            mail.IsBodyHtml = true;

            mailClnt.EnableSsl = true;

            mailClnt.Port = 587;

            try

            {

                mailClnt.Send(mail);


            }

            catch (Exception ex)

            {

                error.errorLog("SendMail_Cameo :" + ex.Message);

            }

        }

        public void SendMail_ComplaintClosed(string Email, string complaintId)

        {
            string webRootPath = _hostingEnvironment.WebRootPath;

            CreateErrorLog error = new CreateErrorLog();

            //     private readonly string _connectionString;
            //public SendMail_Cameo(IConfiguration _configuration)
            //{
            //    _connectionString = _configuration.GetConnectionString("CrestCon");
            //}


            System.Net.Mail.MailMessage mail;

            System.Net.Mail.SmtpClient mailClnt;

            string _MailContent;



            _MailContent = System.IO.File.ReadAllText(webRootPath + "mailTemplates/ComplaintClosedByUser.html");




            mail = new System.Net.Mail.MailMessage();

            mailClnt = new System.Net.Mail.SmtpClient(this._config.GetValue<string>("EmailSettings:SMTPMail"));



            //mailClnt = new System.Net.Mail.SmtpClient("210.18.91.214");

            mailClnt.Credentials = new System.Net.NetworkCredential(this._config.GetValue<string>("EmailSettings:UserName"), this._config.GetValue<string>("EmailSettings:Password").ToString());

            string toId, mailsender, mailSubject;

            toId = Email;

            mailsender = (this._config.GetValue<string>("EmailSettings:DisplayName")) + " < " + (this._config.GetValue<string>("EmailSettings:UserName")) + ">";// ConfigurationManager.AppSettings["FromMail"].ToString();

            mailSubject = "Complaint has been closed";

            mail.From = new System.Net.Mail.MailAddress(mailsender);

            mail.To.Add(new System.Net.Mail.MailAddress(toId));

            //mail.Bcc.Add(ConfigurationManager.AppSettings["UserBCC"].ToString());

            mail.Subject = mailSubject;

            //_MailContent = _MailContent.Replace("{{url}}", "\"" + "http://192.168.0.121:5252/" + "\"");
            _MailContent = _MailContent.Replace("{{url}}", $"http://192.168.0.121:5252");
            _MailContent = _MailContent.Replace("{{DATETIME}}", DateTime.Now.ToString());
            _MailContent = _MailContent.Replace("{{COMPLAINT_ID}}", complaintId);

            mail.Body = _MailContent;

            mail.IsBodyHtml = true;

            mailClnt.EnableSsl = true;

            mailClnt.Port = 587;

            try

            {

                mailClnt.Send(mail);


            }

            catch (Exception ex)

            {

                error.errorLog("SendMail_Cameo :" + ex.Message);

            }

        }

        public void SendMail_ComplaintMessage(string Email, string complaintId)

        {
            string webRootPath = _hostingEnvironment.WebRootPath;

            CreateErrorLog error = new CreateErrorLog();

            //     private readonly string _connectionString;
            //public SendMail_Cameo(IConfiguration _configuration)
            //{
            //    _connectionString = _configuration.GetConnectionString("CrestCon");
            //}


            System.Net.Mail.MailMessage mail;

            System.Net.Mail.SmtpClient mailClnt;

            string _MailContent;



            _MailContent = System.IO.File.ReadAllText(webRootPath + "mailTemplates/ComplaintMessage.html");




            mail = new System.Net.Mail.MailMessage();

            mailClnt = new System.Net.Mail.SmtpClient(this._config.GetValue<string>("EmailSettings:SMTPMail"));



            //mailClnt = new System.Net.Mail.SmtpClient("210.18.91.214");

            mailClnt.Credentials = new System.Net.NetworkCredential(this._config.GetValue<string>("EmailSettings:UserName"), this._config.GetValue<string>("EmailSettings:Password").ToString());

            string toId, mailsender, mailSubject;

            toId = Email;

            mailsender = (this._config.GetValue<string>("EmailSettings:DisplayName")) + " < " + (this._config.GetValue<string>("EmailSettings:UserName")) + ">";// ConfigurationManager.AppSettings["FromMail"].ToString();

            mailSubject = "Your Complaint received a new message";

            mail.From = new System.Net.Mail.MailAddress(mailsender);

            mail.To.Add(new System.Net.Mail.MailAddress(toId));

            //mail.Bcc.Add(ConfigurationManager.AppSettings["UserBCC"].ToString());

            mail.Subject = mailSubject;

            //_MailContent = _MailContent.Replace("{{url}}", "\"" + "http://192.168.0.121:5252/" + "\"");
            _MailContent = _MailContent.Replace("{{url}}", $"http://192.168.0.121:5252");
            _MailContent = _MailContent.Replace("{{DATETIME}}", DateTime.Now.ToString());
            _MailContent = _MailContent.Replace("{{COMPLAINT_ID}}", complaintId);

            mail.Body = _MailContent;

            mail.IsBodyHtml = true;

            mailClnt.EnableSsl = true;

            mailClnt.Port = 587;

            try

            {

                mailClnt.Send(mail);


            }

            catch (Exception ex)

            {

                error.errorLog("SendMail_Cameo :" + ex.Message);

            }

        }
    }
}
