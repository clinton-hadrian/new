﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class UserService:IUser
    {
        private readonly string _connectionString;
        CreateErrorLog create = new CreateErrorLog();
        private object sendMobileOTP;

        public UserService(IConfiguration _configuration)
        {
            _connectionString = _configuration.GetConnectionString("CrestCon");
        }
        public DataTable userClosedComplaints()
        {
           
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();

                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "USER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = 2;
                        cmd.Parameters.Add("ARG_USERNAME", OracleDbType.Varchar2).Value =String.Empty;
                        cmd.Parameters.Add("ARG_PASSWORD", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_USER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable userClosedList(UserModel user)
        {
            int uId = Convert.ToInt32(user.userId);
            try
            {
                DataTable dt = new DataTable();

                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "USER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Decimal).Value = 3;
                        cmd.Parameters.Add("ARG_USERNAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PASSWORD", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_USER_ID", OracleDbType.Int32).Value = uId;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable templates()
        {
         
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "COMMON_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 7;
                        cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        //string path=@"file:///F:/Share/IRMfiles/";


                        //oda.Fill(dt);
                        //if (dt.Rows.Count > 0)
                        //{
                            string path = @"\\172.16.16.120\Share\IRMfiles\IRMTemplates";
                        FileInfo[] files = new DirectoryInfo(path).GetFiles();                            //int l = f.Length;
                                                                                                          // int j = 0;

                        dt1.Columns.Add("FILE_NAME",typeof (byte[]));
                            dt1.Columns.Add("label");
                            dt1.Columns.Add("FILE_TYPE");
                        dt1.Columns.Add("id");
                        int i = 1;
                        //for (int i = 0; i < dt.Rows.Count; i++)
                        //{
                        //    if (i < files.Length)
                        foreach (var file in files)
                                {

                                    byte[] fileBytes = File.ReadAllBytes(file.FullName); // Read the file contents as bytes
                                    string base64File = Convert.ToBase64String(fileBytes); // Convert the bytes to base64
                                    dt1.Rows.Add( fileBytes, file.Name, file.Extension,i);
                            i++;

                                }
                            

                        }

                    
                    con.Close();

                }
              
                    return dt1;
                
                
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }
    }
}
