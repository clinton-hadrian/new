﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    
        public class MessageService : IMessage
        {
            private readonly string _connectionString;
        
        private readonly SendMail _sendMail;
            CreateErrorLog error = new CreateErrorLog();
            public MessageService(IConfiguration _configuration,IHostingEnvironment _hostingEnvironment)
            {
                _connectionString = _configuration.GetConnectionString("CrestCon");
            _sendMail = new SendMail(_hostingEnvironment, _configuration);

            }

            public DataTable postMessage(MessageModels message, IFormFile[] files, string customer_user_id, string role)
            {
                string createdName = customer_user_id;
                string roleName = role;
                try
                {
                    DataTable dt = new DataTable();
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();

                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 3;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = message.message;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            oda.Fill(dt);
                            con.Close();
                            if (files.Length > 0)
                            {
                                insertFiles(files, message.complaintId, dt.Rows[0]["MESSAGE_ID"].ToString(), createdName, roleName);
                            }
                        }
                    }
                if (roleName == "USER") {
                    _sendMail.SendMail_ComplaintMessage(dt.Rows[0]["EMAIL"].ToString().ToLower(),$"#{dt.Rows[0]["COMPLAINT_ID"].ToString().PadLeft(4,'0')}");
                        }
                //else
                //{
                //    _sendMail.SendMail_ComplaintMessage(dt.Rows[0]["EMAIL"].ToString().ToLower(), dt.Rows[0]["COMPLAINT_ID"].ToString());
                //}
                    return dt;
                }
                catch (Exception ex)
                {
                    error.errorLog(ex.Message);
                    return null;
                }

            }

            public void insertFiles(IFormFile[] files, int complaint_id, string message_id, string createdName, string roleName)
            {
                int messId = Convert.ToInt32(message_id);
                int compId = complaint_id;
                int length = files.Length + 1;
                try
                {
                    foreach (var f in files)
                    {
                        using (OracleConnection con = new OracleConnection(_connectionString))
                        {
                            using (OracleCommand cmd = con.CreateCommand())
                            {
                                con.Open();
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "COMMON_PROCEDURE";
                                cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 8;
                                cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                                cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                                cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = messId;
                                cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                                 string networkPath = @"\\172.16.16.120\Share\IRMfiles\";
                               // string networkPath = @"F:\Share\IRMfiles\";
                                cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = f.FileName;
                            string uniqueId = Path.GetRandomFileName().Replace(".", "");
                            string fileName = "mess_id_" + complaint_id + "_" + length + "_"+uniqueId+"" + Path.GetExtension(f.FileName);
                                cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = fileName;
                                string fullPath = Path.Combine(networkPath, fileName.ToUpper());

                                using (FileStream fs = new FileStream(fullPath, FileMode.Create))
                                {
                                    f.CopyTo(fs);
                                }

                                string[] filesNames = files.Select(file => file.FileName).ToArray();
                                string fileNames = string.Join(",", filesNames);

                                cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                                cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                                cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = "message";
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = f.ContentType;
                            cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            length--;
                            using (OracleDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    Console.WriteLine(reader.GetString(0)); //Assuming the output is a single string value
                                }
                            }
                            con.Close();
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                error.errorLog(ex.Message.ToString());
                }
            }


            public DataTable viewMessage(MessageModels message, string customer_user_id, string role)
            {
                string createdName = customer_user_id;
                string roleName = role;
                try
                {
                    DataTable dt = new DataTable();

                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 4;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            oda.Fill(dt);
                            con.Close();
                        }
                    }
                    return dt;
                }
                catch (Exception ex)
                {
                    error.errorLog(ex.Message);
                    return null;
                }
            }

            public DataTable viewFile(FileModels file, string customer_user_id, string role)
            {
                string createdName = customer_user_id;
                string roleName = role;
            string[] files;
                try
                {
                    DataTable dt = new DataTable();
                    DataTable dt1 = new DataTable();
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();

                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 2;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = file.complaintId;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = file.messageId;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = file.multipleQueryId;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            //string path=@"file:///F:/Share/IRMfiles/";


                            oda.Fill(dt);
                            if (dt.Rows.Count > 0)
                            {
                                string path = @"\\172.16.16.120\Share\IRMfiles\";
                            if (file.multipleQueryId == 0)
                            {
                                files = Directory.GetFiles(path, $"COMP_ID_{file.complaintId}_*");
                            }
                            else
                            {
                                files = Directory.GetFiles(path, $"MUL_QUERY_ID_{file.multipleQueryId}_*");
                            }
                               
                                //int l = f.Length;
                                int j = 0;
                                dt1.Columns.Add("FILE_NAME");
                                dt1.Columns.Add("ORIGINAL_NAME");
                                dt1.Columns.Add("FILE_TYPE");
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    if (i < files.Length)

                                    {

                                        byte[] fileBytes = File.ReadAllBytes(files[i]); // Read the file contents as bytes
                                        string base64File = Convert.ToBase64String(fileBytes); // Convert the bytes to base64
                                        dt1.Rows.Add(base64File, dt.Rows[i]["ORIGINAL_NAME"].ToString(), dt.Rows[i]["FILE_TYPE"].ToString());

                                    }
                                }

                            }

                        }
                        con.Close();

                    }
                    if (dt.Rows.Count > 0)
                    {
                        return dt1;
                    }
                    else
                    {
                        return dt;
                    }
                }
                catch (Exception ex)
                {
                    error.errorLog(ex.Message);
                    return null;
                }
            }

       

        public DataTable closeComplaint(MessageModels message, string customer_user_id, string role)
        {
            string roleName = role;
            string complaintId = string.Empty;
            string email = string.Empty;
            string createdName = customer_user_id;
            
            try
            {
                DataTable dt = new DataTable();

                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "COMMON_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 5;
                        cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                        cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                        cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                        cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                if (role == "USER")
                {
                    complaintId = $"#{dt.Rows[0]["COMPLAINT_ID"].ToString().PadLeft(4,'0')}";
                    email = dt.Rows[0]["EMAIL"].ToString().ToLower();
                }
                _sendMail.SendMail_ComplaintClosed(email, complaintId);
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
        }

        public DataTable checkMessage(MessageModels message)
        {
            
            try
            {
                DataTable dt = new DataTable();

                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "COMMON_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 6;
                        cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                        cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
        }

        public DataTable viewMessageFile(FileModels file, string customer_user_id, string role)
        {
            string createdName = customer_user_id;
            string roleName = role;
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "COMMON_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 7;
                        cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = file.complaintId;
                        cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = file.messageId;
                        cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                        cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                        cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_MULTIPLE_QUERY_ID", OracleDbType.Int32).Value = DBNull.Value;

                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        //string path=@"file:///F:/Share/IRMfiles/";


                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            string path = @"\\172.16.16.120\Share\IRMfiles\";
                            string[] files = Directory.GetFiles(path, $"MESS_ID_{file.complaintId}_*");
                            //int l = f.Length;
                            int j = 0;
                            dt1.Columns.Add("MESSAGE_ID");
                            dt1.Columns.Add("FILE_NAME");
                            dt1.Columns.Add("ORIGINAL_NAME");
                            dt1.Columns.Add("FILE_TYPE");
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (i < files.Length)

                                {

                                    byte[] fileBytes = File.ReadAllBytes(files[i]); // Read the file contents as bytes
                                    string base64File = Convert.ToBase64String(fileBytes); // Convert the bytes to base64
                                    dt1.Rows.Add(dt.Rows[i]["MESSAGE_ID"].ToString(),base64File, dt.Rows[i]["ORIGINAL_NAME"].ToString(), dt.Rows[i]["FILE_TYPE"].ToString());

                                }
                            }

                        }

                    }
                    con.Close();

                }
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;
                }
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message.ToString());
                return null;
            }
        }


    }
    }

