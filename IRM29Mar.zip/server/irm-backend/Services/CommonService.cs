﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Services
{
    public class CommonService:ICommon
    {
        private readonly string _connectionString;
        CreateErrorLog error = new CreateErrorLog();
        public CommonService(IConfiguration _configuration)
        {
            _connectionString = _configuration.GetConnectionString("CrestCon");
        }

        public DataTable postMessage(MessageModels message,IFormFile[] files, string customer_user_id, string role)
        {
            string createdName = customer_user_id;
            string roleName = role;
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "COMMON_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 3;
                        cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                        cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = message.message;
                        cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                        cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                        cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                        if (files.Length > 0)
                        {
                            insertFiles(files, dt.Rows[0]["MESSAGE_ID"].ToString(), createdName, roleName);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }

        }

        public void insertFiles(IFormFile[] files, string message_id, string createdName, string roleName)
        {
            int messId = Convert.ToInt32(message_id);
            int length = files.Length + 1;
            try
            {
                foreach (var f in files)
                {
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = 0;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = messId;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = f.FileName;
                            string fileName = "mess_id_" + message_id + "_" + length + "" + Path.GetExtension(f.FileName);
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = fileName;


                            string networkPath = @"\\172.16.16.120\Share\IRMfiles\";
                            // string networkPath = @"F:\Share\IRMfiles\";
                            string fullPath = Path.Combine(networkPath, fileName.ToUpper());
                            using (FileStream fs = new FileStream(fullPath, FileMode.Create))
                            {
                                f.CopyTo(fs);
                            }

                            string[] filesNames = files.Select(file => file.FileName).ToArray();
                            string fileNames = string.Join(",", filesNames);

                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = "message";
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = f.ContentType;
                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            length--;
                            using (OracleDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    Console.WriteLine(reader.GetString(0)); //Assuming the output is a single string value
                                }
                            }
                            con.Close();


                        }

                    }
                }
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message.ToString());
                Console.WriteLine(ex.Message);
            }
        }

        public DataTable viewMessage(MessageModels message,string customer_user_id, string role)
        {
        string createdName = customer_user_id;
        string roleName = role;
        try
        {
            DataTable dt = new DataTable();

            using (OracleConnection con = new OracleConnection(_connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "COMMON_PROCEDURE";
                    cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 4;
                    cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                    cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = message.complaintId;
                    cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = DBNull.Value;
                    cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                    cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                    cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                    cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                    cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                    cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                    cmd.Parameters.Add("ARG_FILE_TYPE",OracleDbType.Varchar2).Value = string.Empty;
                    cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                    OracleDataAdapter oda = new OracleDataAdapter(cmd);
                    oda.Fill(dt);
                    con.Close();
                }
            }
            return dt;
        }
        catch (Exception ex)
        {
                error.errorLog(ex.Message);
                return null;
        }
    }

        public DataTable viewFile(FileModels file, string customer_user_id, string role)
        {
            string createdName = customer_user_id;
            string roleName = role;
            try
            {
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();               
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();

                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 2;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = file.complaintId;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = file.messageId;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = string.Empty;                        
                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        //string path=@"file:///F:/Share/IRMfiles/";
                        

                        oda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            string path = @"\\172.16.16.120\Share\IRMfiles\";
                            string[] files = Directory.GetFiles(path, $"COMP_ID_{file.complaintId}_*");
                            //int l = f.Length;
                            int j=0;
                            dt1.Columns.Add("FILE_NAME");
                            dt1.Columns.Add("ORIGINAL_NAME");
                            dt1.Columns.Add("FILE_TYPE");
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (i < files.Length)

                                {

                                    byte[] fileBytes = File.ReadAllBytes(files[i]); // Read the file contents as bytes
                                    string base64File = Convert.ToBase64String(fileBytes); // Convert the bytes to base64
                                    dt1.Rows.Add(base64File, dt.Rows[i]["ORIGINAL_NAME"].ToString(), dt.Rows[i]["FILE_TYPE"].ToString());

                                }
                            }
                              
                            }
                            
                        }
                            con.Close();
                        
                        }
                if (dt.Rows.Count > 0)
                {
                    return dt1;
                }
                else
                {
                    return dt;
                }
            }
            catch (Exception ex)
            {
                error.errorLog(ex.Message);
                return null;
            }
        }

      
    }
}
