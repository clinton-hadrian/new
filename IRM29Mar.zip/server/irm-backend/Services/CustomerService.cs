﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace irm_backend.Services
{
    public class CustomerService :ICustomer
    {
        private readonly string _connectionString;
        CreateErrorLog create = new CreateErrorLog();
        public CustomerService(IConfiguration _configuration)
        {
            _connectionString = _configuration.GetConnectionString("CrestCon");
        }

        public DataTable addComplaint(customerModel customer,IFormFile[] files,string customerId,string role)
        {
            int id= int.Parse(customerId);
            string createdName = customerId;
            string roleName = role;
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = id;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = customer.investorName;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = customer.companyName;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = customer.folioDemat;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = customer.pan;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = customer.queryType;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = customer.query;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = customer.problemStatement;
                        //string[] filesNames = files.Select(file => file.FileName).ToArray();
                        //string fileNames = string.Join(",", filesNames);
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = string.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                        if (files.Length>0)
                        {
                            insertFiles(files, dt.Rows[0]["COMPLAINT_ID"].ToString(),createdName,roleName);
                        }
                    }
                }
                return dt;
            }
            catch(Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
           
        }

        public void insertFiles(IFormFile[] files,string complaint_id,string createdName,string roleName)
        {
            int compId = Convert.ToInt32(complaint_id);
            int length = files.Length+1; 
            try
            {
                foreach (var f in files)
                {
                    using (OracleConnection con = new OracleConnection(_connectionString))
                    {
                        using (OracleCommand cmd = con.CreateCommand())
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "COMMON_PROCEDURE";
                            cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 1;
                            cmd.Parameters.Add("ARG_FILE_ID", OracleDbType.Int32).Value = DBNull.Value;
                            cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                            cmd.Parameters.Add("ARG_MESSAGE_ID", OracleDbType.Int32).Value = 0;
                            cmd.Parameters.Add("ARG_MESSAGE", OracleDbType.Varchar2).Value = string.Empty;
                            cmd.Parameters.Add("ARG_ORIGINAL_NAME", OracleDbType.Varchar2).Value = f.FileName;
                            string fileName = "comp_id_"+complaint_id + "_" + length + "" + Path.GetExtension(f.FileName);
                            cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = fileName;


                             string networkPath = @"\\172.16.16.120\Share\IRMfiles\";
                           // string networkPath = @"F:\Share\IRMfiles\";
                            string fullPath = Path.Combine(networkPath, fileName.ToUpper());
                            using (FileStream fs = new FileStream(fullPath, FileMode.Create))
                            {
                                f.CopyTo(fs);
                            }

                            string[] filesNames = files.Select(file => file.FileName).ToArray();
                            string fileNames = string.Join(",", filesNames);

                            cmd.Parameters.Add("ARG_CREATED_NAME", OracleDbType.Varchar2).Value = createdName;
                            cmd.Parameters.Add("ARG_ROLE_NAME", OracleDbType.Varchar2).Value = roleName;
                            cmd.Parameters.Add("ARG_FILE_ORIGIN", OracleDbType.Varchar2).Value = "complaint";
                            cmd.Parameters.Add("ARG_FILE_TYPE", OracleDbType.Varchar2).Value = f.ContentType;
                            cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;
                            OracleDataAdapter oda = new OracleDataAdapter(cmd);
                            length--;
                            using (OracleDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    Console.WriteLine(reader.GetString(0)); //Assuming the output is a single string value
                                }
                            }
                            con.Close();

                            
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                Console.WriteLine(ex.Message);
            }
        }
        

        public DataTable viewComplaint(customerModel customer)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        string id = customer.complaintId.ToString().TrimStart('0');
                        int compId = Convert.ToInt32(id);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 2;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = compId;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value =  String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor, 100).Direction = ParameterDirection.Output;

                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);

                        //string[] fileNameArr = dt.Rows[0]["FILE_NAME"].ToString().Split(',');
                        //dt.Columns.Add("FILE_URLS");
                        //DataRow newRow = dt.NewRow();
                        //newRow["FILE_URLS"] = string.Join(",", fileNameArr.Select(fileName => Path.Combine(@"F:\Share\IRMFiles\", fileName.ToLower().Trim())));
                        //dt.Rows.Add(newRow);
                       
                        con.Close();

                    }
                        
                    
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable recentListComplaint(string customerId)
        {
            int id = int.Parse(customerId);
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = 3;
                        cmd.Parameters.Add("ARG_COMPLAINT_ID", OracleDbType.Int32).Value = DBNull.Value;
                        cmd.Parameters.Add("ARG_CUSTOMER_ID", OracleDbType.Int32).Value = id;
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FOLIO_DEMAT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PAN", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_FILE_NAME", OracleDbType.Varchar2).Value = String.Empty;
                        cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor,100).Direction = ParameterDirection.Output;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                create.errorLog(ex.Message.ToString());
                return null;
            }
        }

        public DataTable updateComplaint(customerModel customer)
        {
            throw new NotImplementedException();
        }

        public DataTable listComplaint(customerModel customer)
        {
            throw new NotImplementedException();
        }

        //public void createErrorLog(string errorMessage)
        //{
        //    string fileNamePath = @"F:\share\IRMErrors";
        //    if (!File.Exists(fileNamePath))
        //    {
        //        using (FileStream fs = File.Create(fileNamePath))
        //        {
        //            byte[] info = new UTF8Encoding(true).GetBytes(DateTime.Now.ToString() + "-" + errorMessage);
        //            fs.Write(info, 0, info.Length);
        //        }

        //    }
        //    else
        //    {
        //        using (StreamWriter sw = File.AppendText(fileNamePath))
        //        {
        //            sw.WriteLine(DateTime.Now.ToString() + "-" + errorMessage);
        //        }
        //    }
        //}

        }
}

// cmd.parameters.add("arg_media", oracledbtype.blob).value = customer.mediadocument;
//var mediadocument = request.form.files.firstordefault();
//var mediadocument = file.;
//if (mediadocument != null)
//{
//    using (var stream = new memorystream())
//    {
//        stream.write(mediadocument, 0, mediadocument.length);
//        cmd.parameters.add("arg_media", oracledbtype.blob).value = stream.toarray();
//    }
//}
//cmd.Parameters.Add("ARG_OUTPUT", OracleDbType.RefCursor,100).Direction = ParameterDirection.Output;
