﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        JwtTokenService jwt = new JwtTokenService();
        #region
        private readonly IMessage Service;
        private readonly IHttpContextAccessor httpContextAccessor;

        public MessageController(IMessage _Service, IHttpContextAccessor _httpContextAccessor)
        {
            Service = _Service;
            httpContextAccessor = _httpContextAccessor;

        }
        #endregion
        [HttpPost]
        [ActionName("postMessage")]
        public IActionResult postMessage([FromForm] MessageModels models, IFormFile[] files)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.postMessage(models, files, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("viewMessage")]
        public IActionResult viewMessage([FromForm] MessageModels message)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.viewMessage(message, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("viewFile")]
        public IActionResult viewFile([FromForm] FileModels file)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.viewFile(file, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("viewMessageFile")]
        public IActionResult viewMessageFile([FromForm] FileModels file)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.viewMessageFile(file, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("closeComplaint")]
        public IActionResult closeComplaint([FromForm] MessageModels models)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.closeComplaint(models, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("checkMessage")]
        public IActionResult checkMessage([FromForm] MessageModels message)
        {


            DataTable dt = Service.checkMessage(message);
            if (dt == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }
               

    }
}
