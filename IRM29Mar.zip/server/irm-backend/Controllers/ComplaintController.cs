﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]

    public class ComplaintController : ControllerBase
    {
        JwtTokenService jwt = new JwtTokenService();
        #region
        private readonly IComplaint Service;
        private readonly IHttpContextAccessor httpContextAccessor;

        public ComplaintController(IComplaint _Service, IHttpContextAccessor _httpContextAccessor)
        {
            Service = _Service;
            httpContextAccessor = _httpContextAccessor;

        }
        #endregion
        [HttpPost]
        [ActionName("addComplaint")]
        public IActionResult addComplaint([FromForm] customerModel customer, IFormFile[] files)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.addComplaint(customer, files, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("viewComplaint")]
        public IActionResult viewComplaint(customerModel customer)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.viewComplaint(customer);
                    if (dt == null)
                    {
                        return StatusCode(500, "Contact the Admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Cannot view your complaint, something went wrong");
                    }

                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }



        [HttpGet]
        [ActionName("recentListComplaint")]
        public IActionResult recentListComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.recentListComplaint(ID);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }



        [HttpPost]
        [ActionName("listComplaint")]
        public IActionResult listComplaint(customerModel customer)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.listComplaint(customer);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "No complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("updateComplaint")]
        public IActionResult updateComplaint(customerModel customer)
        {
            DataTable dt = Service.updateComplaint(customer);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot update complaints");
            }

        }

        

        [HttpGet]
        [ActionName("recentAllComplaint")]
        public IActionResult recentAllComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "USER")
                {
                    DataTable dt = Service.recentAllComplaint();
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpGet]
        [ActionName("closedListComplaint")]
        public IActionResult closedListComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.closedListComplaint(ID);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpGet]
        [ActionName("closedAllComplaint")]
        public IActionResult closedAllComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "USER")
                {
                    DataTable dt = Service.closedAllComplaint();
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpGet]
        [ActionName("company")]
        public IActionResult company()
        {

            DataTable dt = Service.company();
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "no company");
            }

        }

        [HttpGet]
        [ActionName("singleQuery")]
        public IActionResult query()
        {

            DataTable dt = Service.singleQuery();
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "no query");
            }

        }

        [HttpPost]
        [ActionName("multipleQuery")]
        public IActionResult multipleQuery(customerModel customer)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {

                    DataTable dt = Service.multipleQuery(customer);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "no query");
                    }

                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;

        }

        [HttpGet]
        [ActionName("attendListComplaint")]
        public IActionResult attendListComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")
                {
                    DataTable dt = Service.attendListComplaint(ID);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpGet]
        [ActionName("attendAllComplaint")]
        public IActionResult attendAllComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "USER")
                {
                    DataTable dt = Service.attendAllComplaint();
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }
            }
            else
            {
                return null;
            }

            return null;
        }
    }
}
