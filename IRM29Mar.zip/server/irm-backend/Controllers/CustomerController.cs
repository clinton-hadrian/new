﻿using irm_backend.Models;
using irm_backend.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using irm_backend.Services;

namespace irm_backend.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]

    public class CustomerController : ControllerBase
    {
        JwtTokenService jwt = new JwtTokenService();
        #region
        private readonly ICustomer Service;
        private readonly IHttpContextAccessor httpContextAccessor;

        public CustomerController(ICustomer _Service,IHttpContextAccessor _httpContextAccessor)
        {
            Service = _Service;
            httpContextAccessor = _httpContextAccessor;

        }
        #endregion
        [HttpPost]
        [ActionName("addComplaint")]
        public IActionResult addComplaint([FromForm] customerModel customer, IFormFile[] files)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();
 
            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "customer" || role == "user")
                {
                    DataTable dt = Service.addComplaint(customer, files, ID, role);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "Please enter valid details");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            } 
            else
            {
                return null;
            }
      
            return null;
        }

        [HttpPost]
        [ActionName("viewComplaint")]
        public IActionResult viewComplaint(customerModel customer)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "customer" || role == "user")
                {
                    DataTable dt = Service.viewComplaint(customer);
                    if (dt == null)
                    {
                        return StatusCode(500, "Contact the Admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Cannot view your complaint, something went wrong");
                    }

                }
                else
                {
                    return Unauthorized();
                }//e
            }
            else
            {
                return null;
            }
                //  }
                //}
                return null;
            }

       

        [HttpGet]
        [ActionName("recentListComplaint")]
        public IActionResult recentListComplaint()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "customer" || role == "user")
                {
                    DataTable dt = Service.recentListComplaint(ID);
                    if (dt == null)
                    {
                        return StatusCode(500, "Please contact the admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));
                    }
                    else
                    {
                        return StatusCode(404, "Something went wrong, cannot show recent complaints");
                    }
                }
                else
                {
                    return Unauthorized();
                }//e
            }
            else
            {
                return null;
            }
            //  }
            //}
            return null;
        }



        [HttpPost]
        [ActionName("listComplaint")]
        public IActionResult listComplaint(customerModel customer)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();
            //if (!string.IsNullOrEmpty(token))
            //{
            //string[] parts = token.Split(' ');
            //if (parts.Length == 2 && parts[0].Equals("Bearer", StringComparison.OrdinalIgnoreCase))
            //{
            //    string bearerToken = parts[1];

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "customer" || role == "user")
                {
                    DataTable dt = Service.listComplaint(customer);
            if (dt==null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count>0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot list complaint");
            }
                }
                else
                {
                    return Unauthorized();
                }//e
            }
            else
            {
                return null;
            }
            //  }
            //}
            return null;
        }
       
        [HttpPost]
        [ActionName("updateComplaint")]
        public IActionResult updateComplaint(customerModel customer)
        {
            DataTable dt = Service.updateComplaint(customer);
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Something went wrong, cannot update complaints");
            }

        }

    }
}
