﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        JwtTokenService jwt = new JwtTokenService();
        #region
        private readonly IUser Service;
        private readonly IHttpContextAccessor httpContextAccessor;

        public UserController(IUser _Service, IHttpContextAccessor _httpContextAccessor)
        {
            Service = _Service;
            httpContextAccessor = _httpContextAccessor;

        }
        #endregion
        [HttpGet]
        [ActionName("userClosedComplaints")]
        public IActionResult userClosedComplaints()
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "USER")
                {
                    DataTable dt = Service.userClosedComplaints();
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "No closed complaints available");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpPost]
        [ActionName("userClosedList")]
        public IActionResult userClosedList(UserModel user)
        {

            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();

            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "USER")
                {
                    DataTable dt = Service.userClosedList(user);
                    if (dt == null)
                    {

                        return StatusCode(500, "Please contact admin");
                    }
                    else if (dt.Rows.Count > 0)
                    {
                        return StatusCode(200, JsonConvert.SerializeObject(dt));

                    }
                    else
                    {
                        return StatusCode(404, "No closed complaints available");
                    }
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return null;
            }

            return null;
        }

        [HttpGet]
        [ActionName("templates")]
        public IActionResult templates()
        {

            DataTable dt = Service.templates();
            if (dt == null)
            {
                return StatusCode(500, "Please contact the admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "no templates");
            }

        }
    }
}
