﻿using irm_backend.Interfaces;
using irm_backend.Models;
using irm_backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace irm_backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        JwtTokenService jwt = new JwtTokenService();
        private readonly IHttpContextAccessor httpContextAccessor;
        #region
        private readonly IAuth Service;
        private readonly IConfiguration config;

        public AuthController(IAuth _Service, IConfiguration _config, IHttpContextAccessor _httpContextAccessor)
        {
            Service = _Service;
            config = _config;
            httpContextAccessor = _httpContextAccessor;

        }
        #endregion
        [HttpPost]
        [ActionName("sendMobileOTP")]
        //[Authorize(Roles = "customer")]
        public IActionResult sendMobileOTP([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable table = Service.sendMobileOTP(sendMobileOTP);
            if (table == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (table.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(table));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        [HttpPost]
        [ActionName("resendOTP")]
        //[Authorize(Roles = "customer")]

        public IActionResult resendOTP([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable table = Service.resendOTP(sendMobileOTP);
            if (table == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (table.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(table));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        [HttpPost]
        [ActionName("OTPVerification")]
        //[Authorize(Roles = "customer")]

        public IActionResult OTPVerification([FromBody] sendMobileOTPModel sendMobileOTP)
        {


            DataTable dt = Service.OTPVerification(sendMobileOTP);
            if (dt == null)
            {
                return StatusCode(500, "Contact the Admin");
            }
            else if (dt.Rows.Count > 0)
            {
                return Ok(JsonConvert.SerializeObject(dt));
            }
            else
            {
                return StatusCode(404, "Please enter correct OTP");
            }


        }

        [HttpPost]
        [ActionName("addProfile")]
        //[Authorize(Roles = "customer")]

        public IActionResult addProfile([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();
           
            if (jwt.verifyToken(bearerToken))
            {
                var ID = jwt.getItem(bearerToken, 0);
                var role = jwt.getItem(bearerToken, 1);

                if (role == "CUSTOMER" || role == "USER")

                {
                            DataTable dt = Service.addProfile(sendMobileOTP);
                            if (dt == null)
                            {
                                return StatusCode(500, "Please contact the admin");
                            }
                            else if (dt.Rows.Count > 0)
                            {
                                return StatusCode(200, JsonConvert.SerializeObject(dt));
                            }
                            else
                            {
                                return StatusCode(404, "Please Enter Valid Name and Email");
                            }

                }
                else
                {
                    return Unauthorized();
                }

            } //e
            else
            {
                return null;
            }
            //  }
            //}
            return null;

        }

        [HttpGet]
        [ActionName("getProfile")]
        //[Authorize(Roles = "customer")]

        public IActionResult getProfile()
        {
            string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            string bearerToken = token.Replace("Bearer ", "").ToString();
            //if (!string.IsNullOrEmpty(token))
            //{
            //string[] parts = token.Split(' ');
            //if (parts.Length == 2 && parts[0].Equals("Bearer", StringComparison.OrdinalIgnoreCase))
            //{
            //    string bearerToken = parts[1];

            if (jwt.verifyToken(bearerToken))
                    {
                        var ID = jwt.getItem(bearerToken, 0);
                        var role = jwt.getItem(bearerToken,1);

                if (role == "CUSTOMER" || role == "USER")
                {
                            DataTable dt = Service.getProfile(ID);
                            if (dt == null)
                            {
                                return StatusCode(500, "Please contact the admin");
                            }
                            else if (dt.Rows.Count > 0)
                            {

                                return StatusCode(200, JsonConvert.SerializeObject(dt));
                            }
                            else
                            {
                                return StatusCode(404, "Please Enter Valid Name and Email");
                            }

                        }
                        else
                        {
                            return Unauthorized();
                        }

                    } //e
                    else
                    {
                        return null;
                    }
              //  }
            //}
            return null;


        }

        [HttpPost]
        [ActionName("sendCredentials")]
        //[Authorize(Roles = "customer")]
        public IActionResult sendCredentials([FromBody] sendMobileOTPModel sendMobileOTP)
        {
            DataTable table = Service.sendCredentials(sendMobileOTP);
            if (table == null)
            {

                return StatusCode(500, "Please contact admin");
            }
            else if (table.Rows.Count > 0)
            {
                return StatusCode(200, JsonConvert.SerializeObject(table));

            }
            else
            {
                return StatusCode(404, "Please enter valid details");
            }
        }

        //[HttpPost]
        //[ActionName("updateProfile")]
        ////[Authorize(Roles = "customer")]

        //public IActionResult updateProfile([FromBody] sendMobileOTPModel sendMobileOTP)
        //{
        //    string token = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
        //    if (!string.IsNullOrEmpty(token))
        //    {
        //        string[] parts = token.Split(' ');
        //        if (parts.Length == 2 && parts[0].Equals("Bearer", StringComparison.OrdinalIgnoreCase))
        //        {
        //            string bearerToken = parts[1];

        //            if (jwt.verifyToken(bearerToken))
        //            {
        //                var claims = jwt.getItem(bearerToken);
        //                var role = claims.Value.ElementAt(0);
        //                if (role == "customer" || role == "user")
        //                {
        //                    DataTable dt = Service.updateProfile(sendMobileOTP);
        //                    if (dt == null)
        //                    {
        //                        return StatusCode(500, "Please contact the admin");
        //                    }
        //                    else if (dt.Rows.Count > 0)
        //                    {
        //                        return StatusCode(200, JsonConvert.SerializeObject(dt));
        //                    }
        //                    else
        //                    {
        //                        return StatusCode(404, "Please Enter Valid Name and Email");
        //                    }
        //                }
        //                else
        //                {
        //                    return Unauthorized();
        //                }

        //            } //e
        //            else
        //            {
        //                return null;
        //            }
        //        }
        //    }
        //    return null;

        //}
    }
}

//// Create claims identity for the user
//var claims = new[]
//{
//            new Claim(ClaimTypes.NameIdentifier, dt.Rows[0]["ID"].ToString()),
//            new Claim(ClaimTypes.Role, "user")
//        };

//// Generate a JWT token
//var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("secretKEEE0123456789abcdefghijklmnopqrstuvwxyz"));
//var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
//var token = new JwtSecurityToken(
//    //issuer: "http://localhost:58535/",
//    //audience: "http://localhost:58535/",
//    claims: claims,
//    expires: DateTime.Now.AddDays(1),
//    signingCredentials: creds
//);

//// Return token to the client
//return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
////return StatusCode(200, JsonConvert.SerializeObject(dt));

