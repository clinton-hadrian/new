import {
  ADD_COMPLAINT_FAILED,
  ADD_COMPLAINT_REQUEST,
  ADD_COMPLAINT_RESET,
  ADD_COMPLAINT_SUCCESS,
  CLOSED_ALL_COMPLAINT_FAILED,
  CLOSED_ALL_COMPLAINT_REQUEST,
  CLOSED_ALL_COMPLAINT_RESET,
  CLOSED_ALL_COMPLAINT_SUCCESS,
  CLOSED_LIST_COMPLAINT_FAILED,
  CLOSED_LIST_COMPLAINT_REQUEST,
  CLOSED_LIST_COMPLAINT_RESET,
  CLOSED_LIST_COMPLAINT_SUCCESS,
  COMPANY_FAILED,
  COMPANY_REQUEST,
  COMPANY_RESET,
  COMPANY_SUCCESS,
  LIST_COMPLAINT_FAILED,
  LIST_COMPLAINT_REQUEST,
  LIST_COMPLAINT_SUCCESS,
  MULTIPLE_QUERY_FAILED,
  MULTIPLE_QUERY_REQUEST,
  MULTIPLE_QUERY_RESET,
  MULTIPLE_QUERY_SUCCESS,
  SINGLE_QUERY_FAILED,
  SINGLE_QUERY_REQUEST,
  SINGLE_QUERY_RESET,
  SINGLE_QUERY_SUCCESS,
  RECENT_ALL_COMPLAINT_FAILED,
  RECENT_ALL_COMPLAINT_REQUEST,
  RECENT_ALL_COMPLAINT_RESET,
  RECENT_ALL_COMPLAINT_SUCCESS,
  RECENT_LIST_COMPLAINT_FAILED,
  RECENT_LIST_COMPLAINT_REQUEST,
  RECENT_LIST_COMPLAINT_RESET,
  RECENT_LIST_COMPLAINT_SUCCESS,
  UPDATE_COMPLAINT_FAILED,
  UPDATE_COMPLAINT_REQUEST,
  UPDATE_COMPLAINT_SUCCESS,
  VIEW_COMPLAINT_FAILED,
  VIEW_COMPLAINT_REQUEST,
  VIEW_COMPLAINT_RESET,
  VIEW_COMPLAINT_SUCCESS,
  ATTEND_LIST_COMPLAINT_REQUEST,
  ATTEND_LIST_COMPLAINT_SUCCESS,
  ATTEND_LIST_COMPLAINT_FAILED,
  ATTEND_LIST_COMPLAINT_RESET,
  ATTEND_ALL_COMPLAINT_REQUEST,
  ATTEND_ALL_COMPLAINT_SUCCESS,
  ATTEND_ALL_COMPLAINT_FAILED,
  ATTEND_ALL_COMPLAINT_RESET,
} from "../constants/complaintConstant";

export const addComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case ADD_COMPLAINT_REQUEST:
      return { loading: true };
    case ADD_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case ADD_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case ADD_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const viewComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case VIEW_COMPLAINT_REQUEST:
      return { loading: true };
    case VIEW_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case VIEW_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case VIEW_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const recentListComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case RECENT_LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case RECENT_LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case RECENT_LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case RECENT_LIST_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const attendListComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case ATTEND_LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case ATTEND_LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case ATTEND_LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case ATTEND_LIST_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const attendAllComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case ATTEND_ALL_COMPLAINT_REQUEST:
      return { loading: true };
    case ATTEND_ALL_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case ATTEND_ALL_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case ATTEND_ALL_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const listComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const updateComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case UPDATE_COMPLAINT_REQUEST:
      return { loading: true };
    case UPDATE_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case UPDATE_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const recentAllComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case RECENT_ALL_COMPLAINT_REQUEST:
      return { loading: true };
    case RECENT_ALL_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case RECENT_ALL_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case RECENT_ALL_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const closedListComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case CLOSED_LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case CLOSED_LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case CLOSED_LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case CLOSED_LIST_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const closedAllComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case CLOSED_ALL_COMPLAINT_REQUEST:
      return { loading: true };
    case CLOSED_ALL_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case CLOSED_ALL_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case CLOSED_ALL_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const companyReducer = (state = {}, action: any) => {
  switch (action.type) {
    case COMPANY_REQUEST:
      return { loading: true };
    case COMPANY_SUCCESS:
      return { loading: false, response: action.payload };
    case COMPANY_FAILED:
      return { loading: false, error: action.payload };
    case COMPANY_RESET:
      return {};
    default:
      return state;
  }
};

export const singleQueryReducer = (state = {}, action: any) => {
  switch (action.type) {
    case SINGLE_QUERY_REQUEST:
      return { loading: true };
    case SINGLE_QUERY_SUCCESS:
      return { loading: false, response: action.payload };
    case SINGLE_QUERY_FAILED:
      return { loading: false, error: action.payload };
    case SINGLE_QUERY_RESET:
      return {};
    default:
      return state;
  }
};

export const multipleQueryReducer = (state = {}, action: any) => {
  switch (action.type) {
    case MULTIPLE_QUERY_REQUEST:
      return { loading: true };
    case MULTIPLE_QUERY_SUCCESS:
      return { loading: false, response: action.payload };
    case MULTIPLE_QUERY_FAILED:
      return { loading: false, error: action.payload };
    case MULTIPLE_QUERY_RESET:
      return {};
    default:
      return state;
  }
};