import React from "react";
import { useDispatch } from "react-redux";
import {
  SEND_MOBILE_OTP_FAILED,
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS,
  RESEND_OTP_REQUEST,
  RESEND_OTP_SUCCESS,
  RESEND_OTP_FAILED,
  GET_PROFILE_FAILED,
  GET_PROFILE_SUCCESS,
  GET_PROFILE_REQUEST,
  SEND_MOBILE_OTP_RESET,
  RESEND_OTP_RESET,
  VERIFY_MOBILE_OTP_RESET,
  GET_PROFILE_RESET,
  ADD_PROFILE_RESET,
  UPDATE_PROFILE_RESET,
  SEND_CREDENTIALS_SUCCESS,
  SEND_CREDENTIALS_FAILED,
  SEND_CREDENTIALS_RESET,
  SEND_CREDENTIALS_REQUEST,
} from "../constants/authConstant";

import {
  VERIFY_MOBILE_OTP_FAILED,
  VERIFY_MOBILE_OTP_REQUEST,
  VERIFY_MOBILE_OTP_SUCCESS,
} from "../constants/authConstant";

import {
  ADD_PROFILE_REQUEST,
  ADD_PROFILE_SUCCESS,
  ADD_PROFILE_FAILED,
} from "../constants/authConstant";
import {
  UPDATE_COMPLAINT_FAILED,
  UPDATE_COMPLAINT_REQUEST,
  UPDATE_COMPLAINT_SUCCESS,
} from "../constants/complaintConstant";

export const sendMobileOTPReducer = (state = {}, action: any) => {
  switch (action.type) {
    case SEND_MOBILE_OTP_REQUEST:
      return { loading: true };

    case SEND_MOBILE_OTP_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case SEND_MOBILE_OTP_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case SEND_MOBILE_OTP_RESET:
      return {};

    default:
      return state;
  }
};

export const addProfileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case ADD_PROFILE_REQUEST:
      return { loading: true };

    case ADD_PROFILE_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case ADD_PROFILE_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case ADD_PROFILE_RESET:
      return {};

    default:
      return state;
  }
};

export const updateProfileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case UPDATE_COMPLAINT_REQUEST:
      return { loading: true };

    case UPDATE_COMPLAINT_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case UPDATE_COMPLAINT_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case UPDATE_PROFILE_RESET:
      return {};

    default:
      return state;
  }
};

export const getProfileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case GET_PROFILE_REQUEST:
      return { loading: true };

    case GET_PROFILE_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case GET_PROFILE_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case GET_PROFILE_RESET:
      return {};

    default:
      return state;
  }
};

export const verifyMobileOTPReducer = (state = {}, action: any) => {
  switch (action.type) {
    case VERIFY_MOBILE_OTP_REQUEST:
      return { loading: true };

    case VERIFY_MOBILE_OTP_SUCCESS:
      return { loading: false, response: action.payload };

    case VERIFY_MOBILE_OTP_FAILED:
      return { loading: false, error: action.payload };

    case VERIFY_MOBILE_OTP_RESET:
      return {};

    default:
      return state;
  }
};

export const resendOTPReducer = (state = {}, action: any) => {
  switch (action.type) {
    case RESEND_OTP_REQUEST:
      return { loading: true };

    case RESEND_OTP_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case RESEND_OTP_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case RESEND_OTP_RESET:
      return {};

    default:
      return state;
  }
};

export const sendCredentialsReducer = (state = {}, action: any) => {
  switch (action.type) {
    case SEND_CREDENTIALS_REQUEST:
      return { loading: true };

    case SEND_CREDENTIALS_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case SEND_CREDENTIALS_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    case SEND_CREDENTIALS_RESET:
      return {};

    default:
      return state;
  }
};
