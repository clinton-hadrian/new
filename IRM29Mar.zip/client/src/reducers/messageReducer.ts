import {
  POST_FILE_FAILED,
  POST_FILE_REQUEST,
  POST_FILE_RESET,
  POST_FILE_SUCCESS,
  VIEW_FILE_REQUEST,
  VIEW_FILE_SUCCESS,
  VIEW_FILE_FAILED,
  VIEW_FILE_RESET,
  POST_MESSAGE_REQUEST,
  POST_MESSAGE_SUCCESS,
  POST_MESSAGE_FAILED,
  VIEW_MESSAGE_FAILED,
  VIEW_MESSAGE_REQUEST,
  VIEW_MESSAGE_SUCCESS,
  VIEW_MESSAGE_RESET,
  CLOSE_COMPLAINT_SUCCESS,
  CLOSE_COMPLAINT_RESET,
  CLOSE_COMPLAINT_FAILED,
  CLOSE_COMPLAINT_REQUEST,
  CHECK_MESSAGE_REQUEST,
  CHECK_MESSAGE_SUCCESS,
  CHECK_MESSAGE_FAILED,
  CHECK_MESSAGE_RESET,
  VIEW_MESSAGE_FILE_REQUEST,
  VIEW_MESSAGE_FILE_SUCCESS,
  VIEW_MESSAGE_FILE_RESET,
  VIEW_MESSAGE_FILE_FAILED,
} from "../constants/messageConstant";

export const postFileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case POST_FILE_REQUEST:
      return { loading: true };
    case POST_FILE_SUCCESS:
      return { loading: false, response: action.payload };
    case POST_FILE_FAILED:
      return { loading: false, error: action.payload };
    case POST_FILE_RESET:
      return {};
    default:
      return state;
  }
};

export const viewFileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case VIEW_FILE_REQUEST:
      return { loading: true };
    case VIEW_FILE_SUCCESS:
      return { loading: false, response: action.payload };
    case VIEW_FILE_FAILED:
      return { loading: false, error: action.payload };
    case VIEW_FILE_RESET:
      return {};
    default:
      return state;
  }
};

export const viewMessageFileReducer = (state = {}, action: any) => {
  switch (action.type) {
    case VIEW_MESSAGE_FILE_REQUEST:
      return { loading: true };
    case VIEW_MESSAGE_FILE_SUCCESS:
      return { loading: false, response: action.payload };
    case VIEW_MESSAGE_FILE_FAILED:
      return { loading: false, error: action.payload };
    case VIEW_MESSAGE_FILE_RESET:
      return {};
    default:
      return state;
  }
};

export const postMessageReducer = (state = {}, action: any) => {
  switch (action.type) {
    case POST_MESSAGE_REQUEST:
      return { loading: true };
    case POST_MESSAGE_SUCCESS:
      return { loading: false, response: action.payload };
    case POST_MESSAGE_FAILED:
      return { loading: false, error: action.payload };
    case VIEW_FILE_RESET:
      return {};
    default:
      return state;
  }
};

export const viewMessageReducer = (state = {}, action: any) => {
  switch (action.type) {
    case VIEW_MESSAGE_REQUEST:
      return { loading: true };
    case VIEW_MESSAGE_SUCCESS:
      return { loading: false, response: action.payload };
    case VIEW_MESSAGE_FAILED:
      return { loading: false, error: action.payload };
    case VIEW_MESSAGE_RESET:
      return {};
    default:
      return state;
  }
};

export const closeComplaintReducer = (state = {}, action: any) => {
  switch (action.type) {
    case CLOSE_COMPLAINT_REQUEST:
      return { loading: true };
    case CLOSE_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case CLOSE_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    case CLOSE_COMPLAINT_RESET:
      return {};
    default:
      return state;
  }
};

export const checkMessageReducer = (state = {}, action: any) => {
  switch (action.type) {
    case CHECK_MESSAGE_REQUEST:
      return { loading: true };
    case CHECK_MESSAGE_SUCCESS:
      return { loading: false, response: action.payload };
    case CHECK_MESSAGE_FAILED:
      return { loading: false, error: action.payload };
    case CHECK_MESSAGE_RESET:
      return {};
    default:
      return state;
  }
};
