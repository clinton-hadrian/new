import { TEMPLATE_FAILED, TEMPLATE_REQUEST, TEMPLATE_RESET, TEMPLATE_SUCCESS, USER_CLOSED_COMPLAINTS_FAILED, USER_CLOSED_COMPLAINTS_REQUEST, USER_CLOSED_COMPLAINTS_RESET, USER_CLOSED_COMPLAINTS_SUCCESS, USER_CLOSED_LIST_FAILED, USER_CLOSED_LIST_REQUEST, USER_CLOSED_LIST_RESET, USER_CLOSED_LIST_SUCCESS } from "../constants/userConstant";

export const userClosedComplaintsReducer = (state = {}, action: any) => {
    switch (action.type) {
      case USER_CLOSED_COMPLAINTS_REQUEST:
        return { loading: true };
      case USER_CLOSED_COMPLAINTS_SUCCESS:
        return { loading: false, response: action.payload };
      case USER_CLOSED_COMPLAINTS_FAILED:
        return { loading: false, error: action.payload };
      case USER_CLOSED_COMPLAINTS_RESET:
        return {};
      default:
        return state;
    }
  };

  export const userClosedListReducer = (state = {}, action: any) => {
    switch (action.type) {
      case USER_CLOSED_LIST_REQUEST:
        return { loading: true };
      case USER_CLOSED_LIST_SUCCESS:
        return { loading: false, response: action.payload };
      case USER_CLOSED_LIST_FAILED:
        return { loading: false, error: action.payload };
      case USER_CLOSED_LIST_RESET:
        return {};
      default:
        return state;
    }
  };

  export const templateReducer = (state = {}, action: any) => {
    switch (action.type) {
      case TEMPLATE_REQUEST:
        return { loading: true };
      case TEMPLATE_SUCCESS:
        return { loading: false, response: action.payload };
      case TEMPLATE_FAILED:
        return { loading: false, error: action.payload };
      case TEMPLATE_RESET:
        return {};
      default:
        return state;
    }
  };