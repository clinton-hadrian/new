import React, { Fragment, useEffect, useState } from "react";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import VpnKeyIcon from "@mui/icons-material/VpnKey";
import {
  Button,
  Box,
  Typography,
  CardContent,
  TextField,
  Paper,
  Grid,
  InputAdornment,
} from "@mui/material";

import * as Yup from "yup";
import phone from "yup-phone";
import { ErrorMessage, useFormik } from "formik";
import IconButton from "@mui/material/IconButton";
import {
  Email,
  LockOpen,
  Visibility,
  VisibilityOff,
  ArrowForward,
  BadgeOutlined,
} from "@mui/icons-material";
import _ from "lodash";
import { sendCredentialsAction } from "../../actions/authAction";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import SnackBar from "../../components/Snackbar";

interface props {
  email: string;
  password: string;
}

const otpBorder = {
  width: "20%",
  margin: "0 5px",
  borderRadius: "15px",
  borderColor: "#a084dc",
  borderStyle: "solid",
  borderWidth: "2px",
  max: "9",
  min: "0",
  textAlign: "center",
};




const UserLogin = () => {

  const navigate=useNavigate();

  const dispatch:any=useDispatch();
  const sendCredentialsSelector=useSelector((state:any)=>state.sendCredentials);

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };


  const [showPassword, setShowPassword] = React.useState(false);
  const [otpVisible, setOTPVisible] = useState<Boolean>(false);
  const [otpError, setOTPError] = useState<string>("");
  const [snackOpen,setSnackOpen]=useState(true);
 

  const userFormik = useFormik({
    initialValues: {
      userName: "",
      password: "",
    },
    validationSchema: Yup.object().shape({
      userName: Yup.string()
        .required("Please enter the user name "),
    
      password: Yup.string().required("Password Required"),
    }),
    onSubmit: (value) => {
      const form=new FormData();
      form.append("userName",value.userName);
      form.append("password",value.password);
      dispatch(sendCredentialsAction(form));
      console.log(value);
      userFormik.resetForm({
        values:{
          userName:"",
          password:""
        },
    });
    },

    
  });

  useEffect(()=>{
    if(sendCredentialsSelector && sendCredentialsSelector.response && sendCredentialsSelector.response[0]["TOKEN"]){
      navigate("dashboard")
    }
  },[navigate,dispatch,sendCredentialsSelector.response])

  return (
    <Fragment>
      {sendCredentialsSelector &&  sendCredentialsSelector.error &&
        <SnackBar severity="error" handleClose={()=>setSnackOpen(false)} open={snackOpen} message={"Wrong username or password"}  />}
      <Paper
        style={{
           borderRadius: "20px",
          // borderColor: "black",
          // borderStyle: "Solid",
          // borderWidth: "2px",
          marginTop:"16%",
          marginBottom:"19%"
        }}
        elevation={20}
        sx={{ p: 2 }}>
        <CardContent sx={{ textAlign: "center" }}>
          <Box
            sx={{
              "& MuiButtonBase-root ": {
                margin: 1,
                width: "100%",
                position: "relative",
              },
              "& .MuiTypography-root ": {
                textAlign: "left",
                mb: 4,
              },
              position: "relative",
            }}>
            <Typography
              style={{
                fontFamily: "Inter",
                fontSize: "1.8rem",
                fontWeight: "bold",
              }}
              variant="h4"
              gutterBottom>
              Welcome back..
              <Typography
                style={{
                  fontFamily: "Inter",
                  fontSize: "1rem",
                  fontWeight: 300,
                  marginTop: 5,
                }}
                variant="h1"
                gutterBottom>
                Please enter you email and password
              </Typography>
            </Typography>
            <TextField
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <BadgeOutlined />
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 2 }}
              id="userName"
              label="User Name"
              placeholder="Enter User name"
              name="userName"
              value={userFormik.values.userName}
              onChange={(e)=>{
                userFormik.setFieldValue("userName",(e.target.value).toUpperCase())
              }}
              onBlur={userFormik.handleBlur}
              error={Boolean(
                userFormik.errors.userName && userFormik.touched.userName
              )}
              helperText={userFormik.touched.userName && userFormik.errors.userName}
              fullWidth
            />

            <TextField
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockOpen />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment sx={{cursor:"pointer"}} onClick={handleClickShowPassword}  position="end">
                     {showPassword ? <VisibilityOff /> : <Visibility />}
                  </InputAdornment>
                ),
              }}
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={userFormik.values.password}
              name="password"
              onBlur={userFormik.handleBlur}
              onChange={(e) => {
                userFormik.setFieldValue("password", e.target.value);
              }}
              placeholder="Enter password"
              fullWidth
              error={Boolean(
                userFormik.touched.password && userFormik.errors.password
              )}
              helperText={
                userFormik.touched.password && userFormik.errors.password
              }
              label="Password"
            />
             <Grid container>
              <Grid item xs={6}  md={6}>
              {/* <Box
              sx={{
                justifyContent: "left",
                alignItems: "start",
                alignContent: "start",
                textAlign: "start ",
                mt: 3,
              }}>
              
                  
                <Button variant="text">Forgot password?</Button>
             
             
            </Box> */}

              </Grid>
              <Grid item xs={6} md={6}>
              <Box
              sx={{
                justifyContent: "right",
                alignItems: "end",
                alignContent: "end",
                textAlign: "end ",
                mt: 2,
              }}>
              <Button
               
                sx={{
                  borderRadius: "25px",
                }}
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={()=>userFormik.handleSubmit()}
                endIcon={<ArrowForward />}>
                  
                Login
             
              </Button>
            </Box>

              </Grid>
             </Grid>
           
          </Box>
        </CardContent>
      </Paper>
    </Fragment>
  );
};
export default UserLogin;
