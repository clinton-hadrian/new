import React, { Fragment, useEffect, useRef, useState } from "react";
import { Box, Tooltip, Typography } from "@mui/material";
import Grid from "@mui/material/Grid";
import {
  Sidebar,
  Menu,
  MenuItem,
  SubMenu,
  useProSidebar,
  
} from "react-pro-sidebar";
import { AssignmentTurnedInOutlined, Close, CloseOutlined, DashboardOutlined, ForkLeftOutlined, MenuOpenOutlined, PendingActionsOutlined } from "@mui/icons-material";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import { useNavigate } from "react-router-dom";
import ListComplaint from "../../components/ListComplaint";
import { useDispatch, useSelector } from "react-redux";
import ComplaintsList from "../../components/ComplaintsList";
import ViewComplaint from "../../components/ViewComplaint";
import Dashboard from "../../components/Dashboard";
import _ from "lodash";
import ClosedComplaintList from "../../components/ClosedComplaintList";
import { companyAction, multipleQueryAction, singleQueryAction } from "../../actions/complaintAction";
import { userCloseComplaintAction } from "../../actions/messageAction";
import { userClosedComplaintsAction } from "../../actions/userAction";
import UserClosedList from "../../components/UserClosedList";
import QueryTabs from "../../components/QueryTabs";
const headTypo = { fontFamily: "Nunito", fontSize: "1.8rem", fontWeight: 500 };

const UserView = () => {
  const navigate = useNavigate();

  const dispatch:any=useDispatch();
  const recentAllComplaintSelector = useSelector(
    (state: any) => state.recentAllComplaint
  );
  const sendCredentialsSelector=useSelector((state:any)=>state.sendCredentials);
  const viewComplaintSelector=useSelector((state:any)=>state.viewComplaint);
  const viewMessageSelector = useSelector((state: any) => state.viewMessage);
  const postMessageSelector = useSelector((state: any) => state.postMessage);
  const userClosedComplaintsSelector = useSelector((state: any) => state.userCloseComplaints);
  const closeComplaintSelector = useSelector((state: any) => state.closeComplaint);
  const closedAllComplaintSelector = useSelector((state: any) => state.closedAllComplaint);





  React.useEffect(() => {
    
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0] &&
      sendCredentialsSelector.response[0]["TOKEN"] 
      
    ) {
     dispatch(companyAction());
     dispatch(singleQueryAction());
     dispatch(userClosedComplaintsAction());
    }
 
  }, [
    sendCredentialsSelector &&
    sendCredentialsSelector.response &&
    sendCredentialsSelector.response[0] ,
   
  ]);

  React.useEffect(() => {
    
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0] &&
      sendCredentialsSelector.response[0]["TOKEN"] 
      
    ) {
   
     dispatch(userClosedComplaintsAction());
    }
 
  }, [
   
    sendCredentialsSelector.response, closeComplaintSelector.response,closedAllComplaintSelector.response
   
  ]);


  

  const { collapseSidebar, toggled, toggleSidebar,collapsed } = useProSidebar();
  const toggle = () => {
    toggleSidebar();
    if (toggled) {
      console.log(true);
      collapseSidebar();
    } else {
      console.log(false);
      collapseSidebar();
    }
  };

  
  useEffect(() => {
    if (sendCredentialsSelector && sendCredentialsSelector.response && !sendCredentialsSelector.response[0]["TOKEN"]) {
      navigate("/user");
    }
  }, [navigate]);

  const [hoveredItem, setHoveredItem] = useState(null);

  const handleItemHover = (item:any) => {
    setHoveredItem(item);
  };
  const [open, setOpen] = useState("dashboard");
  function togg(name: string) {
    if (name == "completed") {
      setOpen("completed");
    } else if (name == "view") {
      setOpen("view");
    } else if (name == "complaint") {
      setOpen("complaint");
    } else if (name == "dashboard") {
      setOpen("dashboard");
    }else if (name == "closedView") {
      setOpen("closedView");
    }  
    else if (name == "closedList") {
      setOpen("closedList");
    }  
  }
 

  useEffect(() => {
    const handleClick = (event:MouseEvent) => {
      const targetElement = event.target as Element;
  if (toggled) {
    toggle(); // toggle sidebar state
  }
    };
    const sidebarElements = document.getElementsByClassName("clickToggle");
  for (let i = 0; i < sidebarElements.length; i++) {
    sidebarElements[i].addEventListener("click", handleClick as EventListener);
  }

  return () => {
    for (let i = 0; i < sidebarElements.length; i++) {
      sidebarElements[i].removeEventListener("click", handleClick as EventListener);
    }
  };
}, [toggled, toggleSidebar]);


  return (
    <Fragment  >
            <Box
           
        sx={{
          position: "inline-flex",
          direction: "row",
          marginX: 1,
          marginY: 1,
          overflow: "auto",
          justifyContent: "center",
          p: 1,
        }}
        style={{}}>
          <Box sx={{position:"fixed",left:"0px",top:"10%",zIndex:1}}>
      <Sidebar 
      
            backgroundColor="#0A2647"
              collapsedWidth="70px"
              defaultCollapsed={true}
              style={{ height: "100vh" }}>
              <Menu>
                <MenuItem
                onClick={()=>{
                 
                    toggle();
                  
                  
                }}
                 onMouseEnter={() => handleItemHover("Item 1")}
                 onMouseLeave={() => handleItemHover(null)}
                  style={{
                    textAlign: "center",
                    alignContent: "center",
                    width: toggled ? 270 : 50, // Set the width of the MenuItem component based on the collapsed state
                  }}
                  icon={
                    toggled ? (
                      <CloseOutlined fontSize="large" style={{
                       
                        color: hoveredItem === "Item 1" ? "#555" : "#fff",
                      }} />
                    ) : (
                      <Tooltip  title="open" placement="right">
                      <KeyboardDoubleArrowRightIcon fontSize="large"
                      style={{
                      
                        color: hoveredItem === "Item 1" ? "#555" : "#fff",
                      }}
                      />
                      </Tooltip>
                    )
                  }
               >
                
                  <Typography sx={{color: hoveredItem === "Item 1" ? "#555" : "#fff"}}>Welcome, {sendCredentialsSelector && sendCredentialsSelector.response && _.capitalize(sendCredentialsSelector.response[0]["USERNAME"])} </Typography>
                </MenuItem>
                <MenuItem 
                onClick={()=>{
                  togg("dashboard");
                }}
                 onMouseEnter={() => handleItemHover("Item 2")}
                 onMouseLeave={() => handleItemHover(null)}
                  style={{
                    textAlign: "center",
                    alignContent: "center",
                    width: toggled ? 270 : 50, 
                  }}
                  icon={
                    <Tooltip title="Dashboard" placement="right">
                      <DashboardOutlined fontSize="large"  style={{
                        color: hoveredItem === "Item 2" ? "#555" : "#fff",
                      }} />
                      </Tooltip>
                  } >
                
                  <Typography sx={{color: hoveredItem === "Item 2" ? "#555" : "#fff"}}>Dashboard</Typography>
                </MenuItem>
                <MenuItem 
                onClick={()=>{
                  togg("view");
                }}
                 onMouseEnter={() => handleItemHover("view")}
                 onMouseLeave={() => handleItemHover(null)}
                  style={{
                    textAlign: "center",
                    alignContent: "center",
                    width: toggled ? 270 : 50, 
                  }}
                  icon={
                    <Tooltip title="Pending Complaints" placement="right">
                      <PendingActionsOutlined  fontSize="large" style={{
                        color: hoveredItem === "view" ? "#555" : "#fff",
                      }} />
                      </Tooltip>
                  } >
                
                  <Typography sx={{color: hoveredItem === "view" ? "#555" : "#fff"}}>Pending Complaints</Typography>
                </MenuItem>
                <MenuItem 
                onClick={()=>{
                  togg("closedView");
                }}
                 onMouseEnter={() => handleItemHover("closed")}
                 onMouseLeave={() => handleItemHover(null)}
                  style={{
                    textAlign: "center",
                    alignContent: "center",
                    width: toggled ? 270 : 50, 
                  }}
                  icon={
                    <Tooltip title="Closed Complaints" placement="right">
                      <AssignmentTurnedInOutlined fontSize="large" style={{
                        color: hoveredItem === "closed" ? "#555" : "#fff",
                      }} />
                      </Tooltip>
                  } >
                
                  <Typography sx={{color: hoveredItem === "closed" ? "#555" : "#fff"}}>Closed Complaints</Typography>
                </MenuItem>
              </Menu>
            </Sidebar>
      </Box>
      <Grid container  >

        <Grid item xs={12} md={8}>
        <Box className="clickToggle"  id="comp-container"
              sx={{
                display: "flex",
                direction: "row",
                p: 2,
                ml: 8,
                height:"85vh",
                overflow: "auto",
                maxHeight: "102vh",
                zIndex:-1
              }}>
          {open=="dashboard" && <Dashboard onClick={togg}/>}
          {open == "view" && <ComplaintsList onClick={togg} />}
              {open == "complaint" && <QueryTabs />}
              {open== "closedView" && <ClosedComplaintList onClick={togg} />}
              {open== "closedList" && <UserClosedList onClick={togg} />}
              </Box>
        </Grid>

        <Grid sx={{ borderLeft: "solid", borderWidth: "1px" }}
            item
            xs={12}
            md={4}>
            <Box
              className="scroll clickToggle"
              sx={{
                height:"85vh",
                display: "flex",
                flex: 1,
                direction: "row",
                justifyContent: "center",
                p: 1,
                ml: 2,
                overflow: "hidden",
                maxHeight: "102vh",
              }}>
          <ListComplaint onClick={togg} />
          </Box>
        </Grid>
      </Grid>
     </Box>
    </Fragment>
  );
};

export default UserView;


