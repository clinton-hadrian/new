import { useState, Dispatch, useEffect, Fragment } from "react";
import _ from "lodash";
import { Fab, Box, Grid } from "@mui/material";
import AddProfile from "../../components/AddProfile";
import ViewComplaint from "../../components/ViewComplaint";
import ListComplaint from "../../components/ListComplaint";
import { Add } from "@mui/icons-material";
import ComplaintsList from "../../components/ComplaintsList";
import AddComplaint from "../../components/AddComplaint";
import { useDispatch, useSelector } from "react-redux";
import SnackBar from "../../components/Snackbar";
import { getProfileAction } from "../../actions/authAction";
import { useNavigate } from "react-router-dom";
import { companyAction, singleQueryAction, recentAllComplaintAction, viewComplaintAction, multipleQueryAction } from "../../actions/complaintAction";
import { log } from "console";
import {
  resetAttendListComplaintAction,
  resetClosedListComplaintAction,
  resetRecentAllComplaintAction,
  resetRecentListComplaintAction,
  resetViewComplaintAction,
} from "../../actions/resetAction";
import Swal from "sweetalert2";
import { viewFileAction } from "../../actions/messageAction";
import ClosedComplaintList from "../../components/ClosedComplaintList";
import QueryTabs from "../../components/QueryTabs";

interface MyState {
  addComplaint: {
    loading: boolean;
    response?: any;
    error?: any;
  };
  // AddProfileSelector verifyOTPSelector getProfileSelector
  viewComplaint: {
    loading: boolean;
    response?: any;
    error?: any;
  };
}

const Complaint = () => {
  const dispatch: Dispatch<any> = useDispatch();
  const navigate = useNavigate();
  const AddProfileSelector = useSelector((state: any) => state.addProfile);
  const verifyOTPSelector = useSelector((state: any) => state.verifyMobileOTP);
  const getProfileSelector = useSelector((state: any) => state.getProfile);
  const addComplaintSelector = useSelector(
    (state: MyState) => state.addComplaint
  );
  const viewComplaintSelector = useSelector(
    (state: MyState) => state.viewComplaint
  );
const closeComplaintSelector=useSelector((state:any)=>state.closeComplaint);
const viewMessageSelector = useSelector((state: any) => state.viewMessage);
const verifyMobileOTPSelector = useSelector(
  (state: any) => state.verifyMobileOTP
);


  const [addProfile, setAddProfile] = useState(
    verifyOTPSelector.response &&
      verifyOTPSelector.response[0]["EXISTUSER"] == "TRUE" || AddProfileSelector && AddProfileSelector.response && AddProfileSelector.response[0]["ID"]
      ? false
      : true
  );
  const [open, setOpen] = useState("add");
  const [snackBarProfile, setSnackBarProfile] = useState(false);

  function toggle(name: string) {
    if (name == "complaint") {
      setOpen("complaint");
    } else if (name == "view") {
      setOpen("view");
    } else if (name == "add") {
      setOpen("add");
    }else if (name == "closedView") {
      setOpen("closedView");
    }
  }

  function boggle(name: boolean) {
    setSnackBarProfile(name);
  }

  useEffect(() => {
    if(verifyMobileOTPSelector && verifyMobileOTPSelector.response && !verifyMobileOTPSelector.response[0]["TOKEN"]){
      navigate("/");
        }
  }, [navigate]);

  // if (!verifyOTPSelector.response) {
  //   navigate("/");

  // }

  useEffect(() => {
    if (
      verifyOTPSelector.response &&
      verifyOTPSelector.response[0]["TOKEN"] &&
      !getProfileSelector.response
    ) {
      dispatch(getProfileAction());
      dispatch(companyAction());
      dispatch(singleQueryAction());
    }
  }, [verifyOTPSelector.response]);

  useEffect(() => {
    if (
      verifyOTPSelector.response &&
      verifyOTPSelector.response[0]["TOKEN"] 
      
    ) {
      dispatch(companyAction());
      dispatch(singleQueryAction());
    }
  }, [verifyOTPSelector.response]);

  useEffect(() => {
    if (
      addComplaintSelector &&
      addComplaintSelector.response &&
      addComplaintSelector.response[0]["COMPLAINT_ID"]
      //&& addComplaintSelector.response[0] &&
      // addComplaintSelector.response[0]["ID"] &&
      // !viewComplaintSelector.response
    ) {
      Swal.fire({
        icon: "success",
        title: "Complaint posted Successfully!",
        text: `Your Complaint ID ${
          addComplaintSelector.response[0]["IS_QUERY_MULTIPLE"] =="TRUE"
            ? addComplaintSelector.response.map((comps:any)=> `#${_.padStart(comps.COMPLAINT_ID,4,'0')} `)
            : `#${_.padStart(addComplaintSelector.response[0]["COMPLAINT_ID"],4,'0')}`
          
        }`,
        showConfirmButton: false,
        timer: 5000,
      });
      dispatch(
        viewComplaintAction({
          complaintId: addComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
      dispatch(
        viewFileAction({
          complaintId: addComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
    
      // dispatch(resetRecentListComplaintAction());
    }
  }, [
    // dispatch,
    addComplaintSelector && addComplaintSelector.response,
    //  viewComplaintSelector && viewComplaintSelector.response,
    // open,
  ]);

  useEffect(() => {
    if (
      viewComplaintSelector &&
      viewComplaintSelector.response &&
      viewComplaintSelector.response[0]["INVESTOR_NAME"]
      // &&  open === "add"
    ) {
     
      dispatch(resetRecentListComplaintAction());
      // toggle("complaint");
      // dispatch(resetViewComplaintAction())
    }
  }, [viewComplaintSelector && viewComplaintSelector.response]);

  useEffect(() => {
    if (
      closeComplaintSelector &&
      closeComplaintSelector.response &&
      closeComplaintSelector.response[0]["CUSTOMER_CLOSE_STATUS"]
    
    ) {
      dispatch(resetRecentListComplaintAction());
      dispatch(resetClosedListComplaintAction());

    }
  }, [closeComplaintSelector && closeComplaintSelector.response]);

  // if (
  //       viewComplaintSelector &&
  //       viewComplaintSelector.response &&
  //       viewComplaintSelector.response[0]["INVESTOR_NAME"]
  //      // &&  open === "add"
  //     ) {
  //       toggle("complaint");
  //       dispatch(resetViewComplaintAction());
  //     }

  const extractName = (name: string) =>
    _.filter(name.split(" "), function (substring) {
      return substring.length > 2;
    });

    const messageContainer = document.getElementById(
      "message-container"
    ) as HTMLElement | null;
    useEffect(() => {
      messageContainer?.scrollTo({ top: messageContainer.scrollHeight });
    }, [viewMessageSelector && viewMessageSelector.response]);

  return (
    <Fragment>
      <Box
        sx={{
          position: "inline-flex",
          direction: "row",
          marginX: 1,
          marginY: 1,
          overflow: "auto",
          justifyContent: "center",
          p: 1,
          filter: addProfile ? "blur(8px)" : "",
          transition: "filter 0.8s ease-out",
        }}
        style={{}}>
        <AddProfile
          onClick={boggle}
          open={addProfile}
          handleClose={() => {
           
              setAddProfile(false);
            
          }}
        />
        <Grid container>
          <Grid item xs={12} md={8}>
            <Box  id="complaint-container"
              sx={{
                display: "flex",
                direction: "row",
                p: 2,
                mr: 0,
                overflow: "auto",
                height:"85vh",
                maxHeight: "102vh",
              }}>
              {AddProfileSelector && AddProfileSelector.response ? (
                <SnackBar
                  severity="success"
                  handleClose={() => {
                    setSnackBarProfile(false);
                  }}
                  message="Profile added successfully!"
                  open={snackBarProfile}
                />
              ) : (
                AddProfileSelector &&
                AddProfileSelector.error && (
                  <SnackBar
                    severity="error"
                    handleClose={() => {
                      setSnackBarProfile(false);
                    }}
                    message="Problem in adding the profile"
                    open={snackBarProfile}
                  />
                )
              )}

              {/* {open == "add" &&
              verifyOTPSelector.response &&
              getProfileSelector.response &&
              verifyOTPSelector.response[0]["MOBILE"] ? (
                <AddComplaint
                  customerName={_.capitalize(
                    extractName(getProfileSelector.response[0]["NAME"])[0]
                  )}
                />
              ) : (
                AddProfileSelector.response && (
                  <AddComplaint
                    customerName={_.capitalize(
                      extractName(AddProfileSelector.response[0]["NAME"])[0]
                    )}
                  />
                )
              )} */}

              {open == "add" &&
              getProfileSelector.response &&
              getProfileSelector.response[0]["NAME"] ? (
                <AddComplaint
                  customerName={_.capitalize(
                    extractName(getProfileSelector.response[0]["NAME"])[0]
                  )}
                />
              ) : (
                open == "add" &&
                AddProfileSelector.response &&
                AddProfileSelector.response[0]["NAME"] && (
                  <AddComplaint
                    customerName={_.capitalize(
                      extractName(AddProfileSelector.response[0]["NAME"])[0]
                    )}
                  />
                )
              )}

              {/* {open =="add" && <AddComplaint customerName="Clinton" />} */}
              {open == "view" && <ComplaintsList onClick={toggle} />}
              {open == "complaint" &&  <QueryTabs  />}
              {open== "closedView" && <ClosedComplaintList onClick={toggle} />}
            </Box>
          </Grid>

          <Grid
            sx={{ borderLeft: "solid", borderWidth: "1px" }}
            item
            xs={12}
            md={4}>
            <Box
              className="scroll"
              sx={{
                display: "flex",
                flex: 1,
                direction: "row",
                justifyContent: "center",
                p: 1,
                ml: 2,
                overflow: "hidden",
                height:"85vh",
                maxHeight: "102vh",
              }}>
              <ListComplaint onClick={toggle} />
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box
        visibility={open !== "add" ? "visible" : "hidden"}
        onClick={() => {
          setOpen("add");
        }}
        sx={{ bottom: 10, right: 15, position: "fixed" }}>
        <Fab name="add" color="secondary">
          <Add />
        </Fab>
      </Box>
    </Fragment>
  );
};

export default Complaint;
