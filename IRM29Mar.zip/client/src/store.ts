import { combineReducers, createStore, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import {
  addProfileReducer,
  resendOTPReducer,
  sendCredentialsReducer,
  updateProfileReducer,
} from "./reducers/authReducer";
import thunk from "redux-thunk";
import {
  sendMobileOTPReducer,
  verifyMobileOTPReducer,
  getProfileReducer,
} from "./reducers/authReducer";

import {
  addComplaintReducer,
  attendAllComplaintReducer,
  attendListComplaintReducer,
  closedAllComplaintReducer,
  closedListComplaintReducer,
  companyReducer,
  listComplaintReducer,
  multipleQueryReducer,
 
  recentAllComplaintReducer,
  recentListComplaintReducer,
  singleQueryReducer,
  updateComplaintReducer,
  viewComplaintReducer,
} from "./reducers/complaintReducer";
import { changeThemeReducer } from "./reducers/themeReducer";
import {
  checkMessageReducer,
  closeComplaintReducer,
  postFileReducer,
  postMessageReducer,
  viewFileReducer,
  viewMessageFileReducer,
  viewMessageReducer,
} from "./reducers/messageReducer";
import { templateReducer, userClosedComplaintsReducer, userClosedListReducer } from "./reducers/userReducer";

const appReducer = combineReducers({
  theme: changeThemeReducer,
  sendMobileOTP: sendMobileOTPReducer,
  resendOTP: resendOTPReducer,
  addProfile: addProfileReducer,
  updateProfile: updateProfileReducer,
  getProfile: getProfileReducer,
  verifyMobileOTP: verifyMobileOTPReducer,
  addComplaint: addComplaintReducer,
  viewComplaint: viewComplaintReducer,
  listComplaint: listComplaintReducer,
  recentListComplaint: recentListComplaintReducer,
  updateComplaint: updateComplaintReducer,
  postFile: postFileReducer,
  viewFile: viewFileReducer,
  postMessage: postMessageReducer,
  viewMessage: viewMessageReducer,
  sendCredentials:sendCredentialsReducer,
  recentAllComplaint:recentAllComplaintReducer,
  closeComplaint:closeComplaintReducer,
  closedListComplaint:closedListComplaintReducer,
  closedAllComplaint:closedAllComplaintReducer,
  company:companyReducer,
  singleQuery:singleQueryReducer,
  multipleQuery:multipleQueryReducer,
  checkMessage:checkMessageReducer,
  viewMessageFile:viewMessageFileReducer,
  userClosedComplaints:userClosedComplaintsReducer,
  userClosedList:userClosedListReducer,
  template:templateReducer,
  attendListComplaint:attendListComplaintReducer,
  attendAllComplaint:attendAllComplaintReducer
});


const themeValue = localStorage.getItem("theme")
  ? localStorage.getItem("theme")
  : "light";
const loginValue = sessionStorage.getItem("login")
? { response: JSON.parse(sessionStorage.getItem("login") || "") }
: {};
const userLoginValue = sessionStorage.getItem("userLogin")
? { response: JSON.parse(sessionStorage.getItem("userLogin") || "") }
: {};
console.log(sessionStorage.getItem("userLogin"));

const profileValue = sessionStorage.getItem("profile")
? { response: JSON.parse(sessionStorage.getItem("profile") || "") }
: {};
const initialReducer = {
  theme: { mode: themeValue },
  verifyMobileOTP: loginValue ,
  sendCredentials: userLoginValue,
  addProfile:profileValue
};

const rootReducer=(state:any,action:any)=>{
  if(action.type=="USER_LOGOUT"){
     state=undefined; 
  }
  return appReducer(state,action);
}

const middleware = [thunk];
const store = createStore(
 rootReducer,
  initialReducer,
  composeWithDevTools(applyMiddleware(...middleware))
);

export default store;
