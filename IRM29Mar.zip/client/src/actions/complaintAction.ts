import axios from "axios";
import { useSelector } from "react-redux";
import {
  ADD_COMPLAINT_FAILED,
  ADD_COMPLAINT_REQUEST,
  ADD_COMPLAINT_SUCCESS,
  CLOSED_ALL_COMPLAINT_FAILED,
  CLOSED_ALL_COMPLAINT_REQUEST,
  CLOSED_ALL_COMPLAINT_SUCCESS,
  CLOSED_LIST_COMPLAINT_FAILED,
  CLOSED_LIST_COMPLAINT_REQUEST,
  CLOSED_LIST_COMPLAINT_SUCCESS,
  COMPANY_FAILED,
  COMPANY_REQUEST,
  COMPANY_SUCCESS,
  LIST_COMPLAINT_FAILED,
  LIST_COMPLAINT_REQUEST,
  LIST_COMPLAINT_SUCCESS,
  MULTIPLE_QUERY_SUCCESS,
  SINGLE_QUERY_FAILED,
  SINGLE_QUERY_REQUEST,
  SINGLE_QUERY_SUCCESS,
  MULTIPLE_QUERY_REQUEST,
  
  RECENT_ALL_COMPLAINT_FAILED,
  RECENT_ALL_COMPLAINT_REQUEST,
  RECENT_ALL_COMPLAINT_SUCCESS,
  RECENT_LIST_COMPLAINT_FAILED,
  RECENT_LIST_COMPLAINT_REQUEST,
  RECENT_LIST_COMPLAINT_SUCCESS,
  UPDATE_COMPLAINT_FAILED,
  UPDATE_COMPLAINT_REQUEST,
  UPDATE_COMPLAINT_SUCCESS,
  VIEW_COMPLAINT_FAILED,
  VIEW_COMPLAINT_REQUEST,
  VIEW_COMPLAINT_SUCCESS,
  MULTIPLE_QUERY_FAILED,
  ATTEND_LIST_COMPLAINT_SUCCESS,
  ATTEND_LIST_COMPLAINT_FAILED,
  ATTEND_ALL_COMPLAINT_REQUEST,
  ATTEND_ALL_COMPLAINT_SUCCESS,
  ATTEND_ALL_COMPLAINT_FAILED,
} from "../constants/complaintConstant";
import { API } from "../data";
import { verifyMobileOTPAction } from "./authAction";

export const addComplaintAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: ADD_COMPLAINT_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Complaint/addComplaint`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      dispatch({
        type: ADD_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: ADD_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const viewComplaintAction =
  (form: any) => async (dispatch: any, getState: any) => {
   
   
    try {
      dispatch({
        type: VIEW_COMPLAINT_REQUEST,
      });
     const {verifyMobileOTP:{response}}=getState();
    
      const { data } = await axios.post(
        `${API}/Complaint/viewComplaint`,
        form,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "application/json",
          },
        }
      );

      dispatch({
        type: VIEW_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const recentListComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: RECENT_LIST_COMPLAINT_REQUEST,
      });
      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/recentListComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: RECENT_LIST_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: RECENT_LIST_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const attendListComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: ATTEND_LIST_COMPLAINT_SUCCESS,
      });
      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/attendListComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: ATTEND_LIST_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: ATTEND_LIST_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const attendAllComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: ATTEND_ALL_COMPLAINT_REQUEST,
      });
      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/attendAllComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: ATTEND_ALL_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: ATTEND_ALL_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const listComplaintAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: LIST_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(`${API}/Complaint/listComplaint`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    dispatch({
      type: LIST_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: LIST_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const updateComplaintAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: UPDATE_COMPLAINT_REQUEST,
    });

    const { data } = await axios.post(
      `${API}/Complaint/updateComplaint`,
      form,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    dispatch({
      type: UPDATE_COMPLAINT_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: UPDATE_COMPLAINT_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const recentAllComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: RECENT_ALL_COMPLAINT_REQUEST,
      });
      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/recentAllComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: RECENT_ALL_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: RECENT_ALL_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userViewComplaintAction =
  (form: any) => async (dispatch: any, getState: any) => {
   
   
    try {
      dispatch({
        type: VIEW_COMPLAINT_REQUEST,
      });
     const {sendCredentials:{response}}=getState();
    
      const { data } = await axios.post(
        `${API}/Complaint/viewComplaint`,
        form,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "application/json",
          },
        }
      );

      dispatch({
        type: VIEW_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userAddComplaintAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: ADD_COMPLAINT_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Complaint/addComplaint`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      dispatch({
        type: ADD_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: ADD_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const closedListComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: CLOSED_LIST_COMPLAINT_REQUEST,
      });
      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/closedListComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: CLOSED_LIST_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: CLOSED_LIST_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const closedAllComplaintAction =
  () => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: CLOSED_ALL_COMPLAINT_REQUEST,
      });
      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.get(`${API}/Complaint/closedAllComplaint`, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: CLOSED_ALL_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: CLOSED_ALL_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const companyAction =
  () => async (dispatch: any) => {
    try {
      dispatch({
        type: COMPANY_REQUEST,
      });
  
      const { data } = await axios.get(`${API}/Complaint/company`, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: COMPANY_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: COMPANY_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const singleQueryAction =
  () => async (dispatch: any) => {
    try {
      dispatch({
        type: SINGLE_QUERY_REQUEST,
      });
  
      const { data } = await axios.get(`${API}/Complaint/singleQuery`, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: SINGLE_QUERY_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: SINGLE_QUERY_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const multipleQueryAction =
  (formData:any) => async (dispatch: any,getState:any) => {
    try {
      dispatch({
        type: MULTIPLE_QUERY_REQUEST,
      });
  
      const {verifyMobileOTP:{response}}=getState();
      const { data } = await axios.post(`${API}/Complaint/multipleQuery`, formData, {
        headers: {
          Authorization:`Bearer ${response[0]["TOKEN"]}` ,
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: MULTIPLE_QUERY_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: MULTIPLE_QUERY_FAILED,

        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  

