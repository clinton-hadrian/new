import axios from "axios";
import {
  GET_PROFILE_RESET,
  VERIFY_MOBILE_OTP_RESET,
  SEND_MOBILE_OTP_RESET,
  RESEND_OTP_RESET,
  ADD_PROFILE_RESET,
  UPDATE_PROFILE_RESET,
  USER_LOGOUT,
  SEND_CREDENTIALS_RESET,
} from "../constants/authConstant";
import { POST_FILE_RESET, VIEW_FILE_RESET, VIEW_MESSAGE_REQUEST, VIEW_MESSAGE_RESET } from "../constants/messageConstant";
import {
  ADD_COMPLAINT_RESET,
  VIEW_COMPLAINT_RESET,
  RECENT_LIST_COMPLAINT_RESET,
  RECENT_ALL_COMPLAINT_RESET,
  CLOSED_ALL_COMPLAINT_RESET,
  CLOSED_LIST_COMPLAINT_RESET,
  ATTEND_LIST_COMPLAINT_RESET,
  ATTEND_ALL_COMPLAINT_RESET,
} from "../constants/complaintConstant";

export const resetSendMobileOTPAction = () => (dispatch: any) => {
  dispatch({
    type: SEND_MOBILE_OTP_RESET,
  });
};

export const resetResendOTPAction = () => (dispatch: any) => {
  dispatch({
    type: RESEND_OTP_RESET,
  });
};

export const resetVerifyMobileOTPAction = () => (dispatch: any) => {
  dispatch({
    type: VERIFY_MOBILE_OTP_RESET,
  });
};

export const resetAddProfileAction = () => (dispatch: any) => {
  dispatch({
    type: ADD_PROFILE_RESET,
  });
};

export const resetUpdateProfileAction = () => (dispatch: any) => {
  dispatch({
    type: UPDATE_PROFILE_RESET,
  });
};

export const resetGetProfileAction = () => (dispatch: any) => {
  dispatch({
    type: GET_PROFILE_RESET,
  });
};

export const resetAddComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: ADD_COMPLAINT_RESET,
  });
};

export const resetViewComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: VIEW_COMPLAINT_RESET,
  });
};
export const resetRecentListComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: RECENT_LIST_COMPLAINT_RESET,
  });
};

export const resetPostFileAction = () => (dispatch: any) => {
  dispatch({
    type: POST_FILE_RESET,
  });
};

export const resetViewFileAction = () => (dispatch: any) => {
  dispatch({
    type: VIEW_FILE_RESET,
  });
};
export const resetAllStateAction = () => (dispatch: any) => {
  dispatch({
    type: USER_LOGOUT,
  });
};

export const resetsendCredentialsAction = () => (dispatch: any) => {
  dispatch({
    type: SEND_CREDENTIALS_RESET,
  });
};

export const resetRecentAllComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: RECENT_ALL_COMPLAINT_RESET,
  });
};

export const resetClosedListComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: CLOSED_LIST_COMPLAINT_RESET,
  });
};

export const resetClosedAllComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: CLOSED_ALL_COMPLAINT_RESET,
  });
};

export const resetViewMessageAction = () => (dispatch: any) => {
  dispatch({
    type: VIEW_MESSAGE_RESET,
  });
};

export const resetAttendListComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: ATTEND_LIST_COMPLAINT_RESET,
  });
};

export const resetAttendAllComplaintAction = () => (dispatch: any) => {
  dispatch({
    type: ATTEND_ALL_COMPLAINT_RESET,
  });
};

// export const resetClosedAllComplaintAction = () => (dispatch: any) => {
//   dispatch({
//     type: CLOSED_ALL_COMPLAINT_RESET,
//   });
// };
