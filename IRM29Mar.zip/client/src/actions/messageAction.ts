import axios from "axios";
import {
  POST_FILE_FAILED,
  POST_FILE_REQUEST,
  POST_FILE_SUCCESS,
  POST_FILE_RESET,
  VIEW_FILE_REQUEST,
  VIEW_FILE_SUCCESS,
  VIEW_FILE_FAILED,
  POST_MESSAGE_SUCCESS,
  POST_MESSAGE_FAILED,
  POST_MESSAGE_REQUEST,
  VIEW_MESSAGE_REQUEST,
  VIEW_MESSAGE_SUCCESS,
  VIEW_MESSAGE_FAILED,
  CLOSE_COMPLAINT_REQUEST,
  CLOSE_COMPLAINT_SUCCESS,
  CLOSE_COMPLAINT_FAILED,
  CHECK_MESSAGE_REQUEST,
  CHECK_MESSAGE_SUCCESS,
  CHECK_MESSAGE_FAILED,
  VIEW_MESSAGE_FILE_REQUEST,
  VIEW_MESSAGE_FILE_SUCCESS,
  VIEW_MESSAGE_FILE_FAILED,
} from "../constants/messageConstant";
import { API } from "../data";

export const postFileAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: POST_FILE_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Message/postFile`, formData, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "multipart/form-data",
        },
      });

      dispatch({
        type: POST_FILE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: POST_FILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const postMessageAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: POST_MESSAGE_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/postMessage`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
            // "Content-Type":"Application/json"
          },
        }
      );

      dispatch({
        type: POST_MESSAGE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: POST_MESSAGE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const viewMessageAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_MESSAGE_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/viewMessage`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      dispatch({
        type: VIEW_MESSAGE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_MESSAGE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

export const viewFileAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_FILE_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Message/viewFile`, formData, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "multipart/form-data",
        },
      });

      dispatch({
        type: VIEW_FILE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_FILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userViewFileAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_FILE_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Message/viewFile`, formData, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "multipart/form-data",
        },
      });

      dispatch({
        type: VIEW_FILE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_FILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const viewMessageFileAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_MESSAGE_FILE_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Message/viewMessageFile`, formData, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "multipart/form-data",
        },
      });

      dispatch({
        type: VIEW_MESSAGE_FILE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_MESSAGE_FILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userViewMessageFileAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_MESSAGE_FILE_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Message/viewMessageFile`, formData, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "multipart/form-data",
        },
      });

      dispatch({
        type: VIEW_MESSAGE_FILE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_MESSAGE_FILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userViewMessageAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: VIEW_MESSAGE_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/viewMessage`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      dispatch({
        type: VIEW_MESSAGE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: VIEW_MESSAGE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userPostMessageAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: POST_MESSAGE_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/postMessage`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
            // "Content-Type":"Application/json"
          },
        }
      );

      dispatch({
        type: POST_MESSAGE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: POST_MESSAGE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const closeComplaintAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: CLOSE_COMPLAINT_REQUEST,
      });

      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/closeComplaint`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
            // "Content-Type":"Application/json"
          },
        }
      );

      dispatch({
        type: CLOSE_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: CLOSE_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const userCloseComplaintAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: CLOSE_COMPLAINT_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/Message/closeComplaint`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "multipart/form-data",
            // "Content-Type":"Application/json"
          },
        }
      );

      dispatch({
        type: CLOSE_COMPLAINT_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: CLOSE_COMPLAINT_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const checkMessageAction =
  (formData: any) => async (dispatch: any) => {
    try {
      dispatch({
        type: CHECK_MESSAGE_REQUEST,
      });


      const { data } = await axios.post(
        `${API}/Message/checkMessage`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      dispatch({
        type: CHECK_MESSAGE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: CHECK_MESSAGE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };
