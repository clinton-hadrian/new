import axios from "axios";
import {
  TEMPLATE_FAILED,
  TEMPLATE_REQUEST,
  TEMPLATE_SUCCESS,
  USER_CLOSED_COMPLAINTS_FAILED,
  USER_CLOSED_COMPLAINTS_REQUEST,
  USER_CLOSED_COMPLAINTS_SUCCESS,
  USER_CLOSED_LIST_FAILED,
  USER_CLOSED_LIST_REQUEST,
  USER_CLOSED_LIST_SUCCESS,
  USER_LOGIN_FAILED,
  USER_LOGIN_REQUEST,
  USER_LOGIN_SUCCESS,
} from "../constants/userConstant";
import { API } from "../data";

export const userLoginAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: USER_LOGIN_REQUEST,
    });

    const { data } = await axios.post(
      `${API}/Auth/userLogin`,
      { form },
      {
        headers: { "content-type": "application-json" },
      }
    );

    dispatch({
      type: USER_LOGIN_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: USER_LOGIN_FAILED,
      payload: error,
    });
  }
};

export const userClosedComplaintsAction = () => async (dispatch: any,getState:any) => {
  try {
    dispatch({
      type: USER_CLOSED_COMPLAINTS_REQUEST,
    });

    const {
      sendCredentials: { response },
    } = getState();
    const { data } = await axios.get(`${API}/User/userClosedComplaints`, {
      headers: {
        Authorization: `Bearer ${response[0]["TOKEN"]}`,
        "Content-Type": "application/json",
      },
    });

    dispatch({
      type: USER_CLOSED_COMPLAINTS_SUCCESS,
      payload: data,
    });
  } catch (error:any) {
    dispatch({
      type: USER_CLOSED_COMPLAINTS_FAILED,
      payload:error && error.response && error.response.data
      ? error.response.data
      : error && error.message,
    });
  }
};

export const userClosedListAction =
  (formData: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: USER_CLOSED_LIST_REQUEST,
      });

      const {
        sendCredentials: { response },
      } = getState();
      const { data } = await axios.post(
        `${API}/User/userClosedList`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${response[0]["TOKEN"]}`,
            "Content-Type": "application/json",
          },
        }
      );

      dispatch({
        type: USER_CLOSED_LIST_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: USER_CLOSED_LIST_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };

  export const templateAction =
  () => async (dispatch: any) => {
    try {
      dispatch({
        type: TEMPLATE_REQUEST,
      });
  
      const { data } = await axios.get(`${API}/User/templates`, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      dispatch({
        type: TEMPLATE_SUCCESS,
        payload: data,
      });
    } catch (error: any) {
      dispatch({
        type: TEMPLATE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.message,
      });
    }
  };