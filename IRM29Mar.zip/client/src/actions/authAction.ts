import axios from "axios";
import {
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS,
  SEND_MOBILE_OTP_FAILED,
  RESEND_OTP_REQUEST,
  RESEND_OTP_SUCCESS,
  RESEND_OTP_FAILED,
  GET_PROFILE_REQUEST,
  GET_PROFILE_SUCCESS,
  GET_PROFILE_FAILED,
  SEND_CREDENTIALS_REQUEST,
  SEND_CREDENTIALS_SUCCESS,
  SEND_CREDENTIALS_FAILED,
} from "../constants/authConstant";

import {
  VERIFY_MOBILE_OTP_FAILED,
  VERIFY_MOBILE_OTP_REQUEST,
  VERIFY_MOBILE_OTP_SUCCESS,
} from "../constants/authConstant";

import { API } from "../data";
import {
  ADD_PROFILE_REQUEST,
  ADD_PROFILE_SUCCESS,
  ADD_PROFILE_FAILED,
  UPDATE_PROFILE_REQUEST,
  UPDATE_PROFILE_SUCCESS,
  UPDATE_PROFILE_FAILED,
} from "../constants/authConstant";
import { useSelector } from "react-redux";

export const sendMobileOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: SEND_MOBILE_OTP_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/sendMobileOTP`, form, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer ${token}",
      },
    });
    dispatch({
      type: SEND_MOBILE_OTP_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: SEND_MOBILE_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};

export const resendOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: RESEND_OTP_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/resendOTP`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: RESEND_OTP_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: RESEND_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};

export const verifyMobileOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: VERIFY_MOBILE_OTP_REQUEST,
    });

    const { data } = await axios.post(`${API}/Auth/OTPVerification`, form, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer ${token}",
      },
    });

    dispatch({
      type: VERIFY_MOBILE_OTP_SUCCESS,
      payload: data,
    });
    sessionStorage.setItem("login", JSON.stringify(data));
  } catch (error: any) {
    dispatch({
      type: VERIFY_MOBILE_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const addProfileAction =
  (form: any) => async (dispatch: any, getState: any) => {
    try {
      dispatch({
        type: ADD_PROFILE_REQUEST,
      });
      const {
        verifyMobileOTP: { response },
      } = getState();
      const { data } = await axios.post(`${API}/Auth/addProfile`, form, {
        headers: {
          Authorization: `Bearer ${response[0]["TOKEN"]}`,
          "Content-Type": "application/json",
        },
      });
      dispatch({
        type: ADD_PROFILE_SUCCESS,
        payload: data,
      });
      sessionStorage.setItem("profile", JSON.stringify(data));
    } catch (error: any) {
      dispatch({
        type: ADD_PROFILE_FAILED,
        payload:
          error && error.response && error.response.data
            ? error.response.data
            : error && error.mesaage,
      });
    }
  };

export const updateProfileAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: UPDATE_PROFILE_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/updateProfile`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: UPDATE_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: UPDATE_PROFILE_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};

export const getProfileAction = () => async (dispatch: any, getState: any) => {
  try {
    dispatch({
      type: GET_PROFILE_REQUEST,
    });
    const {
      verifyMobileOTP: { response },
    } = getState();
    // const verifyMobileOTPSelector=useSelector((state:any)=>state.verifyMobileOTP)
    const { data } = await axios.get(`${API}/Auth/getProfile`, {
      headers: {
        Authorization: `Bearer ${response[0]["TOKEN"]}`,
        "Content-Type": "application/json",
      },
      // const { data } = await axios.get(`${API}/Auth/getProfile`, {
      //   headers: {
      //     Authorization: `Bearer ${verifyMobileOTPSelector.response && verifyMobileOTPSelector.response[0]["TOKEN"]}`,
      //     "Content-Type": "application/json",
      //   },
    });
    dispatch({
      type: GET_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: GET_PROFILE_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};


export const sendCredentialsAction = (form: any) => async (dispatch: any,getState:any) => {
  try {
    dispatch({
      type: SEND_CREDENTIALS_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/sendCredentials`, form, {
      headers: {
        "Content-Type": "application/json"
      },
    });
    dispatch({
      type: SEND_CREDENTIALS_SUCCESS,
      payload: data,
    });
    sessionStorage.setItem("userLogin",JSON.stringify(data));
  } catch (error: any) {
    dispatch({
      type: SEND_CREDENTIALS_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};