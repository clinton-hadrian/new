import React, { Fragment } from "react";

import { Box, IconButton, Typography } from "@mui/material";

import Drawer from "@mui/material/Drawer";
import AppBar from "@mui/material/AppBar";
import CssBaseline from "@mui/material/CssBaseline";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";

import Divider from "@mui/material/Divider";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import LogoutIcon from "@mui/icons-material/Logout";
import HomeIcon from "@mui/icons-material/Home";
import SettingsIcon from "@mui/icons-material/Settings";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import {
  Sidebar,
  Menu,
  MenuItem,
  SubMenu,
  useProSidebar,
} from "react-pro-sidebar";
import { ArrowCircleRightRounded, ForkLeftOutlined, MenuOpenOutlined } from "@mui/icons-material";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import { useSelector } from "react-redux";
import Team from "./Team";
import TeamTable from "./Team";

const headTypo = { fontFamily: "Nunito", fontSize: "1.8rem", fontWeight: 500 };
interface props{
  onClick:(name:string)=>void
}

const DashBoard:React.FC<props> = (props) => {

  const {onClick}=props;

  const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    const n = event.currentTarget.name;
    onClick(n);
  };

  const handleButtonClic = (name:string) => {
    onClick(name);
  };
 

  const recentAllComplaintSelector = useSelector(
    (state: any) => state.recentAllComplaint
  );
  const closedAllComplaintSelector = useSelector(
    (state: any) => state.closedAllComplaint
  );

  return (
    <Fragment>
      <Box component="div" sx={{ width: "100%" }}>
        <Typography
          variant="h4"
          sx={{ fontFamily: "Inter", fontWeight: "500", mb: 3 }}>
          Dashboard
        </Typography>
        <Grid container paddingX={2} paddingY={2} spacing={7}>
          <Grid item xs={12} md={4}>
            <Card
              sx={{
                boxShadow: "12px 12px 2px 1px #0A2647",
                borderStyle: "solid",
                borderRadius: "15px",
              }}>
              <CardContent>
                <Typography sx={{ ...headTypo }}>Current Customers</Typography>
                <Typography>5698</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card
              sx={{
                boxShadow: "12px 12px 2px 1px #0A2647",
                borderStyle: "solid",
                borderRadius: "15px",
              }}>
              <CardContent>
                <Typography sx={{ ...headTypo }}>
                  Completed Complaints
                </Typography>
                <Typography>
                  {closedAllComplaintSelector &&
                  closedAllComplaintSelector.response &&
                  closedAllComplaintSelector.response &&
                  closedAllComplaintSelector.response.length
                    ? closedAllComplaintSelector.response.length
                    : 0}
                    <IconButton  sx={{float:"right",padding:"0px"}}  name="closedView" onClick={(e) => handleButtonClick(e)}>
      <ArrowCircleRightRounded sx={{fontSize:"2rem",color:"#0A2647"}} />
    </IconButton>
                </Typography>
                
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            <Card
              sx={{
                boxShadow: "12px 12px 2px 1px #0A2647",
                borderStyle: "solid",
                borderRadius: "15px",
              }}>
              <CardContent>
                <Typography sx={{ ...headTypo }}>Pending Complaints</Typography>
                <Typography>
                  {recentAllComplaintSelector &&
                  recentAllComplaintSelector.response &&
                  recentAllComplaintSelector.response.length
                    ? recentAllComplaintSelector.response.length
                    : 0}
                    <IconButton sx={{float:"right",padding:"0px"}} name="view" onClick={(e) => handleButtonClick(e)}>
      <ArrowCircleRightRounded sx={{fontSize:"2rem",color:"#0A2647"}} />
    </IconButton>
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <Box component="div" sx={{ mr: 4 }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500", mt: 3 }}>
            Team Complaints statistics
          </Typography>
          <TeamTable onClick={handleButtonClic} />
        </Box>
      </Box>
    </Fragment>
  );
};

export default DashBoard;
