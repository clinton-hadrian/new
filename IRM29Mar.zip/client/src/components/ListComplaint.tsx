import * as React from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import ListItemText from "@mui/material/ListItemText";
import Avatar from "@mui/material/Avatar";
import BeachAccessIcon from "@mui/icons-material/BeachAccess";
import OpenWithRoundedIcon from "@mui/icons-material/OpenWithRounded";
import Divider from "@mui/material/Divider";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { Box } from "@mui/system";
import { Button } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import {
  attendAllComplaintAction,
  closedAllComplaintAction,
  closedListComplaintAction,
  multipleQueryAction,
  recentAllComplaintAction,
  recentListComplaintAction,
  userViewComplaintAction,
  viewComplaintAction,
} from "../actions/complaintAction";
import * as _ from "lodash";
import moment from "moment";
import {
  userViewFileAction,
  userViewMessageAction,
  viewFileAction,
  viewMessageAction,
} from "../actions/messageAction";

interface props {
  onClick: (name: string) => void;
}

interface response {
  COMPLAINT_ID: number;
  INVESTOR_NAME: string;
}

const ListComplaint: React.FC<props> = (props) => {
  const { onClick } = props;
  const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    const n = event.currentTarget.name;
    onClick(n);
  };

  const dispatch: React.Dispatch<any> = useDispatch();
  const verifyMobileOTPSelector = useSelector(
    (state: any) => state.verifyMobileOTP
  );
  const sendCredentialsSelector = useSelector(
    (state: any) => state.sendCredentials
  );
  const recentListComplaintSelector = useSelector(
    (state: any) => state.recentListComplaint
  );
  const recentAllComplaintSelector = useSelector(
    (state: any) => state.recentAllComplaint
  );
  const addComplaintSelector = useSelector((state: any) => state.addComplaint);
  const closedAllComplaintSelector = useSelector(
    (state: any) => state.closedAllComplaint
  );
  const closedListComplaintSelector = useSelector(
    (state: any) => state.closedListComplaint
  );
  const closeComplaintSelector = useSelector(
    (state: any) => state.closeComplaint
  );
  const attendListComplaintSelector = useSelector(
    (state: any) => state.attendListComplaint
  );
  const attendAllComplaintSelector = useSelector(
    (state: any) => state.attendAllComplaint
  );
  const postMessageSelector = useSelector(
    (state: any) => state.postMessageComplaint
  );

  // const [render, setRender] = React.useState(true);

  // function toggleRender() {
  //   setRender(render => !render);
  // }

  // const interval = setInterval(toggleRender, 1000);
  // const clear = () => clearInterval(interval);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
    if (
      verifyMobileOTPSelector &&
      verifyMobileOTPSelector.response &&
      verifyMobileOTPSelector.response[0] &&
      verifyMobileOTPSelector.response[0]["TOKEN"] &&
      !recentListComplaintSelector.response
    ) {
      dispatch(recentListComplaintAction());
    }
    // },1000)
    //   return ()=>clearInterval(interval);
  }, [
    verifyMobileOTPSelector &&
      verifyMobileOTPSelector.response &&
      verifyMobileOTPSelector.response[0],
    addComplaintSelector &&
      addComplaintSelector.response &&
      addComplaintSelector.response[0],
    recentListComplaintSelector && recentListComplaintSelector.response,
    dispatch,
    closeComplaintSelector && closeComplaintSelector.response,
  ]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0] &&
      sendCredentialsSelector.response[0]["TOKEN"] &&
      !recentAllComplaintSelector.response
    ) {
      dispatch(recentAllComplaintAction());
    }
    // },5000)
    //  return ()=> clearInterval(interval);
  }, [
    sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0],
    addComplaintSelector &&
      addComplaintSelector.response &&
      addComplaintSelector.response[0],
    recentAllComplaintSelector && recentAllComplaintSelector.response,
  ]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0] &&
      sendCredentialsSelector.response[0]["TOKEN"] &&
      !attendAllComplaintSelector.response
    ) {
      dispatch(attendAllComplaintAction());
    }
    // },5000)
    //  return ()=> clearInterval(interval);
  }, [
    sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0],
    closeComplaintSelector &&
      closeComplaintSelector.response &&
      closeComplaintSelector.response[0],
    attendAllComplaintSelector && attendAllComplaintSelector.response && attendAllComplaintSelector.response[0],
    postMessageSelector && postMessageSelector.response && postMessageSelector.response[0],
  ]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
    if (
      verifyMobileOTPSelector &&
      verifyMobileOTPSelector.response &&
      verifyMobileOTPSelector.response[0] &&
      verifyMobileOTPSelector.response[0]["TOKEN"] &&
      !closedListComplaintSelector.response
    ) {
      dispatch(closedListComplaintAction());
    }
    // },1000)
    //   return ()=>clearInterval(interval);
  }, [
    verifyMobileOTPSelector &&
      verifyMobileOTPSelector.response &&
      verifyMobileOTPSelector.response[0],
    closedListComplaintSelector &&
      closedListComplaintSelector.response &&
      closedListComplaintSelector.response[0],
    recentListComplaintSelector && recentListComplaintSelector.response,
    closeComplaintSelector && closeComplaintSelector.response,
    dispatch,
  ]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0] &&
      sendCredentialsSelector.response[0]["TOKEN"] &&
      !closedAllComplaintSelector.response
    ) {
      dispatch(closedAllComplaintAction());
    }
    // },1000)
    //   return ()=>clearInterval(interval);
  }, [
    sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      sendCredentialsSelector.response[0],
    closedAllComplaintSelector &&
      closedAllComplaintSelector.response &&
      closedAllComplaintSelector.response[0],
    recentAllComplaintSelector && recentAllComplaintSelector.response,
    closeComplaintSelector && closeComplaintSelector.response,
  ]);

  return (
    <Grid container rowSpacing={1}>
      <Grid item xs={12} md={12}>
        <Box component="div" sx={{ width: "100%" }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500" }}
            gutterBottom>
            Recent Complaints
          </Typography>

          {recentListComplaintSelector.response ||
          recentAllComplaintSelector.response ? (
            <React.Fragment>
              <List
                sx={{
                  width: "100%",
                  maxWidth: "100%",
                  bgcolor: "background.paper",
                }}>
                {verifyMobileOTPSelector.response &&
                  recentListComplaintSelector &&
                  recentListComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    viewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    viewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  // dispatch(
                                  //   userViewMessageAction({
                                  //     complaintId:Number(
                                  //       e.currentTarget.getAttribute("data-key")
                                  //     ),

                                  //   }));
                                  //   dispatch(
                                  //     viewMessageAction({
                                  //       complaintId:
                                  //       e.currentTarget.getAttribute("data-key")
                                  //     }));
                                  console.log(
                                    e.currentTarget.getAttribute("key")
                                  );

                                  handleButtonClick(e);
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
                {sendCredentialsSelector &&
                  sendCredentialsSelector.response &&
                  sendCredentialsSelector.response[0] &&
                  recentAllComplaintSelector &&
                  recentAllComplaintSelector.response &&
                  recentAllComplaintSelector.response[0] &&
                  recentAllComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    userViewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    userViewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  console.log(
                                    e.currentTarget.getAttribute("name")
                                  );

                                  onClick("complaint");
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
              </List>
              <Button
                variant="contained"
                fullWidth
                sx={{
                  borderBottomRightRadius: "15px",
                  borderBottomLeftRadius: "15px",
                }}
                name="view"
                onClick={handleButtonClick}>
                View All
              </Button>
            </React.Fragment>
          ) : (
            "No recent complaints"
          )}
        </Box>
      </Grid>

      <Grid item xs={12} md={12}>
        <Box component="div" sx={{ width: "100%" }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500" }}
            gutterBottom>
            Closed Complaints
          </Typography>
          {closedListComplaintSelector.response ||
          closedAllComplaintSelector.response ? (
            <React.Fragment>
              <List
                sx={{
                  width: "100%",
                  maxWidth: "100%",
                  bgcolor: "background.paper",
                }}>
                {verifyMobileOTPSelector.response &&
                  closedListComplaintSelector &&
                  closedListComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    viewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    viewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  console.log(
                                    e.currentTarget.getAttribute("key")
                                  );

                                  handleButtonClick(e);
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
                {sendCredentialsSelector &&
                  sendCredentialsSelector.response &&
                  sendCredentialsSelector.response[0] &&
                  closedAllComplaintSelector &&
                  closedAllComplaintSelector.response &&
                  closedAllComplaintSelector.response[0] &&
                  closedAllComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    userViewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    userViewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  console.log(
                                    e.currentTarget.getAttribute("name")
                                  );

                                  onClick("complaint");
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
              </List>
              <Button
                variant="contained"
                fullWidth
                sx={{
                  borderBottomRightRadius: "15px",
                  borderBottomLeftRadius: "15px",
                }}
                name="closedView"
                onClick={handleButtonClick}>
                View All
              </Button>
            </React.Fragment>
          ) : (
            "No closed complaints"
          )}
        </Box>
      </Grid>

      <Grid item xs={12} md={12}>
        <Box component="div" sx={{ width: "100%" }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500" }}
            gutterBottom>
            Attending Complaints
          </Typography>
          {attendListComplaintSelector.response ||
          attendAllComplaintSelector.response ? (
            <React.Fragment>
              <List
                sx={{
                  width: "100%",
                  maxWidth: "100%",
                  bgcolor: "background.paper",
                }}>
                {verifyMobileOTPSelector.response &&
                  closedListComplaintSelector &&
                  closedListComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    viewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    viewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  console.log(
                                    e.currentTarget.getAttribute("key")
                                  );

                                  handleButtonClick(e);
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
                {sendCredentialsSelector &&
                  sendCredentialsSelector.response &&
                  sendCredentialsSelector.response[0] &&
                  attendAllComplaintSelector &&
                  attendAllComplaintSelector.response &&
                  attendAllComplaintSelector.response[0] &&
                  attendAllComplaintSelector.response
                    .slice(0, 3)
                    .map((res: any, key: number) => {
                      return (
                        <>
                          <li>
                            <Typography
                              sx={{ mt: 0.5, ml: 9 }}
                              color="text.secondary"
                              display="block"
                              variant="caption">
                              Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                            </Typography>
                          </li>
                          <Divider component="li" variant="inset" />
                          <ListItem sx={{ mb: 1.5 }}>
                            <ListItemAvatar>
                              <Button
                                variant="contained"
                                sx={{ borderRadius: "50px", mr: 2 }}
                                name="complaint"
                                key={res.COMPLAINT_ID}
                                data-key={res.COMPLAINT_ID}
                                data-multiple-query-id={res.MULTIPLE_QUERY_ID}
                                onClick={(
                                  e: React.MouseEvent<HTMLButtonElement>
                                ) => {
                                  dispatch(
                                    userViewComplaintAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    multipleQueryAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                    })
                                  );
                                  dispatch(
                                    userViewFileAction({
                                      complaintId: Number(
                                        e.currentTarget.getAttribute("data-key")
                                      ),
                                      multipleQueryId: Number(
                                        e.currentTarget.getAttribute(
                                          "data-multiple-query-id"
                                        )
                                      ),
                                    })
                                  );
                                  console.log(
                                    e.currentTarget.getAttribute("name")
                                  );

                                  onClick("complaint");
                                }}>
                                <OpenWithRoundedIcon />
                              </Button>
                            </ListItemAvatar>
                            <ListItemText
                              primary={_.capitalize(res.COMPANY_NAME)}
                              secondary={
                                res.FOLIO_DEMAT.length == 8
                                  ? `Folio - ${res.FOLIO_DEMAT}`
                                  : `Demat - ${res.FOLIO_DEMAT}`
                              }
                            />
                            <ListItemText
                              secondary={moment(res.CREATED_DATE).format(
                                "MMM D, YYYY - hh:mm a"
                              )}
                            />
                          </ListItem>
                        </>
                      );
                    })}
              </List>
              <Button
                variant="contained"
                fullWidth
                sx={{
                  borderBottomRightRadius: "15px",
                  borderBottomLeftRadius: "15px",
                }}
                name="closedView"
                onClick={handleButtonClick}>
                View All
              </Button>
            </React.Fragment>
          ) : (
            "No attending complaints"
          )}
        </Box>
      </Grid>
    </Grid>
  );
};

export default ListComplaint;
