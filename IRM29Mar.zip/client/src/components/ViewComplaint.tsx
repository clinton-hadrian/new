import * as React from "react";
import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import Grid from "@mui/material/Grid";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Collapse from "@mui/material/Collapse";
import Avatar from "@mui/material/Avatar";
import IconButton, { IconButtonProps } from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import { red } from "@mui/material/colors";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import TextField from "@mui/material/TextField";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import { useDispatch, useSelector } from "react-redux";
import * as _ from "lodash";
import moment from "moment";
import Modal from "react-modal";
import pdf from "../images/pdf-file.png";
import { Document, Page, pdfjs } from "react-pdf";
import {
  KeyboardDoubleArrowRightOutlined,
  KeyboardDoubleArrowLeftOutlined,
  DownloadOutlined,
  CloseOutlined,
  SendOutlined,
  AttachFileOutlined,
  AddCircle,
  PhotoRounded,
  PictureAsPdfRounded,
} from "@mui/icons-material";
import {
  Box,
  Button,
  ButtonBase,
  ButtonGroup,
  Fab,
  InputAdornment,
  InputLabel,
  Link,
  OutlinedInput,
  Tooltip,
} from "@mui/material";
import Comments from "./Comments";
import {
  closeComplaintAction,
  userCloseComplaintAction,
} from "../actions/messageAction";
import {
  closedAllComplaintAction,
  closedListComplaintAction,
} from "../actions/complaintAction";
import QueryTabs from "./QueryTabs";
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
Modal.setAppElement("#root");

interface ExpandMoreProps extends IconButtonProps {
  expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginRight: "auto",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

// interface props {
//   onClick: (name: string) => void;
// }

const ViewComplaint = () => {
  // const { onClick } = props;
  // const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
  //   const n = event.currentTarget.name;
  //   onClick(n);
  // };
  const [selectedFile, setSelectedFile] = React.useState({
    FILE_NAME: "",
    FILE_TYPE: "",
    ORIGINAL_NAME: "",
  });
  const [modalIsOpen, setModalIsOpen] = React.useState(false);

  const [isHovered, setIsHovered] = React.useState(false);

  const openModal = (file: any) => {
    setSelectedFile({
      FILE_NAME: file.FILE_NAME,
      FILE_TYPE: file.FILE_TYPE,
      ORIGINAL_NAME: file.ORIGINAL_NAME,
    });
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setSelectedFile({ FILE_NAME: "", FILE_TYPE: "", ORIGINAL_NAME: "" });
    setModalIsOpen(false);
  };

  const [numPages, setNumPages] = React.useState<number | null>(null);
  const [pageNumber, setPageNumber] = React.useState(1);

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number | null }) => {
    setNumPages(numPages);
  };

  const changePage = (offset: any) => {
    setPageNumber((prevPageNumber) => prevPageNumber + offset);
  };

  const previousPage = () => {
    changePage(-1);
  };

  const nextPage = () => {
    changePage(1);
  };

  // const [images, setImages] = React.useState<JSX.Element[]>([]);

  const [expanded, setExpanded] = React.useState(true);
  let fileArr: string[] = [];
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const dispatch: any = useDispatch();
  const viewComplaintSelector = useSelector(
    (state: any) => state.viewComplaint
  );
  const viewFileSelector = useSelector((state: any) => state.viewFile);
  const closedComplaintSelector = useSelector(
    (state: any) => state.closedListComplaint
  );
  const closedAllComplaintSelector = useSelector(
    (state: any) => state.closedAllComplaint
  );
  const sendCredentialsSelector = useSelector(
    (state: any) => state.sendCredentials
  );
  const verifyMobileOTPSelector = useSelector(
    (state: any) => state.verifyMobileOTP
  );
  const postMessageSelector = useSelector((state: any) => state.postMessage);
  const viewMessageSelector = useSelector((state: any) => state.viewMessage);
  const viewMessageFileSelector=useSelector((state:any)=>state.viewMessageFile)

  const userHandle = (e: React.MouseEvent<HTMLButtonElement>) => {
    sendCredentialsSelector &&
    sendCredentialsSelector.response &&
    sendCredentialsSelector.response[0]
      ? (() => {
          dispatch(
            userCloseComplaintAction({
              complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
            })
          );
          dispatch(closedAllComplaintAction());
          //handleButtonClick(e);
        })()
      : (() => {
          dispatch(
            closeComplaintAction({
              complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
            })
          );
          dispatch(closedListComplaintAction());
          //handleButtonClick(e);
        })();
  };

  const compContainer = document.getElementById(
    "c-container"
  ) as HTMLElement | null;
  React.useEffect(() => {
    compContainer?.scrollTo({ top: compContainer.scrollHeight });
  }, [postMessageSelector.response,viewMessageFileSelector.response]);

  const [hoveredIndex, setHoveredIndex] = React.useState<number | null>(null);

  const [hoveringItems, setHoveringItems] = React.useState([]);

function handleHover(index:number, isLeaving:boolean) {
  setHoveringItems((prevItems:any) => {
    if (isLeaving) return prevItems.filter((item:any) => item !== index);
    return [...prevItems, index];
  });
}
  return (
    <>
      {viewComplaintSelector && viewComplaintSelector.response ? (
        
        <Card
          id="c-container"
          sx={{ width: "100%", maxWidth: "100%", overflow: "auto", titleTypographyProps: {
            paddingY:"1px"
           }, }}>
            <CardHeader
            avatar={
             <Typography sx={{fontFamily:"inter"}}>Files Attached</Typography>
            }
 
            title={
              viewFileSelector && viewFileSelector.response && viewFileSelector.response.length > 0 ? (
                viewFileSelector.response.map((file:any, index:number) => {
                  const isHovered = index === hoveredIndex;
                  return (
                    <Tooltip key={index} title={file.ORIGINAL_NAME}>
                      <IconButton
                        sx={{
                          "&:hover": {
                            color: "green",
                            "& .MuiSvgIcon-root": {
                              display: isHovered ? "none" : "block",
                            },
                            "& .MuiIconButton-label": {
                              display: isHovered ? "flex" : "none",
                            },
                          },
                        }}
                        onClick={() => {
                          const a = document.createElement("a");
                          a.href = `data:${file.FILE_TYPE};base64,${file.FILE_NAME}`;
                          a.download = file.ORIGINAL_NAME;
                          a.click();
                        }}
                        onMouseEnter={() => {
                          handleHover(index, false)
                        }}
                        onMouseLeave={() => {
                          handleHover(index, true)
                        }}
                      >
                        <DownloadOutlined sx={{ justifyContent:"space-around", color:"#0A2647",   fontSize: "30px", display: isHovered ? "flex" : "none" }} />
                       {file.FILE_TYPE=="APPLICATION/PDF"?<PictureAsPdfRounded sx={{ justifyContent:"space-around",  color: "#0A2647", fontSize: "30px", display: isHovered ? "none" : "flex" }} />:<PhotoRounded sx={{ justifyContent:"space-around",color: "#0A2647", fontSize: "40px", display: isHovered ? "none" : "flex" }} />} 
                      </IconButton>
                    </Tooltip>
                  );
                })
              ) : (
                <Typography sx={{display:"flex",justifyContent:"center",fontWeight:"bold"}}>No files attached</Typography>
              )
             
            }
            
            
            
    


           
          />
          <CardHeader
            avatar={
              <Avatar sx={{ bgcolor: red[500] }} aria-label="nameAvatar">
                {_.capitalize(
                  _.head(viewComplaintSelector.response[0]["INVESTOR_NAME"])
                )}
              </Avatar>
            }
      

      action = {
        (closedAllComplaintSelector &&
          closedAllComplaintSelector.response || closedComplaintSelector &&
          closedComplaintSelector.response ? (
        ((sendCredentialsSelector && sendCredentialsSelector.response &&
        sendCredentialsSelector.response[0] && closedAllComplaintSelector &&
        closedAllComplaintSelector.response && !closedAllComplaintSelector.response.some(
        (complaintId: any) => complaintId.COMPLAINT_ID === viewComplaintSelector.response[0]["COMPLAINT_ID"]
        )) ||
        (verifyMobileOTPSelector && verifyMobileOTPSelector.response &&
        verifyMobileOTPSelector.response[0] && closedComplaintSelector &&
        closedComplaintSelector.response && !closedComplaintSelector.response.some(
        (complaintId: any) => complaintId.COMPLAINT_ID === viewComplaintSelector.response[0]["COMPLAINT_ID"]
        ))) ? (
          <Button
            name="dashboard"
            onClick={userHandle}
            sx={{
              backgroundColor: "#FF0303",
              borderRadius: "15px",
              mt: 1
            }}
            variant="contained"
            endIcon={<HighlightOffIcon />}>
              Close Ticket
          </Button>
        ) : (
          <Typography
            sx={{ border: "solid #FF0303", p: 1,fontWeight:500,color:"#FF0303",fontFamily:"Inter" }}
            component="div">
              TICKET CLOSED
          </Typography>
        )):(((sendCredentialsSelector && sendCredentialsSelector.response &&
          sendCredentialsSelector.response[0] ) ||
          (verifyMobileOTPSelector && verifyMobileOTPSelector.response &&
          verifyMobileOTPSelector.response[0] )) ? (
            <Button
              name="dashboar"
              onClick={userHandle}
              sx={{
                backgroundColor: "#FF0303",
                borderRadius: "15px",
                mt: 1
              }}
              variant="contained"
              endIcon={<HighlightOffIcon />}>
                Close Ticket
            </Button>
          ) : (
            <Typography
              sx={{ border: "solid #cccccc", p: 1,display:"none" }}
              component="div">
                TICKET CLOSED
            </Typography>
          )))
      }
            title={<b>{viewComplaintSelector.response[0]["INVESTOR_NAME"]}</b>}
            subheader={`Posted on ${moment(
              viewComplaintSelector.response[0]["CREATED_DATE"]
            ).format("MMMM D, YYYY - hh:mm a")}`}
          />

          {/* September 14, 2016 - 12:39 */}

          <CardContent>
          <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Ticket Number
              <Typography
                variant="h5"
                sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                {`#${_.padStart(viewComplaintSelector.response[0]["COMPLAINT_ID"],4,"0")}`}
              </Typography>
            </Typography>

            <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Shares held on
              <Typography
                variant="h5"
                sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                {viewComplaintSelector.response[0]["COMPANY_NAME"]}
              </Typography>
            </Typography>

            <Grid container>
              <Grid item xs={12} md={3}>
                <Typography
                  gutterBottom
                  variant="h5"
                  component="div"
                  sx={{ fontFamily: "Inter", fontWeight: "500" }}>
                  {`${
                    viewComplaintSelector.response[0]["FOLIO_DEMAT"].length == 8
                      ? "Folio"
                      : "Demat"
                  } Number`}
                  <Typography
                    variant="h5"
                    sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                    {viewComplaintSelector.response[0]["FOLIO_DEMAT"]}
                  </Typography>
                </Typography>
              </Grid>
              <Grid item xs={12} md={9}>
                <Typography
                  gutterBottom
                  variant="h5"
                  component="div"
                  sx={{ fontFamily: "Inter", fontWeight: "500" }}>
                  PAN Number
                  <Typography
                    variant="h5"
                    sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                    {viewComplaintSelector.response[0]["PAN"]
                      ? viewComplaintSelector.response[0]["PAN"]
                      : "No PAN Number"}
                  </Typography>
                </Typography>
              </Grid>
            </Grid>

            <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              {`${
                viewComplaintSelector.response[0]["FOLIO_DEMAT"].length == 8
                  ? "Folio"
                  : "Demat"
              } Number`}
              <Typography
                variant="h5"
                sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                {viewComplaintSelector.response[0]["FOLIO_DEMAT"]}
              </Typography>
            </Typography>

            <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Type of query
              <Typography
                variant="h5"
                sx={{ fontFamily: "Inter", fontWeight: "200" }}>
                {viewComplaintSelector.response[0]["QUERY"]}
              </Typography>
            </Typography>

            <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Problem Statement
              <Typography
                variant="h6"
                sx={{ fontFamily: "Inter", fontWeight: "200", fontSize: "8" }}>
                {viewComplaintSelector.response[0]["PROBLEM_STATEMENT"]}
              </Typography>
            </Typography>
            {/* <Typography
              gutterBottom
              variant="h5"
              component="div"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Submitted Files
            </Typography>
            {viewFileSelector &&
            viewFileSelector.response &&
            viewFileSelector.response.length > 0 ? (
              <div className="f-container">
                {viewFileSelector &&
                  (viewFileSelector.response as any) &&
                  (viewFileSelector.response as any).map(
                    (
                      file: {
                        FILE_TYPE: string;
                        FILE_NAME: string;
                        ORIGINAL_NAME: string;
                      },
                      index: number
                    ) => {
                      return (
                        <div
                          className="image"
                          key={file.ORIGINAL_NAME}
                          style={{ cursor: "pointer" }}
                          onClick={() => openModal(file)}>
                          {file.FILE_TYPE == "APPLICATION/PDF" ? (
                            <img src={pdf} title={file.ORIGINAL_NAME} />
                          ) : (
                            <img
                              src={`data:${file.FILE_TYPE};base64,${file.FILE_NAME}`}
                              alt={file.ORIGINAL_NAME}
                            />
                          )}

                          <h5>{file.ORIGINAL_NAME}</h5>
                        </div>
                      );
                    }
                  )}
              </div>
            ) : (
              <Typography
                variant="h6"
                sx={{ fontFamily: "Inter", fontWeight: "200", fontSize: "8" }}>
                No Files Submitted
              </Typography>
            )} */}

            <Modal
              isOpen={modalIsOpen}
              onRequestClose={closeModal}
              style={{
                overlay: {
                  zIndex: 1000,
                  position: "fixed",
                  top: "90px",
                  left: 0,
                  right: 0,
                  bottom: 0,
                  backgroundColor: "rgba(255, 255, 255, 0.75)",
                },
                content: {
                  zIndex: 1000,
                  alignContent: "center",
                  textAlign: "center",
                  position: "absolute",
                  top: "0px",
                  left: "40px",
                  right: "40px",
                  bottom: "40px",
                  border: "8px solid #ccc",
                  background: "#fff",
                  overflow: "auto",
                  WebkitOverflowScrolling: "touch",
                  borderRadius: "4px",
                  outline: "none",
                  padding: "20px",
                },
              }}>
              {selectedFile && selectedFile.FILE_TYPE === "APPLICATION/PDF" ? (
                <div style={{ height: "calc(100vh - 200px)" }}>
                  <p>
                    Page {pageNumber || (numPages ? 1 : "--")} of{" "}
                    {numPages || "--"}
                  </p>
                  <div
                    style={{
                      // width:"60%",
                      display: "flex",
                      justifyContent: "flex-start",
                      position: "relative",
                    }}>
                    <div
                      style={{
                        flex: "0 1 auto",
                        position: "absolute",
                        transform: "translateX(-50%)",
                        left: "50%",
                      }}>
                      <Button
                        sx={{ mr: 2 }}
                        variant="outlined"
                        disabled={pageNumber <= 1}
                        onClick={previousPage}>
                        <KeyboardDoubleArrowLeftOutlined />
                      </Button>
                      <Button
                        sx={{}}
                        variant="outlined"
                        disabled={pageNumber >= (numPages ? numPages : 0)}
                        onClick={nextPage}>
                        <KeyboardDoubleArrowRightOutlined />
                      </Button>
                    </div>

                    <div style={{ flex: "0 1 auto", marginLeft: "auto" }}>
                      <Button
                        sx={{ mr: 2 }}
                        variant="outlined"
                        href={`data:${selectedFile.FILE_TYPE};base64,${selectedFile.FILE_NAME}`}
                        download={selectedFile.ORIGINAL_NAME}>
                        <DownloadOutlined />
                      </Button>
                      <Button variant="outlined" sx={{}} onClick={closeModal}>
                        <CloseOutlined />
                      </Button>
                    </div>
                  </div>
                  <Document
                    file={{
                      url: `data:${selectedFile.FILE_TYPE};base64,${selectedFile.FILE_NAME}`,
                    }}
                    onLoadError={(error) =>
                      console.error("Failed to load PDF file:", error)
                    }
                    onLoadSuccess={onDocumentLoadSuccess}>
                    <Page
                      renderAnnotationLayer={false}
                      width={1429}
                      // style={{objectFit:"cover"}}
                      pageNumber={pageNumber}
                    />
                  </Document>
                </div>
              ) : (
                <>
                  <div
                    style={{
                      // width:"60%",
                      display: "flex",
                      justifyContent: "flex-start",
                      position: "relative",
                    }}>
                    <div
                      style={{
                        flex: "0 1 auto",
                        position: "absolute",
                        transform: "translateX(-50%)",
                        left: "50%",
                      }}>
                      <Typography
                        sx={{
                          fontFamily: "inter",
                          fontWeight: "500",
                          mt: 0.5,
                        }}>
                        {selectedFile.ORIGINAL_NAME}
                      </Typography>
                    </div>

                    <div style={{ flex: "0 1 auto", marginLeft: "auto" }}>
                      <Button
                        sx={{ mr: 2 }}
                        variant="outlined"
                        href={`data:${selectedFile.FILE_TYPE};base64,${selectedFile.FILE_NAME}`}
                        download={selectedFile.ORIGINAL_NAME}>
                        <DownloadOutlined />
                      </Button>
                      <Button variant="outlined" sx={{}} onClick={closeModal}>
                        <CloseOutlined />
                      </Button>
                    </div>
                  </div>

                  <div style={{ width: "100%", height: "94%" }}>
                    <img
                      style={{ height: "100%", objectFit: "cover" }}
                      src={`data:${selectedFile.FILE_TYPE};base64,${selectedFile.FILE_NAME}`}
                      alt={selectedFile.ORIGINAL_NAME}
                    />
                  </div>
                </>
              )}
            </Modal>
          </CardContent>
          <CardActions disableSpacing>
            <Typography sx={{ fontWeight: "bold" }}>
              Discussion Forum
            </Typography>
            <ExpandMore
              expand={expanded}
              onClick={handleExpandClick}
              aria-expanded={expanded}
              aria-label="show more">
              <ExpandMoreIcon />
            </ExpandMore>
          </CardActions>
          <Collapse
            in={expanded}
            sx={{ position: "relative" }}
            timeout="auto"
            unmountOnExit>
            <Comments />
          </Collapse>
        </Card>
        
      ) : (
        "No Complaint to view"
      )}
    </>
  );
};

export default ViewComplaint;
