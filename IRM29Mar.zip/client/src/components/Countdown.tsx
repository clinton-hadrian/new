import React, { useState, useEffect, Dispatch } from "react";
import { Typography, Box } from "@mui/material";
import { LoadingButton } from "@mui/lab";
import { resendOTPAction } from "../actions/authAction";
import { useDispatch, useSelector } from "react-redux";

const Countdown = () => {
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [text, setText] = useState("Code will expire in");
  const [isCountdownActive, setIsCountdownActive] = useState(true);
  const dispatch:Dispatch<any>=useDispatch();
  const sendMobileOTPSelector=useSelector((state:any)=>state.sendMobileOTP)
  let intervalId: number | undefined;

  useEffect(() => {
    if (isCountdownActive) {
      intervalId = window.setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            setText("Code has expired");
            clearInterval(intervalId);
            setIsCountdownActive(false);
            return;
          }
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [minutes, seconds, isCountdownActive]);

  return (
    <>
      <Box
        component="div"
        sx={{
          display: "flex",
          direction: "row",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
          width: "20rem",
          height: 30,
        }}>
        {isCountdownActive ? (
          <Box
            component="div"
            sx={{
              // backgroundColor: "#2C74B3",
              borderBottom: "50px solid #0A2647",
              borderLeft: "25px solid transparent",
              borderRight: "25px solid transparent",
              height: 0,
              // width: "250%",
              position: "absolute",
              // top: 10,
              bottom: -33,
              color: "#fff",
            }}>
            <Typography
              variant="h6"
              sx={{ fontFamily: "inter", fontWeight: "400", mt: 1, mx: 1 }}>
              {text} {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
            </Typography>
            {/* <div></div> */}
          </Box>
        ) : (
          <LoadingButton
            sx={{ mt: 2, width: "90%" }}
            fullWidth
            size="large"
            type="submit"
            variant="outlined"
            color="primary"
            onClick={() => {
              setIsCountdownActive(true);
                dispatch(resendOTPAction({
                  mobile:sendMobileOTPSelector.response[0]["MOBILE"]
                }));
               dispatch(resendOTPAction( sendMobileOTPSelector.response[0]["MOBILE"] ));
            }}>
            Resend OTP
          </LoadingButton>
        )}
      </Box>
    </>
  );
};

export default Countdown;
