import {
  AttachFileOutlined,
  CheckBox,
  CheckBoxOutlineBlankOutlined,
  CloseOutlined,
  CommentsDisabled,
  DownloadOutlined,
  FileDownloadRounded,
  FilePresentOutlined,
  KeyboardDoubleArrowLeftOutlined,
  KeyboardDoubleArrowRightOutlined,
  PhotoRounded,
  PictureAsPdfRounded,
  SendOutlined,
  SendRounded,
} from "@mui/icons-material";
import {
  Autocomplete,
  Box,
  Button,
  CardContent,
  Checkbox,
  Chip,
  Fab,
  FormControl,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  OutlinedInput,
  TextField,
  Typography,
} from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  checkMessageAction,
  postMessageAction,
  userPostMessageAction,
  userViewFileAction,
  userViewMessageAction,
  userViewMessageFileAction,
  viewMessageAction,
  viewMessageFileAction,
} from "../actions/messageAction";
import moment from "moment";
import _ from "lodash";
import { resetViewMessageAction } from "../actions/resetAction";
import pdf from "../images/pdf-file.png";
import Modal from '@mui/material/Modal';
import { Document, Page, pdfjs } from "react-pdf";
import { templateAction } from "../actions/userAction";

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
 // border: '2px solid ',
  borderRadius:"15px",
  boxShadow: 24,
  p: 4,
};

const Comments = () => {
  const fileInputRef = useRef<HTMLButtonElement | null>(null);
  const [fileName, setFileName] = useState("");

  const [images, setImages] = useState<JSX.Element[]>([]);

  const [files, setFiles] = useState<File[]>([]);

  const [rows, setRows] = useState(1);

  const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    const lines = event.target.value.split("\n").length;
    if (lines <= 4) {
      setRows(lines);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const lines = event.currentTarget.value.split("\n").length;
    if (lines >= 4 && event.keyCode === 13) {
      event.preventDefault();
    }
  };

  const delImage = (index: number) => {
    setFiles((files) => files.filter((_, i) => i !== index));
     setFileName((fileName)=>fileName.split(",").filter((_,i)=>i!==index).join(","));
  };

  const showImages = (files: File[]) => {
    const imageElements = files.map((file, index) => {
    });
  };

  const dispatch: any = useDispatch();
  const viewComplaintSelector = useSelector(
    (state: any) => state.viewComplaint
  );
  const checkMessageSelector = useSelector((state: any) => state.checkMessage);

  const postMessageSelector = useSelector((state: any) => state.postMessage);
  const viewMessageSelector = useSelector((state: any) => state.viewMessage);
  const verifyMobileOTPSelector = useSelector(
    (state: any) => state.verifyMobileOTP
  );
  const sendCredentialsSelector = useSelector(
    (state: any) => state.sendCredentials
  );
  const closedListComplaintSelector = useSelector(
    (state: any) => state.closedListComplaint
  );
  const closedAllComplaintSelector = useSelector(
    (state: any) => state.closedAllComplaint
  );
  const templateSelector = useSelector(
    (state: any) => state.template
  );
  const viewMessageFileSelector = useSelector(
    (state: any) => state.viewMessageFile
  );

  // too check the length in db
  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     if (
  //       viewComplaintSelector &&
  //       viewComplaintSelector.response &&
  //       viewComplaintSelector.response[0]
  //     ) {
  //       dispatch(
  //         checkMessageAction({
  //           complaintId:
  //             viewComplaintSelector &&
  //             viewComplaintSelector.response &&
  //             viewComplaintSelector.response[0]["COMPLAINT_ID"],
  //         })
  //       );
  //     }
  //   }, 2000);
  //   return () => clearInterval(interval);
  // }, [
  //   viewComplaintSelector.response,
  //   dispatch,
  //   viewMessageSelector.response,
  //   postMessageSelector.response,
  // ]);

  //   useEffect(()=>{ if (
  //     checkMessageSelector &&
  //     checkMessageSelector.response &&
  //     checkMessageSelector.response.length > viewMessageSelector &&
  //     viewMessageSelector.response.length
  //   ) {
  //     dispatch(
  //       viewMessageAction({
  //         complaintId:
  //           viewComplaintSelector &&
  //           viewComplaintSelector.response &&
  //           viewComplaintSelector.response[0]["COMPLAINT_ID"],
  //       })
  //     );
  //     dispatch(
  //       userViewMessageAction({
  //         complaintId:
  //           viewComplaintSelector &&
  //           viewComplaintSelector.response &&
  //           viewComplaintSelector.response[0]["COMPLAINT_ID"],
  //       })
  //     );

  //     dispatch(resetViewMessageAction());
  //   }

  // },[checkMessageSelector &&
  //   checkMessageSelector.response,viewMessageSelector &&
  //   viewMessageSelector.response])

  useEffect(() => {
    if (
      verifyMobileOTPSelector &&
      verifyMobileOTPSelector.response &&
      viewComplaintSelector &&
      viewComplaintSelector.response &&
      viewComplaintSelector.response[0]["COMPLAINT_ID"]
      // && !viewMessageSelector.response[0]
    ) {
      dispatch(
        viewMessageAction({
          complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
      dispatch(
        viewMessageFileAction({
          complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
    }
  }, [viewComplaintSelector.response, dispatch, postMessageSelector.response]);

  useEffect(() => {
    if (
      sendCredentialsSelector &&
      sendCredentialsSelector.response &&
      viewComplaintSelector &&
      viewComplaintSelector.response &&
      viewComplaintSelector.response[0]["COMPLAINT_ID"]
      //  && !viewMessageSelector.response[0]
    ) {
      dispatch(
        userViewMessageAction({
          complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
      dispatch(
        userViewMessageFileAction({
          complaintId: viewComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
      dispatch(
        templateAction()
      );
    }
  }, [viewComplaintSelector.response, dispatch, postMessageSelector.response]);

  const commentsFormik = useFormik({
    initialValues: {
      message: "",
      mediaDocument: "",
    },

    validationSchema: Yup.object().shape({
      message: Yup.string().required(),
    }),
    onSubmit: (value) => {
      console.log(value.message);
      console.log(
        viewComplaintSelector &&
          viewComplaintSelector.response &&
          viewComplaintSelector.response[0]["COMPLAINT_ID"]
      );

      const formData = new FormData();
      formData.append(
        "complaintId",
        viewComplaintSelector &&
          viewComplaintSelector.response &&
          viewComplaintSelector.response[0]["COMPLAINT_ID"]
      );
      formData.append("message", value.message);
      files.forEach((file) => {
        formData.append("files", file);
      });

      console.log(formData.getAll("complaintId"));
      if (verifyMobileOTPSelector && verifyMobileOTPSelector.response) {
        dispatch(postMessageAction(formData));
      } else {
        dispatch(userPostMessageAction(formData));
      }

      commentsFormik.resetForm({
        values: {
          message: "",
          mediaDocument: "",
        },
      });

      setFiles([]);
      setImages([]);
      setFileName("");
    },
  });

  const messageContainer = document.getElementById(
    "message-container"
  ) as HTMLElement | null;
  useEffect(() => {
    messageContainer?.scrollTo({ top: messageContainer.scrollHeight });
  }, [
    postMessageSelector.response,
    viewMessageSelector.response,
    viewMessageFileSelector.response,
  ]);

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [queries, setQueries] = useState<Array<{
    label: string;
    id: number;
  }> | null>(null);
 
const handleQueryChange = (
    event: React.ChangeEvent<{}>,
    value: Array<{ label: string; id: number }> | null
  ) => {
    setQueries(value || []);
  };

  const icon = <CheckBoxOutlineBlankOutlined fontSize="small" />;
  const checkedIcon = <CheckBox fontSize="small" />;


  return (
    <>
      <CardContent
        id="message-container"
        sx={{ mb: 0.5, maxHeight: "50vh", overflowY: "auto" }}>
        {viewMessageSelector &&
          viewMessageSelector.response &&
          viewMessageSelector.response
            .sort(
              (a: any, b: any) =>
                new Date(a.CREATED_DATE).getTime() -
                new Date(b.CREATED_DATE).getTime()
            )
            .map((message: any, index: number) => (
              <div style={{ width: "100%", display: "flex" }}>
                {(_.lowerCase(message.ROLE_NAME) == "customer" &&
                  _.lowerCase(
                    verifyMobileOTPSelector &&
                      verifyMobileOTPSelector.response &&
                      verifyMobileOTPSelector.response[0]["ROLE"]
                  ) == "customer") ||
                // (_.lowerCase(message.CREATED_NAME) == "user" &&
                //  (_.lowerCase(sendCredentialsSelector &&
                //    sendCredentialsSelector.response &&
                //    sendCredentialsSelector.response[0]["ROLE"]) == "user"))
                _.lowerCase(message.CREATED_NAME) ==
                  _.lowerCase(
                    sendCredentialsSelector &&
                      sendCredentialsSelector.response &&
                      sendCredentialsSelector.response[0]["USERNAME"]
                  ) ? (
                  <div
                    style={{
                      marginLeft: "auto",
                      marginBottom: "4px",
                      width: "50%",
                    }}>
                    <div
                      className="chat"
                      style={{ overflowWrap: "break-word" }}>
                      <div className="right">
                        <p
                          style={{
                            marginTop: "0px",
                            marginBottom: "0px",
                            color: "green",
                            fontSize: "14px",
                          }}>
                          You
                        </p>
                        <span className="chat-message">{message.MESSAGE}</span>
                      </div>
                      <p
                        className="time"
                        style={{
                          float: "left",
                          marginBottom: "0px",
                          color: "red",
                          fontSize: "11px",
                          display:
                            viewMessageFileSelector.response &&
                            viewMessageFileSelector.response.some(
                              (file: any) =>
                                file.MESSAGE_ID == message.MESSAGE_ID
                            ) &&
                            "none",
                        }}>
                        {moment(message.CREATED_DATE).format(
                          "DD-MM-yyyy hh:mm a"
                        )}
                      </p>
                    </div>
                    {viewMessageFileSelector &&
                      viewMessageFileSelector.response &&
                      viewMessageFileSelector.response.length > 0 && (
                        <div
                          className="mes-right-container"
                          style={{
                            float: "right",
                            display: viewMessageFileSelector.response.some(
                              (file: any) =>
                                file.MESSAGE_ID == message.MESSAGE_ID
                            )
                              ? "flex"
                              : "none",
                          }}>
                          {viewMessageFileSelector &&
                            (viewMessageFileSelector.response as any) &&
                            (viewMessageFileSelector.response as any)
                              .filter(
                                (file: any) =>
                                  message.MESSAGE_ID == file.MESSAGE_ID
                              )
                              .map(
                                (
                                  file: {
                                    FILE_TYPE: string;
                                    FILE_NAME: string;
                                    ORIGINAL_NAME: string;
                                  },
                                  index: number
                                ) => {
                                  return (
                                    <div
                                      className="image"
                                      key={file.ORIGINAL_NAME}
                                      style={{ cursor: "pointer" }}>
                                      {file.FILE_TYPE == "APPLICATION/PDF" ? (
                                        // <img src={pdf} title={file.ORIGINAL_NAME} />

                                        <Chip
                                          color="error"
                                          deleteIcon={<FileDownloadRounded />}
                                          onDelete={() => {
                                            const a =
                                              document.createElement("a");
                                            a.href = `data:${
                                              file.FILE_TYPE
                                            };base64,${_.last(
                                              file.FILE_NAME.split("/")
                                            )}`;
                                            a.download = file.ORIGINAL_NAME;
                                            a.click();
                                          }}
                                          label={`${_.truncate(
                                            file.ORIGINAL_NAME.replace(
                                              /\.[^/.]+$/,
                                              ""
                                            ),
                                            { length: 15 }
                                          )}.${_.last(
                                            file.FILE_TYPE.split("/")
                                          )}`}
                                          icon={<PictureAsPdfRounded />}
                                        />
                                      ) : (
                                        <Chip
                                          color="primary"
                                          label={`${_.truncate(
                                            file.ORIGINAL_NAME.replace(
                                              /\.[^/.]+$/,
                                              ""
                                            ),
                                            { length: 15 }
                                          )}.${_.last(
                                            file.FILE_TYPE.split("/")
                                          )}`}
                                          deleteIcon={<FileDownloadRounded />}
                                          onDelete={() => {
                                            const a =
                                              document.createElement("a");
                                            a.href = `data:${file.FILE_TYPE};base64,${file.FILE_NAME}`;
                                            a.download = file.ORIGINAL_NAME;
                                            a.click();
                                          }}
                                          icon={<PhotoRounded />}
                                        />
                                      )}
                                    </div>
                                  );
                                }
                              )}
                          <p
                            className="file-time"
                            style={{
                              float: "left",
                              marginBottom: "0px",
                              color: "red",
                              fontSize: "11px",
                            }}>
                            {moment(message.CREATED_DATE).format(
                              "DD-MM-yyyy hh:mm a"
                            )}
                          </p>
                        </div>
                      )}
                  </div>
                ) : (
                  <div
                    style={{
                      marginRight: "auto",
                      marginBottom: "4px",
                      width: "50%",
                    }}>
                    <div
                      className="chat-left"
                      style={{ overflowWrap: "break-word" }}>
                      <div className="left">
                        <p
                          style={{
                            marginTop: "0px",
                            marginBottom: "0px",
                            color: "green",
                            fontSize: "14px",
                          }}>
                          {message.CREATED_NAME}{" "}
                          {_.lowerCase(message.ROLE_NAME) == "user"
                            ? "(support)"
                            : ""}
                        </p>
                        <span className="chat-message">{message.MESSAGE}</span>
                      </div>
                      <p
                        className="time-left"
                        style={{
                          float: "right",
                          marginBottom: "0px",
                          color: "red",
                          fontSize: "11px",
                          display:
                            viewMessageFileSelector.response &&
                            viewMessageFileSelector.response.some(
                              (file: any) =>
                                file.MESSAGE_ID == message.MESSAGE_ID
                            ) &&
                            "none",
                        }}>
                        {moment(message.CREATED_DATE).format(
                          "DD-MM-yyyy hh:mm a"
                        )}
                      </p>
                    </div>
                    {viewMessageFileSelector &&
                      viewMessageFileSelector.response &&
                      viewMessageFileSelector.response.length > 0 && (
                        <div
                          className="mes-left-container"
                          style={{
                            float: "left",
                            display: viewMessageFileSelector.response.some(
                              (file: any) =>
                                file.MESSAGE_ID == message.MESSAGE_ID
                            )
                              ? "flex"
                              : "none",
                          }}>
                          {viewMessageFileSelector &&
                            (viewMessageFileSelector.response as any) &&
                            (viewMessageFileSelector.response as any)
                              .filter(
                                (file: any) =>
                                  message.MESSAGE_ID == file.MESSAGE_ID
                              )
                              .map(
                                (
                                  file: {
                                    FILE_TYPE: string;
                                    FILE_NAME: string;
                                    ORIGINAL_NAME: string;
                                  },
                                  index: number
                                ) => {
                                  return (
                                    <div
                                      className="image"
                                      key={file.ORIGINAL_NAME}
                                      style={{ cursor: "pointer" }}>
                                      {file.FILE_TYPE == "APPLICATION/PDF" ? (
                                        <Chip
                                          color="error"
                                          deleteIcon={<FileDownloadRounded />}
                                          onDelete={() => {
                                            const a =
                                              document.createElement("a");
                                            a.href = `data:${file.FILE_TYPE};base64,${file.FILE_NAME}`;
                                            a.download = file.ORIGINAL_NAME;
                                            a.click();
                                          }}
                                          label={`${_.truncate(
                                            file.ORIGINAL_NAME.replace(
                                              /\.[^/.]+$/,
                                              ""
                                            ),
                                            { length: 15 }
                                          )}.${_.last(
                                            file.FILE_TYPE.split("/")
                                          )}`}
                                          icon={<PictureAsPdfRounded />}
                                        />
                                      ) : (
                                        <Chip
                                          color="primary"
                                          label={`${_.truncate(
                                            file.ORIGINAL_NAME.replace(
                                              /\.[^/.]+$/,
                                              ""
                                            ),
                                            { length: 15 }
                                          )}.${_.last(
                                            file.FILE_TYPE.split("/")
                                          )}`}
                                          deleteIcon={<FileDownloadRounded />}
                                          onDelete={() => {
                                            const a =
                                              document.createElement("a");
                                            a.href = `data:${file.FILE_TYPE};base64,${file.FILE_NAME}`;
                                            a.download = file.ORIGINAL_NAME;
                                            a.click();
                                          }}
                                          icon={<PhotoRounded />}
                                        />
                                      )}
                                    </div>
                                  );
                                }
                              )}
                          <p
                            className="file-time-left"
                            style={{
                              float: "right",
                              marginBottom: "0px",
                              color: "red",
                              fontSize: "11px",
                            }}>
                            {moment(message.CREATED_DATE).format(
                              "DD-MM-yyyy hh:mm a"
                            )}
                          </p>
                        </div>
                      )}
                  </div>
                )}
              </div>
            ))}
      </CardContent>
      <CardContent>
        {(closedAllComplaintSelector && closedAllComplaintSelector.response) ||
        (closedListComplaintSelector &&
          closedListComplaintSelector.response) ? (
          (sendCredentialsSelector &&
            sendCredentialsSelector.response &&
            sendCredentialsSelector.response[0] &&
            closedAllComplaintSelector &&
            closedAllComplaintSelector.response &&
            !closedAllComplaintSelector.response.some(
              (complaintId: any) =>
                complaintId.COMPLAINT_ID ===
                  viewComplaintSelector.response[0]["COMPLAINT_ID"] &&
                complaintId.CUSTOMER_CLOSE_STATUS == 1
            )) ||
          (verifyMobileOTPSelector &&
            verifyMobileOTPSelector.response &&
            verifyMobileOTPSelector.response[0] &&
            closedListComplaintSelector &&
            closedListComplaintSelector.response &&
            !closedListComplaintSelector.response.some(
              (complaintId: any) =>
                complaintId.COMPLAINT_ID ===
                  viewComplaintSelector.response[0]["COMPLAINT_ID"] &&
                complaintId.CUSTOMER_CLOSE_STATUS == 1
            )) ? (
            <div
              style={{
                width: "97%",
                position: "relative",
                display: "flex",
                left: "1.5%",
                bottom: "1.9%",
                marginTop: "10px",
              }}>
              <FormControl fullWidth sx={{ mr: 2 }}>
                <span style={{ marginLeft: "1.5rem" }} id="custom-text">
                  {fileName}
                </span>
                <div className="img-container">
                  {" "}
                  {files.map((file, index) => {
                    return (
                      <>
                        <div className="image" key={file.name}>
                          {file.type === "application/pdf" ? (
                            <img src={pdf} alt="PDF" />
                          ) : (
                            <img
                              src={URL.createObjectURL(file)}
                              alt={file.name}
                            />
                          )}
                          <span onClick={() => delImage(index)}>×</span>
                        </div>
                      </>
                    );
                  })}
                </div>
                <Grid container columnSpacing={1}>
                  <Grid item md={11.2}>
                    <TextField
                      inputProps={{ multiple: true }}
                      className="inputField"
                      style={{ display: "none" }}
                      id="upload-photo"
                      name="mediaDocument"
                      type="file"
                      inputRef={fileInputRef}
                      onChange={(
                        event: React.ChangeEvent<HTMLInputElement>
                      ) => {
                        const mediaDocument = event.target.files?.[0];
                        if (mediaDocument) {
                          commentsFormik.handleChange({
                            target: {
                              name: "mediaDocument",
                              value: event.target.files,
                            },
                          });
                        }
                        const selectedFiles = event.target.files;
                        if (selectedFiles) {
                          setFiles((prevFiles) => [
                            ...prevFiles,
                            ...Array.from(selectedFiles),
                          ]);

                          setFileName(
                            (prevFileName) =>
                            prevFileName +
                            // ", " +
                            Array.from(selectedFiles)
                              .map((file) => file.name)
                              .join(", ")
                          );

                          showImages([...files, ...Array.from(selectedFiles)]);
                        }
                      }}
                    />
                    <Modal
  open={open}
  onClose={handleClose}
>
  <Box sx={style}>
    <Typography sx={{fontFamily:"inter",mb:1}} variant="h6" component="h2">
      Select Templates to send <IconButton  sx={{float:"right",padding:"0px"}}  name="closedView" onClick={(e) =>{}}>
      <SendRounded sx={{fontSize:"2rem",color:"#0A2647"}} />
    </IconButton>
    </Typography>
    <Autocomplete
            value={queries || []}
            multiple
            
            options={
              templateSelector && templateSelector.response
                ? templateSelector.response
                : "LOADING"
              
            }
            disableCloseOnSelect
            getOptionLabel={(option) => option.label}
            renderOption={(props, option, { selected }) => (
              <li {...props}>
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  style={{ marginRight: 8 }}
                  checked={selected}
                />
                {option.label}
              </li>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
               
                placeholder="Templates"
              />
            )}
            onChange={handleQueryChange}
          />
  </Box>
</Modal>

                    <OutlinedInput
                      multiline
                      // rows={1}
                      minRows={1}
                      type="text"
                      name="message"
                      onChange={commentsFormik.handleChange}
                      onBlur={commentsFormik.handleBlur}
                      value={commentsFormik.values.message}
                      endAdornment={
                        <InputAdornment position="end">
                        { sendCredentialsSelector && sendCredentialsSelector.response && <IconButton
                            sx={{ mr: 0.2 }}
                            onClick={() => handleOpen()}
                            edge="end">
                            <FilePresentOutlined />
                          </IconButton>}
                          <IconButton
                            onClick={() => fileInputRef.current?.click()}
                            edge="end">
                            <AttachFileOutlined />
                          </IconButton>
                        </InputAdornment>
                      }
                      sx={{ width: "100%" }}
                      style={{ borderRadius: "15px" }}
                      placeholder="Comment here.."
                    />
                    <FormHelperText sx={{ float: "right", color: "#144272" }}>
                      Do not exceed 1000 characters
                    </FormHelperText>
                    {Boolean(
                      commentsFormik.touched.message &&
                        commentsFormik.errors.message
                    ) && <FormHelperText error>it is empty</FormHelperText>}
                  </Grid>
                  <Grid item md={0.8}>
                    <Box
                      onClick={(e: React.MouseEvent<HTMLDivElement>) => {
                        commentsFormik.handleSubmit();
                        e.preventDefault();
                      }}
                      sx={{ marginLeft: "auto", zIndex: 1 }}>
                      <Fab color="primary" sx={{}}>
                        <SendOutlined />
                      </Fab>
                    </Box>
                  </Grid>
                </Grid>
              </FormControl>
            </div>
          ) : (
            <Typography
              sx={{
                border: "solid #FF0303",
                p: 1,
                textAlign: "center",
                fontWeight: 500,
                color: "#FF0303",
                fontFamily: "Inter",
              }}
              component="div">
              TICKET CLOSED
            </Typography>
          )
        ) : (sendCredentialsSelector &&
            sendCredentialsSelector.response &&
            sendCredentialsSelector.response[0]) ||
          (verifyMobileOTPSelector &&
            verifyMobileOTPSelector.response &&
            verifyMobileOTPSelector.response[0]) ? (
          <div
            style={{
              width: "97%",
              position: "relative",
              display: "flex",
              left: "1.5%",
              bottom: "1.9%",
              marginTop: "10px",
            }}>
            <FormControl fullWidth sx={{ mr: 2 }}>
              <span style={{ marginLeft: "1.5rem" }} id="custom-text">
                {fileName}
              </span>
              <div style={{ position: "relative" }} className="img-container">
                {images}
              </div>

              <Grid container columnSpacing={1}>
                <Grid item md={11.2}>
                  <TextField
                    inputProps={{ multiple: true }}
                    className="inputField"
                    style={{ display: "none" }}
                    id="upload-photo"
                    name="mediaDocument"
                    type="file"
                    inputRef={fileInputRef}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                      const mediaDocument = event.target.files?.[0];
                      if (mediaDocument) {
                        commentsFormik.handleChange({
                          target: {
                            name: "mediaDocument",
                            value: event.target.files,
                          },
                        });
                      }
                      const selectedFiles = event.target.files;
                      if (selectedFiles) {
                        setFiles((prevFiles) => [
                          ...prevFiles,
                          ...Array.from(selectedFiles),
                        ]);

                        setFileName(
                          (prevFileName) =>
                          prevFileName +
                          // ", " +
                          Array.from(selectedFiles)
                            .map((file) => file.name)
                            .join(", ")
                        );

                        showImages([...files, ...Array.from(selectedFiles)]);
                      }
                    }}
                  />
                  <OutlinedInput
                    multiline
                    // rows={1}
                    minRows={1}
                    type="text"
                    name="message"
                    onChange={commentsFormik.handleChange}
                    onBlur={commentsFormik.handleBlur}
                    value={commentsFormik.values.message}
                    endAdornment={
                      <InputAdornment position="end">
                        { sendCredentialsSelector && sendCredentialsSelector.response && <IconButton
                            sx={{ mr: 0.2 }}
                            onClick={() => handleOpen()}
                            edge="end">
                            <FilePresentOutlined />
                          </IconButton>}
                        <IconButton
                          onClick={() => fileInputRef.current?.click()}
                          edge="end">
                          <AttachFileOutlined />
                        </IconButton>
                      </InputAdornment>
                    }
                    sx={{ width: "100%" }}
                    style={{ borderRadius: "15px" }}
                    placeholder="Comment here.."
                  />
                  <FormHelperText sx={{ float: "right", color: "#144272" }}>
                    Do not exceed 1000 characters
                  </FormHelperText>
                  {Boolean(
                    commentsFormik.touched.message &&
                      commentsFormik.errors.message
                  ) && <FormHelperText error>it is empty</FormHelperText>}
                </Grid>
                <Grid sx={{}} item md={0.8}>
                  <Box
                    onClick={(e: React.MouseEvent<HTMLDivElement>) => {
                      commentsFormik.handleSubmit();
                      e.preventDefault();
                    }}
                    sx={{ marginLeft: "auto" }}>
                    <Fab color="primary" sx={{}}>
                      <SendOutlined />
                    </Fab>
                  </Box>
                </Grid>
              </Grid>
            </FormControl>
          </div>
        ) : (
          <Typography
            sx={{ border: "solid #cccccc", p: 1, display: "none" }}
            component="div">
            TICKET CLOSED
          </Typography>
        )}
      </CardContent>
    </>
  );
};

export default Comments;

const ops = [
  { label: 'The Shawshank Redemption', id: 1994 },
  { label: 'The Godfather', id: 1972 },
  { label: 'The Godfather: Part II', id: 1974 },
  { label: 'The Dark Knight', id: 2008 }];
