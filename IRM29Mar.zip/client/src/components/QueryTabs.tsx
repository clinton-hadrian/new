import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import ViewComplaint from './ViewComplaint';
import { Tabs } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { viewComplaintAction } from '../actions/complaintAction';
import _ from 'lodash';

interface props{
    onClick:(name:string)=>void
}

const QueryTabs =()=> {

    const dispatch:any=useDispatch();
    const multipleQuerySelector=useSelector((state:any)=>state.multipleQuery);
     

    // const {onClick}=props;
    // function handleClick(name:string){
    //     onClick(name);
    // }

  const [value, setValue] = React.useState('1');

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      {multipleQuerySelector && multipleQuerySelector.response && multipleQuerySelector.response.length>1?<TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            {multipleQuerySelector && multipleQuerySelector.response && multipleQuerySelector.response.length>1 && multipleQuerySelector.response.map((query:any,index:number)=>{return(
                <Tab onClick={()=>{
                    dispatch(viewComplaintAction({
                        complaintId:query.COMPLAINT_ID
                    }))
                }} label={`#${_.padStart(query.COMPLAINT_ID,4,"0")}`} value={index}/>
            )})}
           
          </TabList>
        </Box>
        <ViewComplaint />
        </TabContext>:
 <ViewComplaint />}
      
</Box>
      );
}

export default QueryTabs

 {/* <Tab label="Item One" value="1" />
            <Tab label="Item Two" value="2" />
            <Tab label="Item Three" value="3" /> */}