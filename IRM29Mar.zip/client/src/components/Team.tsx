import React, { Fragment } from "react";
import { Box, useTheme } from "@mui/material";
import { GridColDef, DataGridProps } from "@mui/x-data-grid";
import { useSelector } from "react-redux";
import DataGrid from "./DataGrid";

interface props {
  onClick: (name: string) => void;
}



const TeamTable:React.FC<props> = (props) => {

  const { onClick } = props;
 

  const userClosedComplaintsSelector = useSelector(
    (state: any) => state.userClosedComplaints
  );


  const columns: GridColDef[] = [
    { field: "id", headerName: "Id", width: 100 },
    { field: "USER_CLOSE_BY", headerName: "Employee Id", width: 100 },
    {
      field: "USERNAME",
      headerName: "Name",
      cellClassName: "name-column--cell",
      width: 150,
    },
    {
      field: "COMPLAINTS_CLOSED",
      headerName: "Completed Complaints",
      type: "number",
      headerAlign: "left",
      align: "left",
      width: 200,
    },

    { field: "EMAILID", headerName: "Email", width: 200 },
  ];
  const rows = userClosedComplaintsSelector && userClosedComplaintsSelector.response
    ? userClosedComplaintsSelector.response.map((users:any)=>{
      return{
        id:users.ID,
        USER_CLOSE_BY:users.USER_CLOSE_BY,
        USERNAME:users.USERNAME,
        EMAILID:users.EMAILID,
        COMPLAINTS_CLOSED:users.COMPLAINTS_CLOSED,

      }
    })
    : [];

    function handleClick(name:string) {
     
      onClick(name);
    }
    
  return (
    <Fragment>
      {userClosedComplaintsSelector.response &&
        userClosedComplaintsSelector.response.length > 0 &&
        rows.length > 0 && <DataGrid onClic={handleClick} rows={rows} columns={columns}   />}
    </Fragment>
  );
};

export default TeamTable;
