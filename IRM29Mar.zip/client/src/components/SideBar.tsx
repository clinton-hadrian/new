import { BarChartOutlined, CalendarMonthOutlined, ContactEmergencyOutlined, HelpCenterOutlined, HotelOutlined, MapOutlined, PeopleAltOutlined, Person2Outlined, PieChartOutline, ReceiptLongOutlined, TimeToLeaveOutlined } from '@mui/icons-material';
import { Box, Typography } from '@mui/material'
import React, { Fragment, useState } from 'react'
import { Menu, MenuItem, Sidebar, useProSidebar } from 'react-pro-sidebar'

interface ItemProps {
    title: string;
    icon: React.ReactElement;
    selected: string;
    setSelected: (title: string) => void;
  }

const Item = ({ title, icon, selected, setSelected }: ItemProps) => {
    
 
  
    return (
      <MenuItem
        active={selected === title}
        style={{color:"#141414"}}
        onClick={() => setSelected(title)}
        icon={icon}
        
      >
        <Typography>{title}</Typography>
      </MenuItem>
    );
  };

const SideBar = () => {

    const [selected, setSelected] = useState("Dashboard");

  const { collapseSidebar, toggleSidebar, collapsed, broken } = useProSidebar();
  return (
    <Fragment> <Box
    sx={{
      position: "sticky",
      display: "flex",
      height: "100vh",
      top: 0,
      bottom: 0,
      zIndex: 10000,
      "& .sidebar": {
        border: "none",
      },
      "& .menu-icon": {
        backgroundColor: "transparent !important",
      },
      "& .menu-item": {
        // padding: "5px 35px 5px 20px !important",
        backgroundColor: "transparent !important",
      },
      "& .menu-anchor": {
        color: "inherit !important",
        backgroundColor: "transparent !important",
      },
      "& .menu-item:hover": {
        color: "#6870fa !important",
        backgroundColor: "transparent !important",
      },
      "& .menu-item.active": {
        color: "#4cceac !important",
        backgroundColor: "transparent !important",
      },
    }}
  >
    
    <Sidebar
      breakPoint="md"
 
      backgroundColor="#1F2A40"

    >
      <Menu >
        
        {!collapsed && (
          <Box mb="25px">
          
            <Box textAlign="center">
              <Typography
                variant="h3"
                color="#e0e0e0"
                fontWeight="bold"
                sx={{ m: "10px 0 0 0" }}
              >
                Harun Jeylan
              </Typography>
            </Box>
          </Box>
        )}
        <Box paddingLeft={collapsed ? undefined : "10%"}>
          <Item
            title="Dashboard"
           
            icon={<HotelOutlined />}
            selected={selected}
            setSelected={setSelected}
          />

          <Typography
            variant="h6"
            color="#3d3d3d"
            sx={{ m: "15px 20px 5px 20px" }}
          >
            Data
          </Typography>
          <Item
            title="Manage Team"
        
            icon={<PeopleAltOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Contacts Information"
          
            icon={<ContactEmergencyOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Invoices Balances"
           
            icon={<ReceiptLongOutlined />}
            selected={selected}
            setSelected={setSelected}
          />

          <Typography
            variant="h6"
            color="#3d3d3d"
            sx={{ m: "15px 20px 5px 20px" }}
          >
            Pages
          </Typography>
          <Item
            title="Profile Form"
            
            icon={<Person2Outlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Calendar"
            
            icon={<CalendarMonthOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="FAQ Page"
            
            icon={<HelpCenterOutlined />}
            selected={selected}
            setSelected={setSelected}
          />

          <Typography
            variant="h6"
            color="#3d3d3d"
            sx={{ m: "15px 20px 5px 20px" }}
          >
            Charts
          </Typography>
          <Item
            title="Bar Chart"
            
            icon={<BarChartOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Pie Chart"
            
            icon={<PieChartOutline />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Line Chart"
            
            icon={<TimeToLeaveOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
          <Item
            title="Geography Chart"
          
            icon={<MapOutlined />}
            selected={selected}
            setSelected={setSelected}
          />
        </Box>
      </Menu>
    </Sidebar>
  </Box></Fragment>
  )
}

export default SideBar