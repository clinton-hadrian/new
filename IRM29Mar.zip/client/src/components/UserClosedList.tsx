import React, { Dispatch, useState } from "react";
import {
  Box,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Typography,
  Divider,
  Fab,
  Button,
} from "@mui/material";
import IconButton from "@mui/material/IconButton";
import { EastRounded } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import * as _ from "lodash";
import {
  userViewComplaintAction,
  viewComplaintAction,
} from "../actions/complaintAction";
import { userViewFileAction, viewFileAction } from "../actions/messageAction";



interface props {
  onClick: (name: string) => void;
}

const UserClosedList: React.FC<props> = (props) => {
  const { onClick } = props;
  function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    const name = event.currentTarget.name;
    onClick(name);
  }

  const dispatch: Dispatch<any> = useDispatch();

  const sendCredentialsSelector = useSelector(
    (state: any) => state.sendCredentials
  );
  const userClosedListSelector = useSelector(
    (state: any) => state.userClosedList
  );

  const [complaintsToShow, setComplaintsToShow] = useState(1);


  return (
    <>
      <Box
        component="div"
        sx={{ width: "100%", overFlow: "auto", p: 0, justifyContent: "left" }}>
        <Typography
          variant="h4"
          sx={{
            fontFamily: "Inter",
            fontSize: "1.8rem",
            fontWeight: "300",
            ml: 2,
          }}
          gutterBottom>
          Complaints Closed By {" "}
          {userClosedListSelector.response ? 
          _.lowerCase(userClosedListSelector.response[0]["USERNAME"]) ==
            
          _.lowerCase(sendCredentialsSelector.response[0]["USERNAME"])
            ? "You"
            : _.capitalize(userClosedListSelector.response[0]["USERNAME"]):"User"}
        </Typography>

        {userClosedListSelector && userClosedListSelector.response && userClosedListSelector.response ? (
          <List
            sx={{
              width: "100%",
              bgcolor: "background.paper",
              alignItems: "left",
            }}>
             
            {sendCredentialsSelector.response &&
              userClosedListSelector.response &&
              userClosedListSelector.response.slice(0, complaintsToShow).map((res: any, index: number) => {
                return (
                  <>
                    <li>
                      <Typography
                        sx={{ mt: 0.5, ml: 9, fontWeight: "800" }}
                        color="text.secondary"
                        display="block"
                        variant="caption">
                        Ticket No - {_.padStart(res.COMPLAINT_ID, 4, "0")}
                      </Typography>
                    </li>
                    <Divider component="li" variant="inset" />
                    <ListItem
                      sx={{ mb: 2 }}
                      secondaryAction={
                        <IconButton edge="end" aria-label="delete">
                          <Fab
                            name="complaint"
                            data-key={res.COMPLAINT_ID}
                            onClick={(
                              e: React.MouseEvent<HTMLButtonElement>
                            ) => {
                              dispatch(
                                userViewComplaintAction({
                                  complaintId:
                                    e.currentTarget.getAttribute("data-key"),
                                })
                              );
                              dispatch(
                                userViewFileAction({
                                  complaintId: Number(
                                    e.currentTarget.getAttribute("data-key")
                                  ),
                                })
                              );
                              handleClick(e);
                            }}
                            color="secondary">
                            <EastRounded />
                          </Fab>
                        </IconButton>
                      }>
                      <ListItemAvatar>
                        <Avatar sx={{ backgroundColor: "#0A2647" }}>
                          {index + 1}
                        </Avatar>
                      </ListItemAvatar>

                      <ListItemText
                        primary={res.COMPANY_NAME}
                        secondary={
                          res.FOLIO_DEMAT.length == 8
                            ? `Folio - ${res.FOLIO_DEMAT}`
                            : `Demat - ${res.FOLIO_DEMAT}`
                        }
                      />
                      <ListItemText
                        secondary={
                          <Typography sx={{ fontFamily: "Inter" }}>
                            {moment(res.CREATED_DATE).format(
                              "MMM D, YYYY - hh:mm a"
                            )}
                          </Typography>
                        }
                      />
                    </ListItem>
                  </>
                );
              })}
              <Button sx={{display:"flex",margin:"auto"}}
  variant="contained"
  color="primary"
  onClick={() => setComplaintsToShow(complaintsToShow + 5)}
>
  Load More
</Button>
          </List>
        ) : (
          <Typography sx={{ ml: 2 }}>No recent complaints</Typography>
        )}
      </Box>
    </>
  );
};

export default UserClosedList;
