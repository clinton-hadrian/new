import { Grid } from "@mui/material";
import Container from "@mui/material/Container";
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import LoginFooter from "./LoginFooter";
import LoginHeader from "./LoginHeader";

const IndexLayout = () => {
  return (
    <Fragment>
       <LoginHeader />
      <Grid
        container
        spacing={1}
        sx={{
          alignItems: "center",
          justifyContent: "center",
          minHeight: "60vh",
        }}>
         
        <Grid item xs={12} md={5}>
       
        <Outlet />
        </Grid>
      </Grid>
     <LoginFooter />
    </Fragment>
  );
};

export default IndexLayout;
