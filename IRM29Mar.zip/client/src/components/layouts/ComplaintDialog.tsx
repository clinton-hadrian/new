import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import ListItemText from "@mui/material/ListItemText";
import ListItem from "@mui/material/ListItem";
import List from "@mui/material/List";
import Divider from "@mui/material/Divider";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import CloseIcon from "@mui/icons-material/Close";
import Slide from "@mui/material/Slide";
import { TransitionProps } from "@mui/material/transitions";
import { Report } from "@mui/icons-material";
import AddComplaint from "../AddComplaint";
import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import { userViewComplaintAction } from "../../actions/complaintAction";
import { userViewFileAction } from "../../actions/messageAction";
import _ from "lodash";
import { resetAttendAllComplaintAction, resetClosedAllComplaintAction, resetRecentAllComplaintAction } from "../../actions/resetAction";
import { setIn } from "formik";

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function FullScreenDialog() {
  const [open, setOpen] = React.useState(false);

  const dispatch:any=useDispatch();
  const addComplaintSelector=useSelector((state:any)=>state.addComplaint);
  const viewComplaintSelector=useSelector((state:any)=>state.viewComplaint);
  const closeComplaintSelector=useSelector((state:any)=>state.closeComplaint);
  const attendAllComplaintSelector=useSelector((state:any)=>state.attendAllComplaint);
  const postMessageSelector=useSelector((state:any)=>state.postMessageComplaint);


  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  React.useEffect(() => {
      // const interval=setInterval(()=>{
    if (
      viewComplaintSelector &&
      viewComplaintSelector.response &&
      viewComplaintSelector.response[0]["INVESTOR_NAME"]
    
    ) {
      dispatch(resetRecentAllComplaintAction());

    }
    //   },1000);
    //  return ()=> clearInterval(interval);
  }, [viewComplaintSelector && viewComplaintSelector.response]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
  if (
    postMessageSelector &&
    postMessageSelector.response &&
    postMessageSelector.response[0]["INVESTOR_NAME"]
  
  ) {
    dispatch(resetAttendAllComplaintAction());

  }
  //   },1000);
  //  return ()=> clearInterval(interval);
}, [postMessageSelector &&
  postMessageSelector.response &&
  postMessageSelector.response[0]]);

  React.useEffect(() => {
    // const interval=setInterval(()=>{
      if (
        closeComplaintSelector &&
        closeComplaintSelector.response &&
        closeComplaintSelector.response[0]["USER_CLOSE_STATUS"]
      
      ) {
        dispatch(resetRecentAllComplaintAction());
        dispatch(resetClosedAllComplaintAction());
        dispatch(resetAttendAllComplaintAction());
  
      }
    // },1000);
    // return ()=> clearInterval(interval);
   
  }, [closeComplaintSelector && closeComplaintSelector.response]);

  React.useEffect(() => {
    if (
      addComplaintSelector &&
      addComplaintSelector.response &&
      addComplaintSelector.response[0]["COMPLAINT_ID"]

    ) {
      Swal.fire({
        icon: "success",
        title: "Complaint posted Successfully!",
        text: `The Complaint ID #${_.padStart(
          addComplaintSelector.response[0]["COMPLAINT_ID"],
          4,
          "0"
        )}`,
        showConfirmButton: false,
        timer: 5000,
      });
      dispatch(
        userViewComplaintAction({
          complaintId: addComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
      dispatch(
        userViewFileAction({
          complaintId: addComplaintSelector.response[0]["COMPLAINT_ID"],
        })
      );
    }
  }, [
   addComplaintSelector && addComplaintSelector.response,
  ]);

  return (
    <div>
      <Button variant="outlined" sx={{borderColor:"white",borderWidth:"solid",borderRadius:"25px",color:"white",mt:0.8}} onClick={handleClickOpen}>
       Add Complaint
      </Button>
      <Dialog 
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}>
        <AppBar sx={{ position: "relative" }}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              sx={{cursor:"auto"}}>
              <Report />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Add a complaint
            </Typography>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close">
              <CloseIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
        <AddComplaint customerName="User" />
      </Dialog>
    </div>
  );
}
