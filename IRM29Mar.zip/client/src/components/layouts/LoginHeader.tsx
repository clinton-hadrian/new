import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import InputBase from "@mui/material/InputBase";
import Badge from "@mui/material/Badge";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MailIcon from "@mui/icons-material/Mail";
import NotificationsIcon from "@mui/icons-material/Notifications";
import MoreIcon from "@mui/icons-material/MoreVert";
import { Avatar, Container, InputAdornment, InputProps } from "@mui/material";
import DarkModeToggle from "react-dark-mode-toggle";
import { useDispatch, useSelector } from "react-redux";
import { changeThemeAction } from "../../actions/themeAction";
import SnackBar from "../Snackbar";
import cameo from "../../images/cameo.png"
import { Navigate, useNavigate } from "react-router-dom";
import { resetAllStateAction } from "../../actions/resetAction";

const LoginHeader = () => {

  const navigate=useNavigate();

  const dispatch: React.Dispatch<any> = useDispatch();
  const verifyMobileOTPSelector=useSelector((state:any)=>state.verifyMobileOTP);
  const getProfileSelector=useSelector((state:any)=>state.getProfile);


 

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          mb: 2,
          px: 4,
          py: 1,
          backgroundColor: "#0A2647"
        }}
        position="sticky">
        <Toolbar>
          <Avatar
            src={cameo}
            sx={{ backgroundColor: "white", width: 60, height: 60, mr: 2 }}
            variant="square"
          />

          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{
              display: { sm: "block",color:"white" },
            }}>
            Welcome to Cameo IRM Portal
          </Typography>

          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
           
            
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
};

export default LoginHeader;
