import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import { Container } from "@mui/system";
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import UserHeader from "./UserHeader";

const CustomerLayout = () => {
  return (
    <Fragment>
      <Box>
          <Header />
          <Outlet />
      </Box>
    </Fragment>
  );
};

export default CustomerLayout;
