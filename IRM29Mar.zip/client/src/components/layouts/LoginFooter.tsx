import React, { Fragment } from 'react'
import cameo from "../../images/cameo.png"

const LoginFooter = () => {
  return (
   <Fragment>
      <footer>
       <div>
       <div className="comp-logo" ><img src={cameo} style={{width:"50px",backgroundColor:"white",height:"50px"}}></img>
            <span className="logo">Cameo Corporate Services</span>
            </div>
       </div>

       <div className="row">
            <div className="col-3">                
                <div className="link-cat" >
                    <span className="footer-toggle"></span>
                    <span className="footer-cat">Sevices</span>
                </div>
                <ul className="footer-cat-links">
                    <li><a href=""><span>Registry and share transfer</span></a></li>
                    <li><a href=""><span>E-Publishing</span></a></li>
                    <li><a href=""><span>Services to BFSI sector</span></a></li>
                    <li><a href=""><span>Healthcare back office</span></a></li>
                    <li><a href=""><span>Services to TELCOs</span></a></li>
                    <li><a href=""><span>Reverse logistics for healthcare</span></a></li>
                </ul>
            </div>
            <div className="col-3">
                <div className="link-cat" >
                    <span className="footer-toggle"></span>
                    <span className="footer-cat">Know</span>
                </div>
                <ul className="footer-cat-links">
                    <li><a href=""><span>About Us</span></a></li>
                    <li><a href=""><span>Our Values</span></a></li>
                    <li><a href=""><span>Our Strength</span></a></li>
                    <li><a href=""><span>Our team</span></a></li>
                    <li><a href=""><span>Disclosures under section 92 (3) of Companies Act, 2013</span></a></li>
                </ul>
            </div>
            <div className="col-3">
                <div className="link-cat" >
                    <span className="footer-toggle"></span>
                    <span className="footer-cat">Quick Links</span>
                </div>
                <ul className="footer-cat-links">
                    {/* <li><a href=""><span>Reviews</span></a></li> */}
                    <li><a href=""><span>Terms & Condition</span></a></li>
                    <li><a href=""><span>Disclaimer</span></a></li>
                    {/* <li><a href=""><span>Site Map</span></a></li> */}
                </ul>
            </div>
            <div className="col-3" id="newsletter">
                {/* <span>Stay Connected</span>
                <form id="subscribe">
                    <input type="email" id="subscriber-email" placeholder="Enter Email Address"/>
                    <input type="submit" value="Subscribe" id="btn-scribe"/>
                </form> */}
                
                <div className="social-links social-2">
                    <a href=""><i className="fab fa-facebook-f"></i></a>
                    <a href=""><i className="fab fa-twitter"></i></a>
                    <a href=""><i className="fab fa-linkedin-in"></i></a>
                    <a href=""><i className="fab fa-instagram"></i></a>
                    <a href=""><i className="fab fa-tumblr"></i></a>
                    <a href=""><i className="fab fa-reddit-alien"></i></a>
                </div>

                <div id="address">
                    <span>Ways to contact us</span>
                    <ul>
                        <li>
                            <i className="fas fa-phone"></i>
                            <div>Call Us:<br/>
                            91-44-28460390</div>
                        </li>
                        <li>
                            <i className="fas fa-fax"></i>
                            <div>Fax Us:<br/>
                            91-44-2846 0129</div>
                        </li>
                        <li>
                            <i className="fas fa-envelope"></i>
                            <div>Email Us:<br/>
                            cameo@cameoindia.com</div>
                        </li>
                    </ul>
                </div>
                
            </div>
            
            <div style={{marginTop:"60px"}}>
            <div className="social-links social-1 col-6">
            <p>Follow Us</p>
                {/* <a href=""><i className="fab fa-facebook-f"></i></a>
                <a href=""><i className="fab fa-twitter"></i></a> */}
                <a href=""><i className="fab fa-linkedin-in"></i></a>
                {/* <a href=""><i className="fab fa-instagram"></i></a>
                <a href=""><i className="fab fa-tumblr"></i></a>
                <a href=""><i className="fab fa-reddit-alien"></i></a> */}
            </div>
            </div>
            
       </div>
       <div id="copyright">
          Copyright © 2023 Cameo Corporate Services Limited
       </div>
       
    </footer>
   </Fragment>
  )
}

export default LoginFooter;
//onClick="footerToggle(this)"