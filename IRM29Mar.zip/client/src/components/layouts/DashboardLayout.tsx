import React, { Fragment } from "react";
import { ProSidebarProvider, useProSidebar } from "react-pro-sidebar";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import UserHeader from "./UserHeader";

const DashboardLayout = () => {
 
  return (
    <Fragment>
      <UserHeader />
      <ProSidebarProvider>
        <Outlet />
      </ProSidebarProvider>
    </Fragment>
  );
};

export default DashboardLayout;
