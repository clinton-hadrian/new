import {
  Grid,
  TextField,
  Typography,
  Radio,
  Autocomplete,
  Input,
  Checkbox,
  FormHelperText,
  createFilterOptions,
} from "@mui/material";
// import Autocomplete from "@mui/material/Autocomplete";
// import Autocomplete from "@material-ui/lab/Autocomplete";
import Fab from "@mui/material/Fab";
import { ErrorMessage, useFormik } from "formik";
import React, { RefObject, useEffect, useRef, useState } from "react";
import * as Yup from "yup";

import AddIcon from "@mui/icons-material/Add";
import InputLabel from "@mui/material/InputLabel";
import Button from "@mui/material/Button";
import AttachmentRoundedIcon from "@mui/icons-material/AttachmentRounded";
import Tooltip from "@mui/material/Tooltip";
import FormLabel from "@mui/material/FormLabel";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { useDispatch, useSelector } from "react-redux";
import {
  addComplaintAction,
  userAddComplaintAction,
} from "../actions/complaintAction";
import pdf from "../images/pdf-file.png";
import jwt_decode from "jwt-decode";
import { FocusError } from "focus-formik-error";
import { postFileAction } from "../actions/messageAction";
import {
  CheckBox,
  CheckBoxOutlineBlankOutlined,
  QuestionMarkRounded,
} from "@mui/icons-material";
// import Autocomplete from '@mui/joy/Autocomplete';

// const folioValidation = Yup.string()
//   .required("Folio or Demat account number is required")
//   .matches(/^[0-9]{8}$/, "Folio must be 8 digits")

// const demantValidation = Yup.string()
//   .required("Folio or Demat account number is required")
//   .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")

// const folioOrDematValidation = Yup.mixed().oneOf(
//   [folioValidation, demantValidation],
//   "Invalid Folio or Demat number"
// );

const supportedFormats = ["png", "jpeg", "pdf", "jpg"];
const supportSize = 2000000;

interface FilmOptionType {
  label: string;
  id: number;
}

const filterOptions = createFilterOptions({
  matchFrom: "start",
  stringify: (option: FilmOptionType) => option.label,
});

interface props {
  customerName: string;
}

const formStyle = {
  padding: "20px 50px 10px",
};

const userValidation = {
  customerEmail: Yup.string()
    .email("Invalid Email")
    .required("Customer email required"),
  customerMobile: Yup.string().required(
    "Customer registered number is required"
  ),
};

// let files: File[] = [];

const AddComplaint: React.FC<props> = (props) => {
  const dispatch: any = useDispatch();
  const companySelector = useSelector((state: any) => state.company);
  const singleQuerySelector = useSelector((state: any) => state.singleQuery);
  const multipleQuerySelector = useSelector(
    (state: any) => state.multipleQuery
  );

  const icon = <CheckBoxOutlineBlankOutlined fontSize="small" />;
  const checkedIcon = <CheckBox fontSize="small" />;

  const sendMobileOTPSelector = useSelector(
    (state: any) => state.sendMobileOTP
  );
  const addProfileSelector = useSelector((state: any) => state.addProfile);
  const verifyMobileOTPSelector = useSelector(
    (state: any) => state.verifyMobileOTP
  );
  const sendCredentialsSelector = useSelector(
    (state: any) => state.sendCredentials
  );
  const viewComplaintSelector = useSelector(
    (state: any) => state.viewComplaint
  );
  const addComplaintSelector = useSelector((state: any) => state.addComplaint);

  const [queryT, setQueryType] = useState("");

  const [fileName, setFileName] = useState("");

  const [images, setImages] = useState<JSX.Element[]>([]);

  const [files, setFiles] = useState<File[]>([]);

  const [queries, setQueries] = useState<Array<{
    label: string;
    id: number;
  }> | null>(null);

  const handleQueryChange = (
    event: React.ChangeEvent<{}>,
    value: Array<{ label: string; id: number }> | null
  ) => {
    setQueries(value || []);
  };

  const delImage = (index: number) => {
    // Remove the file at the given index and create a new array with the remaining files
    setFiles((files) => files.filter((_, i) => i !== index));
    // setFiles(newFiles);
    // showImages(newFiles);
    // const newFileNames = newFiles.map((file) => file.name).join(", ");

    setFileName((fileName) =>
      fileName
        .split(",")
        .filter((_, i) => i !== index)
        .join(",")
    );
    // const deletedFile = files[index];
    // setFileName(prevFileName => {
    //   const fileNameArr = prevFileName.split(", ");
    //   const fileIndex = fileNameArr.indexOf(deletedFile.name);
    //   if (fileIndex !== -1) {
    //     fileNameArr.splice(fileIndex, 1);
    //     return fileNameArr.join(", ");
    //   } else {
    //     return prevFileName;
    //   }
    // });
    console.log(index);
  };

  const showImages = (files: File[]) => {
    const imageElements = files.map((file, index) => {
      // <div className="image" key={file.name}>
      //   {file.type === "application/pdf" ? (
      //     <img src={pdf} alt="PDF" />
      //   ) : (
      //     <img src={URL.createObjectURL(file)} alt={file.name} />
      //   )}
      //   <span onClick={() => delImage(index)}>×</span>
      //   </div>
      console.log(index);
    });
    // setImages(imageElements);
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  // const formRef = useRef<HTMLFormElement>(null);
  // const formRef: RefObject<HTMLDivElement> = useRef(null);
  const [inputValue, setInputValue] = React.useState("");
  const [selectedOption, setSelectedOption] = React.useState<{
    label: string;
    id: number;
  } | null>(null);
  const [companyValue, setCompanyValue] = React.useState("");
  const [selectedCompOption, setSelectedCompOption] = React.useState<{
    label: string;
    id: number;
  } | null>(null);

  const complaintFormik = useFormik({
    initialValues: {
      customerEmail: "",
      customerMobile: "",
      investorName: "",
      companyName: "",
      folioDemat: "",
      pan: "",
      // queryType: "single query",
      query: "",
      problemStatement: "",
      mediaDocument: [],
    },

    validationSchema: Yup.object().shape({
      ...(sendCredentialsSelector &&
        sendCredentialsSelector.response &&
        userValidation),
      investorName: Yup.string()
        .required("Investor name is required"),
      //  .matches(/^[a-zA-Z]+$/, "Name should not contain numbers"),

      companyName: Yup.string().required("Company name is required"),

      folioDemat: Yup.string().test(
        "len",
        "Invalid Folio or Demat account number",
        (val: string | undefined) =>
          val ? val.length === 8 || val.length === 16 : false
      ),
      pan: Yup.string()
        .required("PAN is required")
        .nullable()
        .test(
          "len",
          "Invalid PAN number",

          (val: any) => {
            const regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}/;
            if (typeof val !== "string" || !regex.test(val)) {
              return false;
            }
            return true;

            // return regex.test(val);
          }
        ),
      problemStatement: Yup.string().required("Query is required"),

      // query: Yup.string().required("query field is required"),

      mediaDocument: Yup.array()
        .required("File is required")
        .max(5, "You can upload maximum 5 files")
        // .test("file-upload","maximum 5 files only",(values:any)=>
        // values?.length>5)
        .test("file-size", "File should be 2MB or lower", (values: any) =>
          values?.every((file: File) => file.size <= 2000000)
        )
        .test(
          "file-format",
          "Files should be PDF or any image format",
          (values: File[] | undefined) =>
            values?.every((file) =>
              ["png", "jpeg", "pdf", "jpg", "tiff"].includes(
                file.name.split(".").pop()?.toLowerCase() ?? ""
              )
            ) ?? true
        ),
    }),

    onSubmit: (value) => {
      const formData = new FormData();
      const fileFormData = new FormData();
      formData.append("customerEmail", value.customerEmail);
      formData.append("customerMobile", value.customerMobile);
      formData.append("investorName", value.investorName);
      formData.append("companyName", value.companyName);
      formData.append("folioDemat", value.folioDemat);
      formData.append("pan", value.pan);
      //  formData.append("queryType", value.queryType);
      queries &&
        queries.forEach((query) => {
          formData.append("query", query.label);
        });
      formData.append("problemStatement", value.problemStatement);
      files.forEach((file) => {
        formData.append("files", file);
      });

      if (verifyMobileOTPSelector && verifyMobileOTPSelector.response) {
        dispatch(addComplaintAction(formData));
      } else {
        dispatch(userAddComplaintAction(formData));
      }

      console.log(formData.get("queryType"));
      console.log(queries);

      console.log("hello", queryT);

      complaintFormik.resetForm({
        values: {
          customerEmail: "",
          customerMobile: "",
          investorName: "",
          companyName: "",
          folioDemat: "",
          pan: "",
          //    queryType: "single query",
          query: "",
          problemStatement: "",
          mediaDocument: [],
        },
      });

      setFiles([]);
      setImages([]);
      setFileName("");
      setInputValue("");
      setSelectedOption(null);
      setCompanyValue("");
      setSelectedCompOption(null);
      setQueries([]);
    },
  });

  // if(viewComplaintSelector && viewComplaintSelector.response && viewComplaintSelector.response[0] && viewComplaintSelector.response[0]["INVESTOR_NAME"]){
  //   complaintFormik.resetForm({
  //     values: {
  //       investorName: "",
  //       companyName: "",
  //       folioDemat: "",
  //       queryType: "single query",
  //       query: "",
  //       problemStatement: "",
  //       mediaDocument: "",
  //     },
  //   })
  // }
  console.log(files);
  console.log(complaintFormik.values.mediaDocument);

  // const [searchText, setSearchText] = useState("");
  // const [tableData, setTableData] = useState<any[]>(companySelector && companySelector.response);

  // useEffect(()=>{requestSearch(searchText)},[searchText])

  // const handleSearchInputChange = (event:string) => {
  //   setSearchText(event);
  // };

  // const requestSearch = (searchValue: string) => {
  //   const searchRegex = new RegExp(`.*${searchValue}.*`, "ig");
  //   const ops = companySelector && companySelector.response.filter((o: any) => {
  //     return Object.keys(o).some((k: any) => {
  //       return searchRegex.test(o[k].toString());
  //     });
  //   });
  //   setTableData(ops);
  // };

 
  
  const { customerName } = props;

  return (
    <div
      style={{
        ...(sendCredentialsSelector &&
          sendCredentialsSelector.response &&
          formStyle),
        height: "100%",
      }}>
      <Grid container spacing={3} sx={{ p: 0 }} style={{ height: "100%" }}>
        {verifyMobileOTPSelector && verifyMobileOTPSelector.response && (
          <Grid item xs={12}>
            <Typography
              variant="h3"
              style={{
                fontFamily: "Inter",
                fontWeight: "bold",
                fontSize: "1.8rem",
              }}
              gutterBottom>
              Hi, {customerName}. We are here to assist you !
              <Typography
                gutterBottom
                variant="h4"
                style={{
                  fontFamily: "Inter",
                  fontWeight: "300",
                  fontSize: "1rem",
                  marginTop: 5,
                }}>
                Please complete the form below for your complaints
              </Typography>
            </Typography>
          </Grid>
        )}
        <FocusError formik={complaintFormik} />
        {sendCredentialsSelector &&
          sendCredentialsSelector.response &&
          sendCredentialsSelector.response[0] && (
            <>
              <Grid item xs={12} md={6}>
                <TextField
                  type="text"
                  value={complaintFormik.values.customerEmail}
                  name="customerEmail"
                  onBlur={complaintFormik.handleBlur}
                  label="Customer Email"
                  onChange={complaintFormik.handleChange}
                  placeholder="Enter customer email here"
                  fullWidth
                  error={Boolean(
                    complaintFormik.touched.customerEmail &&
                      complaintFormik.errors.customerEmail
                  )}
                  helperText={
                    complaintFormik.touched.customerEmail &&
                    complaintFormik.errors.customerEmail
                  }
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  type="text"
                  value={complaintFormik.values.customerMobile}
                  name="customerMobile"
                  onBlur={complaintFormik.handleBlur}
                  label="Customer Nobile Number"
                  onChange={complaintFormik.handleChange}
                  placeholder="Enter customer Mobile Number here"
                  fullWidth
                  error={Boolean(
                    complaintFormik.touched.customerMobile &&
                      complaintFormik.errors.customerMobile
                  )}
                  helperText={
                    complaintFormik.touched.customerMobile &&
                    complaintFormik.errors.customerMobile
                  }
                />
              </Grid>
            </>
          )}
        <Grid item xs={12} md={12}>
          <TextField
            required
            type="text"
            value={complaintFormik.values.investorName}
            name="investorName"
            onBlur={complaintFormik.handleBlur}
            label="Investor Name"
            onChange={complaintFormik.handleChange}
            placeholder="Enter Investor Name"
            fullWidth
            error={Boolean(
              complaintFormik.touched.investorName &&
                complaintFormik.errors.investorName
            )}
            helperText={
              complaintFormik.touched.investorName &&
              complaintFormik.errors.investorName
            }
          />
        </Grid>
        <Grid item xs={12} md={12}>
        <Autocomplete
 options={
  companySelector && companySelector.response && typeof companySelector.response !== 'string'
    ? Array.from(new Set(companySelector.response.map((option:any) => option.label)))
      .map(label => ({ label }))
    : []
}
  getOptionLabel={(option:any) => option.label}
  value={selectedCompOption}
  onChange={(event, newValue:any) => {
    setSelectedCompOption(newValue);
    complaintFormik.setFieldValue("companyName", newValue?.label);
  }}
  isOptionEqualToValue={(option, value) => {
    console.log('isOptionEqualToValue', option.label, value.label);
    return option.label === value.label;
  }}
  inputValue={companyValue}
  onInputChange={(event, newInputValue) => {
    setCompanyValue(newInputValue);
  }}
  renderInput={(params) => (
    <TextField
      {...params}
      name="companyName"
      value={complaintFormik.values.companyName}
      label="Company name*"
      variant="outlined"
      fullWidth
    />
  )}
/>


        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            required
            fullWidth
            error={Boolean(
              complaintFormik.touched.folioDemat &&
                complaintFormik.errors.folioDemat
            )}
            id="folio-login"
            type="numeric"
            value={complaintFormik.values.folioDemat}
            name="folioDemat"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter Folio No / Demat ACC No"
            helperText={
              complaintFormik.touched.folioDemat &&
              complaintFormik.errors.folioDemat
            }
            label="Folio Number (or) Demat Account Number"
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.pan && complaintFormik.errors.pan
            )}
            id="pan-login"
            type="numeric"
            value={complaintFormik.values.pan}
            name="pan"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter PAN number here"
            helperText={
              complaintFormik.touched.pan && complaintFormik.errors.pan
            }
            label="PAN"
          />
        </Grid>

        <Grid item xs={12} md={12}>
          {/* <Autocomplete
            options={queryT=="single query"?singleQuerySelector && singleQuerySelector.response : multipleQuerySelector && multipleQuerySelector.response}
            getOptionLabel={(option) => option.label}
            value={selectedOption}
            onChange={(event, newValue) => {
              setSelectedOption(newValue);
              complaintFormik.setFieldValue("query", newValue?.label);
            }}
            isOptionEqualToValue={(option, value) =>
              option.label === value.label
            }
            inputValue={inputValue}
            onInputChange={(event, newInputValue) => {
              setInputValue(newInputValue);
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                name="query"
                value={complaintFormik.values.query}
                label="Queries*"
                variant="outlined"
                fullWidth
              />
            )}
          /> */}
          <Autocomplete
            value={queries || []}
            multiple
            limitTags={2}
            options={
              singleQuerySelector && singleQuerySelector.response
                ? singleQuerySelector.response
                : "LOADING"
            }
            disableCloseOnSelect
            getOptionLabel={(option) => option.label}
            renderOption={(props, option, { selected }) => (
              <li {...props}>
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  style={{ marginRight: 8 }}
                  checked={selected}
                />
                {option.label}
              </li>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Queries"
                placeholder="Select Query"
              />
            )}
            onChange={handleQueryChange}
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <TextField
            required
            fullWidth
            error={Boolean(
              complaintFormik.touched.problemStatement &&
                complaintFormik.errors.problemStatement
            )}
            id="conteproblemStatementnt"
            type="text"
            value={complaintFormik.values.problemStatement}
            name="problemStatement"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter your query here"
            helperText={
              complaintFormik.touched.problemStatement &&
              complaintFormik.errors.problemStatement
            }
            label="Query"
            multiline
            rows={4}
          />
          <FormHelperText sx={{ marginLeft: "auto", color: "#144272" }}>
            Do not exceed 1000 characters
          </FormHelperText>
        </Grid>
        <Grid item xs={12}>
          <InputLabel htmlFor="upload-photo" />
          <TextField
            inputProps={{ multiple: true,accept: 'image/*,application/pdf' }}
            className="inputField"
            style={{ display: "none" }}
            id="upload-photo"
            name="mediaDocument"
            type="file"
            inputRef={fileInputRef}
            onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
              const mediaDocument = event.target.files;
              if (mediaDocument) {
                // complaintFormik.handleChange({
                //   target: {
                //     name: "mediaDocument",
                //     value: event.target.files,
                //   },
                // });
                complaintFormik.setFieldValue(
                  "mediaDocument",
                  Array.from(mediaDocument)
                );
              }
              const selectedFiles = event.target.files;
              if (selectedFiles) {
                // Update the files array using the state updater function to add new files
                setFiles((prevFiles) => [
                  ...prevFiles,
                  ...Array.from(selectedFiles),
                ]);
                //   const selectedFileNames = Array.from(selectedFiles)
                //   .map((file) => file.name)
                //   .join(", ");
                // setFileName(selectedFileNames);
                setFileName(
                  (prevFileName) =>
                    prevFileName +
                    // ", " +
                    Array.from(selectedFiles)
                      .map((file) => file.name)
                      .join(", ")
                );

                showImages([...files, ...Array.from(selectedFiles)]);
              }
            }}
            // value={complaintFormik.values.mediaDocument}
            // error={Boolean(
            //   complaintFormik.touched.mediaDocument &&
            //     complaintFormik.errors.mediaDocument
            // )}
            // helperText={
            //   complaintFormik.touched.mediaDocument &&
            //   complaintFormik.errors.mediaDocument
            // }
          />

          <Tooltip title="Attachment" placement="right">
            <Fab
              id="custom-button"
              color="primary"
              size="small"
              component="span"
              aria-label="add"
              variant="extended"
              sx={{ borderRadius: "50%" }}
              onClick={() => {
                fileInputRef.current?.click();
              }}>
              <AttachmentRoundedIcon />
            </Fab>
          </Tooltip>
          <span style={{ marginLeft: "1.5rem" }} id="custom-text">
            {fileName}
          </span>
          <div className="img-container">
            {files.map((file, index) => {
              return (
                <>
                  <div className="image" key={file.name}>
                    {file.type === "application/pdf" ? (
                      <img src={pdf} alt="PDF" />
                    ) : (
                      <img src={URL.createObjectURL(file)} alt={file.name} />
                    )}
                    <span onClick={() => delImage(index)}>×</span>
                  </div>
                </>
              );
            })}
          </div>
        </Grid>
        <Grid sx={{}} style={{ paddingTop: "2px" }} item md={9} xs={12}>
          {Boolean(
            complaintFormik.touched.mediaDocument &&
              complaintFormik.errors.mediaDocument
          ) ? (
            <FormHelperText style={{}} error>
              {complaintFormik.errors.mediaDocument}{" "}
            </FormHelperText>
          ) : (
            <FormHelperText>
              The file should be atleast 2MB and can be PDF or any image format
            </FormHelperText>
          )}
        </Grid>

        <Grid item xs={12} md={12}>
          <Button
            disableElevation
            // disabled={isSubmitting}
            size="large"
            type="submit"
            variant="contained"
            color="primary"
            sx={{ borderRadius: "15px" }}
            onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
              // e.preventDefault(); // prevent the default behavior
              complaintFormik.handleSubmit();
            }}
            fullWidth>
            Submit
          </Button>
        </Grid>
      </Grid>
    </div>
  );
};

{
  /* <Grid item xs={12} md={12}>
          <FormLabel>Your Selection Type ?</FormLabel>
          <RadioGroup
            row
            name="queryType"
            value={complaintFormik.values.queryType}
            onChange={(e) => {
              complaintFormik.handleChange(e);
              setQueryType(e.target.value);
            }}>
            <FormControlLabel
              value="single query"
              control={<Radio />}
              label="Single Query"
            />
            <FormControlLabel
              value="multiple query"
              control={<Radio />}
              label="Multiple Query"
            />
          </RadioGroup>
        </Grid> */
}

export default AddComplaint;
