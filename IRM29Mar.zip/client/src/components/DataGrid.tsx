import { Box, TextField } from "@mui/material";
import React, { Fragment, useEffect, useState } from "react";
import { DataGrid as Grid, GridToolbar} from "@mui/x-data-grid";
import { AnyCnameRecord } from "dns";
import { useDispatch, useSelector } from "react-redux";
import { userClosedListAction } from "../actions/userAction";

interface props {
  rows: any;
  columns: any;
  onClic: (name: string) => void;

}

const DataGrid: React.FC<props> = (props) => {
  const { rows, columns } = props; 

  const { onClic } = props;
  
  const dispatch:any=useDispatch();
  const userClosedListSelector=useSelector((state:any)=>state.userClosedList);

  const [searchText, setSearchText] = useState("");
  const [tableData, setTableData] = useState<any[]>(rows);

  useEffect(()=>{requestSearch(searchText)},[searchText])

  const handleSearchInputChange = (event:any) => {
    setSearchText(event.target.value);
  };

  const handleRowClick = (params:any) => {
    dispatch(userClosedListAction({
        userId:params.row.USER_CLOSE_BY
    }))
    const name="closedList";
    onClic(name);
  };

 
  const requestSearch = (searchValue: string) => {
    const searchRegex = new RegExp(`.*${searchValue}.*`, "ig");
    const filteredRows = rows.filter((o: any) => {
      return Object.keys(o).some((k: any) => {
        return searchRegex.test(o[k].toString());
      });
    });
    setTableData(filteredRows);
  };

  const cancelSearch = () => {
    setSearchText("");
    requestSearch(searchText);
  };

  return (
    <Fragment>
      <Box m="20px">
        <Box
          m="8px 0 0 0"
          width="100%"
          height="40vh"
          sx={{
            "& .MuiDataGrid-root": {
              border: "none",
            },
            "& .MuiDataGrid-cell": {
              color: "#fff !important",
              borderBottom: "none",
            },
            "& .name-column--cell": {
              color: "#94e2cd !important",
            },
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: "#0A2647 !important",
              color: "#fff !important",
              borderBottom: "none",
            },
            "& . css-128fb87-MuiDataGrid-toolbarContainer": {
              backgroundColor: "#0A2647 !important",
              color: "#fff !important",
              borderBottom: "none",
            },
            "& . css-11m8xr4": {
              color: "#0A2647 !important",
            },

            "& .MuiDataGrid-virtualScroller": {
              backgroundColor: "#2C74B3 !important",
            },
            "& .css-rtrcn9-MuiTablePagination-root ": {
              color: "#fff !important",
            },
            "& .css-pqjvzy-MuiSvgIcon-root-MuiSelect-icon": {
              color: "#fff !important",
            },
            "& .MuiDataGrid-footerContainer": {
              borderTop: "none",

              backgroundColor: "#144272 !important",
            },
            "& .MuiDataGrid-sortIcon, .MuiDataGrid-menuIconButton": {
              color: "#fff !important",
            },

            "& .css-zylse7-MuiButtonBase-root-MuiIconButton-root": {
              color: "#b7ebde ",
            },
            "& .MuiCheckbox-root": {
              color: "#b7ebde !important",
            },
            "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
              color: "#1F2A40 !important",
            },
          }}>
               <TextField
        label="Quick Search"
        variant="outlined"
        size="small"
        value={searchText}
        onChange={(e)=>{
          handleSearchInputChange(e)
        }}
      />
 
          <Grid
          className="closedList"
          onRowClick={ handleRowClick}

            rows={searchText?tableData:rows}
            columns={columns}
            components={{ Toolbar: GridToolbar }}
            componentsProps={{
              toolbar: {
                value: searchText,
                onChange: (event: React.FormEvent<HTMLDivElement>) => {
                  const searchVal = (event.target as HTMLInputElement).value;
                  requestSearch(searchVal);
                }
              }
            }}
            //   componentsProps={{
            //     panel: {
            //       sx: {
            //         '& .MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation8.MuiDataGrid-paper.css-154sxbz-MuiPaper-root-MuiDataGrid-paper': {
            //           maxHeight: '15rem !important',
            //           overFlow: 'auto'
            //         },

            //       },
            //     },
            //   }}
          />
        </Box>
      </Box>
    </Fragment>
  );
};

export default DataGrid;
