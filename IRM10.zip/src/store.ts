import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { addProfileReducer } from "./reducers/authReducer";
import { sendMobileOTPReducer, verifyMobileOTPReducer } from "./reducers/authReducer";
import { userLoginReducer } from "./reducers/complaintReducer";
import { changeThemeReducer } from "./reducers/themeReducer";



const rootReducer = combineReducers({
  theme: changeThemeReducer,
  sendMobileOTP: sendMobileOTPReducer,
  userLogin: userLoginReducer,
  addProfile:addProfileReducer,
  verifyMobileOTP: verifyMobileOTPReducer,
});

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
});



// const themeValue = localStorage.getItem("theme")
//   ? localStorage.getItem("theme")
//   : "light";
// const initialReducer = {
//   theme: { mode: themeValue },
// };

export default store;
