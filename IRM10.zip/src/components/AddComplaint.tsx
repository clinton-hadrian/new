import { Grid, TextField, Typography, Radio } from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import Fab from "@mui/material/Fab";
import { useFormik } from "formik";
import React from "react";
import * as Yup from "yup";

import AddIcon from "@mui/icons-material/Add";
import InputLabel from "@mui/material/InputLabel";
import Button from "@mui/material/Button";
import AttachmentRoundedIcon from "@mui/icons-material/AttachmentRounded";
import Tooltip from "@mui/material/Tooltip";
import FormLabel from "@mui/material/FormLabel";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { RadioRounded } from "@mui/icons-material";

const folioValidation = Yup.string()
  .required("Folio or Demat account number is required")
  .matches(/^[0-9]{8}$/, "Folio must be 6 digits")
  .required("Folio or Demant A/c number is required");

const demantValidation = Yup.string()
  .required("Folio or Demat account number is required")
  .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")
  .required("Folio or Demant A/c number is required");

const folioOrDematValidation = Yup.mixed().oneOf(
  [folioValidation, demantValidation],
  "Invalid Folio or Demat number"
);

const supportedFormats = ["png", "jpeg", "pdf"];
const supportSize = 1000000;

interface props {
  customerName: string;
}

const AddComplaint: React.FC<props> = (props) => {
  const complaintFormik = useFormik({
    initialValues: {
      investor: "",
      company: "",
      folio: "",
      radioQuery: "single query",
      query: "",
      content: "",
      file: "",
    },

    validationSchema: Yup.object().shape({
      shareholder: Yup.string()
        .required("Shareholder name is required")
        .matches(/^[a-zA-Z]+$/, "Name should not contain numbers"),

      company: Yup.string().required("Company name is required"),

      folio: folioOrDematValidation,

      query: Yup.string().required(),

      File: Yup.mixed()
        .required("File is required")
        .test(
          "file-size",
          "File should be 1MB or lower",
          (values) => values && values.size <= supportSize
        )
        .test(
          "test-format",
          "Files should be PNG, JPEG, PDF",
          (values) =>
            values && supportedFormats.includes(values.type.split("/")[1])
        ),
    }),

    onSubmit: (values) => {
      console.log(values);
    },
  });

  const { customerName } = props;

  return (
    <div>
      <Grid container spacing={3} sx={{ p: 0 }}>
        <Grid item xs={12}>
          <Typography
            variant="h3"
            style={{
              fontFamily: "Inter",
              fontWeight: "bold",
              fontSize: "1.8rem",
            }}
            gutterBottom
          >
            Hi, {customerName}. We are here to assist you !
            <Typography
              gutterBottom
              variant="h4"
              style={{
                fontFamily: "Inter",
                fontWeight: "300",
                fontSize: "1rem",
                marginTop: 5,
              }}
            >
              Please complete the form below for your complaints
            </Typography>
          </Typography>
        </Grid>
        <Grid item xs={12} md={12}>
          <TextField
            type="text"
            value={complaintFormik.values.investor}
            name="investor"
            onBlur={complaintFormik.handleBlur}
            label="Investor Name"
            onChange={complaintFormik.handleChange}
            placeholder="Enter Investor Name"
            fullWidth
            error={Boolean(
              complaintFormik.touched.investor &&
                complaintFormik.errors.investor
            )}
            helperText={
              complaintFormik.touched.investor &&
              complaintFormik.errors.investor
            }
          />
        </Grid>
        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.company && complaintFormik.errors.company
            )}
            id="company-login"
            type="text"
            value={complaintFormik.values.company}
            name="company"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter Company Name"
            helperText={
              complaintFormik.touched.company && complaintFormik.errors.company
            }
            label="Company on which shares held"
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.folio && complaintFormik.errors.folio
            )}
            id="folio-login"
            type="numeric"
            value={complaintFormik.values.folio}
            name="folio"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter Folio No / Demat ACC No"
            helperText={
              complaintFormik.touched.folio && complaintFormik.errors.folio
            }
            label="Folio Number (or) Demat Account Number"
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <FormLabel>Your Selection Type ?</FormLabel>
          <RadioGroup
            row
            name="radioQuery"
            value={complaintFormik.values.radioQuery}
            onChange={complaintFormik.handleChange}
          >
            <FormControlLabel
              value="single query"
              control={<Radio />}
              label="Single Query"
            />
            <FormControlLabel
              value="multiple query"
              control={<Radio />}
              label="Multiple Query"
            />
          </RadioGroup>
        </Grid>

        <Grid item xs={12} md={12}>
          <Autocomplete
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Select Query"
            disablePortal
            options={queries}
            sx={{}}
            renderInput={(params) => (
              <TextField
                {...params}
                error={Boolean(
                  complaintFormik.touched.query && complaintFormik.errors.query
                )}
                value={complaintFormik.values.query}
                helperText={
                  complaintFormik.touched.folio && complaintFormik.errors.folio
                }
                fullWidth
                name="query"
                label="Query"
              />
            )}
          />
        </Grid>

        <Grid item xs={12} md={12}>
          <TextField
            fullWidth
            error={Boolean(
              complaintFormik.touched.content && complaintFormik.errors.content
            )}
            id="content"
            type="text"
            value={complaintFormik.values.content}
            name="content"
            onBlur={complaintFormik.handleBlur}
            onChange={complaintFormik.handleChange}
            placeholder="Enter your complaint here"
            helperText={
              complaintFormik.touched.content && complaintFormik.errors.content
            }
            label="Complaint"
            multiline
            rows={4}
          />
        </Grid>

        <Grid item xs={12}>
          <InputLabel htmlFor="upload-photo" />
          <TextField
            style={{ display: "none" }}
            id="upload-photo"
            name="upload-photo"
            type="file"
            error={Boolean(
              complaintFormik.touched.file && complaintFormik.errors.file
            )}
            helperText={
              complaintFormik.touched.file && complaintFormik.errors.file
            }
          />
          <Tooltip title="Attachment" placement="right">
            <Fab
              color="primary"
              size="small"
              component="span"
              aria-label="add"
              variant="extended"
              sx={{ borderRadius: "50%" }}
            >
              <AttachmentRoundedIcon />
            </Fab>
          </Tooltip>
        </Grid>

        <Grid item xs={12} md={12}>
          <Button
            disableElevation
            // disabled={isSubmitting}
            size="large"
            type="submit"
            variant="contained"
            color="primary"
            sx={{ borderRadius: "15px" }}
            fullWidth
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </div>
  );
};

const queries = [
  { label: "Updation of Change of address", id: 1 },
  { label: "Updation  of KYC", id: 2 },
  { label: "Share certificate Lost", id: 3 },
  { label: "Shareholder/s deceased", id: 4 },
  { label: "IEPF Claim", id: 5 },
  { label: "Status of documents submitted", id: 6 },
  { label: "Name Change/ Correction", id: 7 },
  { label: "Non-receipt of New certificate (company name change)", id: 8 },
  { label: "Non-receipt of stickers  (company name change)", id: 9 },
  { label: "Non-receipt of Dividends", id: 10 },
  { label: "Non-receipt of Demat Rejected Documents", id: 11 },
  { label: "Status of demat request", id: 12 },
  { label: "Non-receipt of Rights shares", id: 13 },
  { label: "Status of IPO allotment", id: 14 },
  { label: "Status of shares", id: 15 },
  { label: "Non-receipt of annual report", id: 16 },
];

export default AddComplaint;
