import  { useState } from "react";
import _ from "lodash";
import {
  Fab,
  Box,
  Grid,
} from "@mui/material";
import AddProfile from "../../components/AddProfile";
import ViewComplaint from "../../components/ViewComplaint";
import ListComplaint from "../../components/ListComplaint";
import { Add } from "@mui/icons-material";
import ComplaintsList from "../../components/ComplaintsList";
import AddComplaint from "../../components/AddComplaint";
import { useSelector } from "react-redux";
import SnackBar from "../../components/Snackbar";


const Complaint = () => {

  const AddProfileSelector=useSelector((state:any)=>state.addProfile)
  const sendMobileOTPSelector=useSelector((state:any)=>state.sendMobileOTP)

  const [addProfile, setAddProfile] = useState(sendMobileOTPSelector.response[0]["NAME"]?false:true);
  const [open,setOpen]=useState("add");
  const [snackBarProfile,setSnackBarProfile]= useState(false)

  function toggle(name:string){
    if(name=="complaint"){
      setOpen("complaint")
    }
    else if(name=="view"){
      setOpen("view")
    }
else if(name=="add")
{
  setOpen("add")

}
  }

  function boggle(name:boolean){
    setSnackBarProfile(name)
  }

  return (
    <>
      <Box
        sx={{
          position: "inline-flex",
          direction: "row",
          marginX: 1,
          marginY: 1,
          overflow: "auto",
          justifyContent: "center",
          p: 1,
          filter:addProfile?"blur(8px)":"",
          transition: "filter 0.8s ease-out",
          
        }}
        style={{}}>
        <AddProfile
        onClick={boggle}
          open={addProfile}
          handleClose={() => {
            if(AddProfileSelector.response){
              setAddProfile(false)
            }
            setAddProfile(false);
          }}
        />
        <Grid container>
          <Grid item xs={12} md={8}>
            <Box
         
              sx={{
                display: "flex",
                direction: "row",
                p: 2,
                mr: 0,
                overflow: "auto",
                maxHeight: "102vh",
               
              }}>
                {AddProfileSelector && AddProfileSelector.response ? (
        <SnackBar
          severity="success"
          handleClose={() => {
            setSnackBarProfile(false);
          }}
          message="Profile added successfully!"
          open={snackBarProfile}
        />
      ):( AddProfileSelector && AddProfileSelector.error && (
        <SnackBar
          severity= "error"
          handleClose={() => {
            setSnackBarProfile(false);
          }}
          message="Problem in adding the profile"
          open={snackBarProfile}
        />)
      )}
            
             {open=="add" && sendMobileOTPSelector.response && sendMobileOTPSelector.response[0]["NAME"]? (<AddComplaint customerName={_.capitalize(sendMobileOTPSelector.response[0]["NAME"])} />) : AddProfileSelector.response && <AddComplaint customerName={_.capitalize(AddProfileSelector.response[0]["NAME"])} />}
             {open=="view" && <ComplaintsList onClick={toggle}  />}
             {open=="complaint" && <ViewComplaint  />}
             
            </Box>
          </Grid>

          <Grid
            sx={{ borderLeft: "solid", borderWidth: "1px" }}
            item
            xs={12}
            md={4}>
            <Box
              className="scroll"
              sx={{
                display: "flex",
                flex: 1,
                direction: "row",
                justifyContent: "center",
                p: 1,
                ml: 2,
                overflow: "hidden",
                maxHeight: "102vh",
                
              }}>
             <ListComplaint  onClick={toggle} />
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box visibility={open!=="add"?"visible":"hidden"} onClick={()=>{setOpen("add")}} sx={{ bottom: 10, right: 15, position: "fixed" }}>
        <Fab name="add"  color="secondary">
          <Add />
        </Fab>
      </Box>
    </>
  );
};

export default Complaint;
