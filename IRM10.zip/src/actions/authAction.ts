import axios from "axios";
import { AnyAction, Dispatch } from "redux";
import {
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS,
  SEND_MOBILE_OTP_FAILED,
} from "../constants/authConstant";

import { VERIFY_MOBILE_OTP_FAILED,
   VERIFY_MOBILE_OTP_REQUEST, 
  VERIFY_MOBILE_OTP_SUCCESS } from "../constants/authConstant";

import { API } from "../data";
import {
  ADD_PROFILE_REQUEST,
  ADD_PROFILE_SUCCESS,
  ADD_PROFILE_FAILED
} from "../constants/authConstant";

export const sendMobileOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: SEND_MOBILE_OTP_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/sendMobileOTP`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: SEND_MOBILE_OTP_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: SEND_MOBILE_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};

export const verifyMobileOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: VERIFY_MOBILE_OTP_REQUEST,
    });

    const { data } = await axios.post(`${API}/Auth/OTPVerification`, form, {
      headers: { "Content-Type": "application/json" },
    });

    dispatch({
      type: VERIFY_MOBILE_OTP_SUCCESS,
      payload: data,
    });

  } catch (error: any) {
    dispatch({
      type: VERIFY_MOBILE_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};

export const addProfileAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: ADD_PROFILE_REQUEST,    
    });
    const { data } = await axios.post(`${API}/Auth/addProfile`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: ADD_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: ADD_PROFILE_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};

