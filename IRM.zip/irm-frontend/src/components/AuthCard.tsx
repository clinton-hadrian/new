import PropTypes from 'prop-types';

// material-ui
import { Box, CardContent } from '@mui/material';
import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

// project import




// ==============================|| AUTHENTICATION - CARD WRAPPER ||============================== //

// interface Props{
//     children:React.ReactNode
// }

// const AuthCard:React.FC<Props> = ({ children, ...other }) => (
//     <MainCard
//         sx={{
//             maxWidth: { xs: 400, lg: 475 },
//             margin: { xs: 2.5, md: 3 },
//             '& > *': {
//                 flexGrow: 1,
//                 flexBasis: '50%'
//             }
//         }}
//         content={false}
//         {...other}
//         border={false}
//         boxShadow
//         shadow={(theme) => theme.customShadows.z1}
//     >
//         <Box sx={{ p: { xs: 2, sm: 3, md: 4, xl: 5 } }}>{children}</Box>
//     </MainCard>
// );



// export default AuthCard;

interface Props{
    children:React.ReactNode
}

 const AuthCard:React.FC<Props>= ({children}) =>{
    return (
    <>
    
        <Card sx={{maxWidth:345}}>
        <CardContent>
        <Typography  variant="h5" gutterBottom>
        Login
        </Typography>
        </CardContent>
        <CardContent>
        <Box sx={{ p: { xs: 2, sm: 3, md: 4, xl: 5 } }}>{children}</Box>
        </CardContent>
        </Card>
        </>
    )
}

export default AuthCard;