import { ErrorMessage, Formik, useFormik } from "formik";
import React, { Fragment } from "react";
import * as Yup from "yup";

import AddIcon from "@mui/icons-material/Add";

import {
  Button,
  Fab,
  Card,
  Box,
  CardContent,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Autocomplete,
  MenuItem,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  TextField,
} from "@mui/material";

const Complaint = () => {
  const folioValidation = Yup.string()
    .required("Folio or Demat account number is required")
    .matches(/^[0-9]{8}$/, "Folio must be 6 digits")
    .required("Folio or Demant A/c number is required");

  const demantValidation = Yup.string()
    .required("Folio or Demat account number is required")
    .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")
    .required("Folio or Demant A/c number is required");

  const folioOrDematValidation = Yup.mixed().oneOf(
    [folioValidation, demantValidation],
    "Invalid Folio or Demat number"
  );

  const customerName = "customer";

  const supportedFormats = ["png", "jpeg", "pdf"];
  const supportSize = 1000000;

  const complaintFormik = useFormik({
    initialValues: {
      shareholder: "",
      company: "",
      folio: "",
      query: "",
      content: "",
      file: "",
    },

    validationSchema: Yup.object().shape({
      shareholder: Yup.string()
        .required("Shareholder name is required")
        .matches(/^[a-zA-Z]+$/, "Name should not contain numbers"),

      company: Yup.string().required("Company name is required"),

      folio: folioOrDematValidation,

      query: Yup.string().required(),

      File: Yup.mixed()
        .required("File is required")
        .test(
          "file-size",
          "File should be 1MB or lower",
          (values) => values && values.size <= supportSize
        )
        .test(
          "test-format",
          "Files should be PNG, JPEG, PDF",
          (values) =>
            values && supportedFormats.includes(values.type.split("/")[1])
        ),
    }),

    onSubmit: (values) => {
      console.log(values);
    },
  });

  return (
    <Box
      sx={{
        position: "inline-flex",
        direction: "row",
        marginX: 1,
        marginY: 4,
        borderRadius: "15px",
        overflow: "auto",
        justifyContent: "center",
        p: 2,
      }}
      style={{ backgroundColor: "#FFCEFE" }}
    >
      <Box
        sx={{
          display: "flex",
          direction: "column",
          justifyContent: "center",
          height: "87vh",
          p: 2,
          overflow: "auto",
        }}
        style={{ backgroundColor: "#F0ECCF" }}
      >
        <Grid container spacing={3} sx={{ p: 2 }}>
          <Grid item xs={12}>
            <Typography
              variant="h3"
              style={{
                fontFamily: "Inter",
                fontWeight: "bold",
                fontSize: "1.8rem",
              }}
              gutterBottom
            >
              Hi, {customerName}. We are here to assist you !
              <Typography
                gutterBottom
                variant="h4"
                style={{
                  fontFamily: "Inter",
                  fontWeight: "300",
                  fontSize: "1rem",
                  marginTop: 5,
                }}
              >
                Please complete the form below for your complaints
              </Typography>
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              id="shareholder-login"
              type="text"
              value={complaintFormik.values.shareholder}
              name="phone"
              onBlur={complaintFormik.handleBlur}
              label="Shareholder / Claimant Name"
              onChange={complaintFormik.handleChange}
              placeholder="Enter Shareholder / Claimant Name"
              fullWidth
              error={Boolean(
                complaintFormik.touched.shareholder &&
                  complaintFormik.errors.shareholder
              )}
              helperText={
                complaintFormik.touched.shareholder &&
                complaintFormik.errors.shareholder
              }
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              error={Boolean(
                complaintFormik.touched.company &&
                  complaintFormik.errors.company
              )}
              id="-company-login"
              type="text"
              value={complaintFormik.values.company}
              name="company"
              onBlur={complaintFormik.handleBlur}
              onChange={complaintFormik.handleChange}
              placeholder="Enter Company Name"
              helperText={
                complaintFormik.touched.company &&
                complaintFormik.errors.company
              }
              label="Company on which shares held"
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              error={Boolean(
                complaintFormik.touched.folio && complaintFormik.errors.folio
              )}
              id="-company-login"
              type="numeric"
              value={complaintFormik.values.folio}
              name="folio"
              onBlur={complaintFormik.handleBlur}
              onChange={complaintFormik.handleChange}
              placeholder="Enter Folio No / Demat ACC No"
              helperText={
                complaintFormik.touched.folio && complaintFormik.errors.folio
              }
              label="Folio Number (or) Demat Account Number"
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <Autocomplete
              id="-query-login"
              onBlur={complaintFormik.handleBlur}
              onChange={complaintFormik.handleChange}
              placeholder="Select Query"
              disablePortal
              options={queries}
              sx={{}}
              renderInput={(params) => (
                <TextField
                  {...params}
                  error={Boolean(
                    complaintFormik.touched.query &&
                      complaintFormik.errors.query
                  )}
                  value={complaintFormik.values.query}
                  helperText={
                    complaintFormik.touched.folio &&
                    complaintFormik.errors.folio
                  }
                  fullWidth
                  name="query"
                  label="Query"
                />
              )}
            />
          </Grid>

          <Grid item xs={12} md={12}>
            <TextField
              fullWidth
              error={Boolean(
                complaintFormik.touched.content &&
                  complaintFormik.errors.content
              )}
              id="content"
              type="text"
              value={complaintFormik.values.content}
              name="content"
              onBlur={complaintFormik.handleBlur}
              onChange={complaintFormik.handleChange}
              placeholder="Enter your complaint here"
              helperText={
                complaintFormik.touched.content &&
                complaintFormik.errors.content
              }
              label="Complaint"
              multiline
              rows={4}
            />
          </Grid>

          <Grid item xs={12}>
            <InputLabel htmlFor="upload-photo" />
            <TextField
              style={{ display: "none" }}
              id="upload-photo"
              name="upload-photo"
              type="file"
              error={Boolean(
                complaintFormik.touched.file && complaintFormik.errors.file
              )}
              helperText={
                complaintFormik.touched.file && complaintFormik.errors.file
              }
            />
            <Fab
              color="primary"
              size="small"
              component="span"
              aria-label="add"
              variant="extended"
            >
              <AddIcon /> Upload photo
            </Fab>
          </Grid>

          <Grid item xs={12} md={2}>
            <Button
              disableElevation
              // disabled={isSubmitting}
              size="large"
              type="submit"
              variant="contained"
              color="primary"
              sx={{}}
              fullWidth
            >
              Submit
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

const queries = [
  { label: "Updation of Change of address", id: 1 },
  { label: "Updation  of KYC", id: 2 },
  { label: "Share certificate Lost", id: 3 },
  { label: "Shareholder/s deceased", id: 4 },
  { label: "IEPF Claim", id: 5 },
  { label: "Status of documents submitted", id: 6 },
  { label: "Name Change/ Correction", id: 7 },
  { label: "Non-receipt of New certificate (company name change)", id: 8 },
  { label: "Non-receipt of stickers  (company name change)", id: 9 },
  { label: "Non-receipt of Dividends", id: 10 },
  { label: "Non-receipt of Demat Rejected Documents", id: 11 },
  { label: "Status of demat request", id: 12 },
  { label: "Non-receipt of Rights shares", id: 13 },
  { label: "Status of IPO allotment", id: 14 },
  { label: "Status of shares", id: 15 },
  { label: "Non-receipt of annual report", id: 16 },
];

export default Complaint;
