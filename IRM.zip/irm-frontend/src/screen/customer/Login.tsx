import React, { Fragment, useState } from "react";
import OtpInput from "react18-input-otp";
import {
  Button,
  Box,
  Typography,
  CardContent,
  TextField,
  Paper,
  Grid,
} from "@mui/material";

import * as Yup from "yup";
import phone from "yup-phone";
import { ErrorMessage, useFormik } from "formik";

interface props {
  mobile: string;
  email: string;
}

const otpBorder = {
  width: "20%",
  margin: "0 5px",
  borderRadius: "15px",
  borderColor: "#a084dc",
  borderStyle: "solid",
  borderWidth: "2px",
  max: "9",
  min: "0",
  textAlign: "center",
};

const Login = () => {
  const [otpVisible, setOTPVisible] = useState<Boolean>(false);
  const [otpError, setOTPError] = useState<string>("");
  const [numberAndEmail, setNumberAndEmail] = useState<props>({
    mobile: "",
    email: "",
  });

  const [code, setCode] = useState("");

  const handleChange = (code: any) => {
    setCode(code);
    otpFormik.values.otp = code;
  };

  const mobileFormik = useFormik({
    initialValues: {
      mobile: "",
      email: "",
    },
    validationSchema: Yup.object().shape({
      mobile: Yup.string().required("Please enter the mobile number"),
      email: Yup.string()
        .required("Please enter the email number")
        .email("Invalid email address"),
    }),
    onSubmit: (value) => {
      console.log(value);
    },
  });

  const otpFormik = useFormik({
    initialValues: {
      otp: "",
    },
    validationSchema: Yup.object().shape({
      otp: Yup.string().required("OTP is required"),
    }),

    onSubmit: (values) => {
      console.log(values);
    },
  });

  return (
    <Fragment>
      <Paper
        style={{
          borderRadius: "20px",
          borderColor: "black",
          borderStyle: "Solid",
          borderWidth: "2px",
        }}
        elevation={20}
        sx={{ p: 2 }}
      >
        <CardContent sx={{ textAlign: "center" }}>
          {!otpVisible && (
            <Box
              sx={{
                "& .MuitTextField-root": {
                  margin: 1,
                  width: "100%",
                },
              }}
            >
              <Typography
                style={{
                  fontFamily: "Nunito",
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom
              >
                SIGN IN
              </Typography>
              <TextField
                sx={{ mb: 2 }}
                id="email"
                label="Email"
                placeholder="Enter Email"
                name="email"
                value={mobileFormik.values.email}
                onChange={(e) => {
                  mobileFormik.setFieldValue("email", e.target.value);
                }}
                onBlur={mobileFormik.handleBlur}
                error={Boolean(
                  mobileFormik.errors.email && mobileFormik.touched.email
                )}
                helperText={
                  mobileFormik.touched.email && mobileFormik.errors.email
                }
                fullWidth
              />

              <TextField
                id="mobile"
                value={mobileFormik.values.mobile}
                name="mobile"
                onBlur={mobileFormik.handleBlur}
                onChange={(e) => {
                  mobileFormik.setFieldValue("mobile", e.target.value);
                }}
                placeholder="Enter mobile number"
                fullWidth
                error={Boolean(
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                )}
                helperText={
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                }
                label="Mobile Number"
              />

              <Button
                style={{
                  fontFamily: "Inter",
                  fontSize: "1rem",
                  fontWeight: "bold",
                }}
                sx={{ mt: 2 }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  setOTPVisible(true);
                }}
              >
                GET OTP
              </Button>
            </Box>
          )}

          {/* <MuiOtpInput 
           length={6}
            value={otpFormik.values.otp}
             onChange={(e)=>{otpFormik.setFieldValue("otp",e.target.value)}} 
             error={Boolean(otpFormik.touched.otp && otpFormik.errors.otp)}
             onBlur={otpFormik.handleBlur}
             helperText={otpFormik.touched.otp && otpFormik.errors.otp}
             
             /> */}
          {otpVisible && (
            <Box
              sx={{
                margin: 1,
                width: "100%",
                textAlign: "center",
                alignContent: "center",
                alignItems: "center",
                justifyContent: "center",
                alignSelf: "center",
              }}
            >
              <Typography
                style={{
                  fontFamily: "Nunito",
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom
              >
                Enter OTP
              </Typography>
              <OtpInput
                inputStyle={{
                  border: "3px solid ",
                  borderRadius: "8px",
                  width: "40.5px",
                  height: "40px",
                  fontSize: "20px",
                  color: "#090752",
                  fontWeight: "bold",
                  caretColor: "blue",
                  margin: 20,
                }}
                inputProps={{ name: "otp" }}
                numInputs={6}
                separator={<span style={{ width: "8px" }}></span>}
                isInputNum={true}
                shouldAutoFocus={true}
                value={code}
                //  onChange={()=>{otpFormik.setFieldValue("otp",otpFormik.values.otp)}}
                onChange={handleChange}
                hasErrored={Boolean(
                  otpFormik.touched.otp && otpFormik.errors.otp
                )}
                errorStyle="error"
                focusStyle={{
                  border: "1px solid #090752",
                  outline: "none",
                }}
                // helperText={otpFormik.touched.otp && otpFormik.errors.otp}
              />

              <Button
                style={{
                  fontFamily: "Inter",
                  fontSize: "1rem",
                  fontWeight: "bold",
                }}
                sx={{ mt: 2 }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  setOTPVisible(true);
                }}
              >
                VERIFY
              </Button>
            </Box>
          )}

          {/* {touched && error && <div className="error">{error}</div>} */}
        </CardContent>
      </Paper>
    </Fragment>
  );
};
export default Login;
