import { styled, useTheme, Theme, CSSObject } from "@mui/material/styles";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar, { AppBarProps as MuiAppBarProps } from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import { ErrorMessage, Formik, useFormik } from "formik";
import React, { Fragment, useState } from "react";
import * as Yup from "yup";
import AddIcon from "@mui/icons-material/Add";
import FactCheckOutlinedIcon from "@mui/icons-material/FactCheckOutlined";
import PendingActionsOutlinedIcon from "@mui/icons-material/PendingActionsOutlined";
import DialpadOutlinedIcon from "@mui/icons-material/DialpadOutlined";
import HelpCenterOutlinedIcon from "@mui/icons-material/HelpCenterOutlined";
import {
  Button,
  Fab,
  Card,
  Box,
  CardContent,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Autocomplete,
  MenuItem,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  TextField,
} from "@mui/material";
import ReactSlidingPane from "react-sliding-pane";

const drawerWidth = 240;

interface props {
  isPaneOpen: boolean;
  isPaneOpenLeft: boolean;
}

const iconList = [
  { name: "completed", id: 0 },
  { name: "pending", id: 1 },
  { name: "phone", id: 2 },
  { name: "help", id: 3 },
];

const getIcon = (iconName: string) => {
  switch (iconName) {
    case "completed":
      return <FactCheckOutlinedIcon />;
    case "pending":
      return <PendingActionsOutlinedIcon />;
    case "phone":
      return <DialpadOutlinedIcon />;
    case "help":
      return <HelpCenterOutlinedIcon />;
    default:
      return null;
  }
};

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})<AppBarProps>(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

const MiniDrawer = () => {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [pane, setPane] = useState({
    isPaneOpen: false,
  });

  function handlePane(e: any) {
    if (e.target.key === "Completed Queries") {
      setPane({ isPaneOpen: true });
    }
  }

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const folioValidation = Yup.string()
    .required("Folio or Demat account number is required")
    .matches(/^[0-9]{8}$/, "Folio must be 6 digits")
    .required("Folio or Demant A/c number is required");

  const demantValidation = Yup.string()
    .required("Folio or Demat account number is required")
    .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")
    .required("Folio or Demant A/c number is required");

  const folioOrDematValidation = Yup.mixed().oneOf(
    [folioValidation, demantValidation],
    "Invalid Folio or Demat number"
  );

  const customerName = "customer";

  const supportedFormats = ["png", "jpeg", "pdf"];
  const supportSize = 1000000;

  const complaintFormik = useFormik({
    initialValues: {
      shareholder: "",
      company: "",
      folio: "",
      query: "",
      content: "",
      file: "",
    },

    validationSchema: Yup.object().shape({
      shareholder: Yup.string()
        .required("Shareholder name is required")
        .matches(/^[a-zA-Z]+$/, "Name should not contain numbers"),

      company: Yup.string().required("Company name is required"),

      folio: folioOrDematValidation,

      query: Yup.string().required(),

      File: Yup.mixed()
        .required("File is required")
        .test(
          "file-size",
          "File should be 1MB or lower",
          (values) => values && values.size <= supportSize
        )
        .test(
          "test-format",
          "Files should be PNG, JPEG, PDF",
          (values) =>
            values && supportedFormats.includes(values.type.split("/")[1])
        ),
    }),

    onSubmit: (values) => {
      console.log(values);
    },
  });

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar position="fixed" open={open}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{
              marginRight: 5,
              ...(open && { display: "none" }),
            }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            style={{
              fontFamily: "Inter",
              fontWeight: "bold",
              fontSize: "1.8rem",
            }}
            noWrap
            component="div"
          >
            Welcome to Camio IRM
          </Typography>
        </Toolbar>
      </AppBar>
      <Drawer variant="permanent" open={open}>
        <DrawerHeader>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List>
          {[
            "Completed Queries",
            "Pending Queries",
            "Change Phone Number",
            "Help",
          ].map((text, index) => (
            <ListItem
              key={text}
              onClick={handlePane}
              disablePadding
              sx={{ display: "block" }}
            >
              <ListItemButton
                onClick={handlePane}
                sx={{
                  minHeight: 48,
                  justifyContent: open ? "initial" : "center",
                  px: 2.5,
                }}
              >
                <ListItemIcon
                  onClick={handlePane}
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : "auto",
                    justifyContent: "center",
                  }}
                >
                  {/* {index % 2 === 0 ? <InboxIcon /> : <MailIcon />} */}
                  {/* {imgIcons.forEach(iconName => <{iconName}/>  )} */}

                  {/* <FactCheckOutlinedIcon />
                  <PendingActionsOutlinedIcon /> */}

                  {iconList
                    .filter(function (ind) {
                      return ind.id == index;
                    })
                    .map(function (name) {
                      return getIcon(name.name);
                    })}

                  {/* {iconList.map(({ name, icon }, index) => (
                    <>{getIcon(name)}</>
                  ))} */}
                </ListItemIcon>
                <ListItemText primary={text} sx={{ opacity: open ? 1 : 0 }} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
        <ReactSlidingPane
          className="some-custom-class"
          overlayClassName="some-custom-overlay-class"
          isOpen={pane.isPaneOpen}
          title="Hey, it is optional pane title.  I can be React component too."
          subtitle="Optional subtitle."
          onRequestClose={() => {
            // triggered on "<" on left top click or on outside click
            setPane({ isPaneOpen: false });
          }}
        >
          <div>And I am pane content. BTW, what rocks?</div>
          <br />
        </ReactSlidingPane>
        <Divider />
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <DrawerHeader />
        <Box
          sx={{
            display: "flex",
            direction: "column",
            justifyContent: "center",
            height: "87vh",
            p: 2,
            overflow: "auto",
          }}
          style={{ backgroundColor: "#F0ECCF" }}
        >
          <Grid container spacing={3} sx={{ p: 2 }}>
            <Grid item xs={12}>
              <Typography
                variant="h3"
                style={{
                  fontFamily: "Inter",
                  fontWeight: "bold",
                  fontSize: "1.8rem",
                }}
                gutterBottom
              >
                Hi, {customerName}. We are here to assist you !
                <Typography
                  gutterBottom
                  variant="h4"
                  style={{
                    fontFamily: "Inter",
                    fontWeight: "300",
                    fontSize: "1rem",
                    marginTop: 5,
                  }}
                >
                  Please complete the form below for your complaints
                </Typography>
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                id="shareholder-login"
                type="text"
                value={complaintFormik.values.shareholder}
                name="phone"
                onBlur={complaintFormik.handleBlur}
                label="Shareholder / Claimant Name"
                onChange={complaintFormik.handleChange}
                placeholder="Enter Shareholder / Claimant Name"
                fullWidth
                error={Boolean(
                  complaintFormik.touched.shareholder &&
                    complaintFormik.errors.shareholder
                )}
                helperText={
                  complaintFormik.touched.shareholder &&
                  complaintFormik.errors.shareholder
                }
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                error={Boolean(
                  complaintFormik.touched.company &&
                    complaintFormik.errors.company
                )}
                id="-company-login"
                type="text"
                value={complaintFormik.values.company}
                name="company"
                onBlur={complaintFormik.handleBlur}
                onChange={complaintFormik.handleChange}
                placeholder="Enter Company Name"
                helperText={
                  complaintFormik.touched.company &&
                  complaintFormik.errors.company
                }
                label="Company on which shares held"
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                error={Boolean(
                  complaintFormik.touched.folio && complaintFormik.errors.folio
                )}
                id="-company-login"
                type="numeric"
                value={complaintFormik.values.folio}
                name="folio"
                onBlur={complaintFormik.handleBlur}
                onChange={complaintFormik.handleChange}
                placeholder="Enter Folio No / Demat ACC No"
                helperText={
                  complaintFormik.touched.folio && complaintFormik.errors.folio
                }
                label="Folio Number (or) Demat Account Number"
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <Autocomplete
                id="-query-login"
                onBlur={complaintFormik.handleBlur}
                onChange={complaintFormik.handleChange}
                placeholder="Select Query"
                disablePortal
                options={queries}
                sx={{}}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    error={Boolean(
                      complaintFormik.touched.query &&
                        complaintFormik.errors.query
                    )}
                    value={complaintFormik.values.query}
                    helperText={
                      complaintFormik.touched.folio &&
                      complaintFormik.errors.folio
                    }
                    fullWidth
                    name="query"
                    label="Query"
                  />
                )}
              />
            </Grid>

            <Grid item xs={12} md={12}>
              <TextField
                fullWidth
                error={Boolean(
                  complaintFormik.touched.content &&
                    complaintFormik.errors.content
                )}
                id="content"
                type="text"
                value={complaintFormik.values.content}
                name="content"
                onBlur={complaintFormik.handleBlur}
                onChange={complaintFormik.handleChange}
                placeholder="Enter your complaint here"
                helperText={
                  complaintFormik.touched.content &&
                  complaintFormik.errors.content
                }
                label="Complaint"
                multiline
                rows={4}
              />
            </Grid>

            <Grid item xs={12}>
              <InputLabel htmlFor="upload-photo" />
              <TextField
                style={{ display: "none" }}
                id="upload-photo"
                name="upload-photo"
                type="file"
                error={Boolean(
                  complaintFormik.touched.file && complaintFormik.errors.file
                )}
                helperText={
                  complaintFormik.touched.file && complaintFormik.errors.file
                }
              />
              <Fab
                color="primary"
                size="small"
                component="span"
                aria-label="add"
                variant="extended"
              >
                <AddIcon /> Upload photo
              </Fab>
            </Grid>

            <Grid item xs={12} md={2}>
              <Button
                disableElevation
                // disabled={isSubmitting}
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                sx={{}}
                fullWidth
              >
                Submit
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Box>
  );
};

const queries = [
  { label: "Updation of Change of address", id: 1 },
  { label: "Updation  of KYC", id: 2 },
  { label: "Share certificate Lost", id: 3 },
  { label: "Shareholder/s deceased", id: 4 },
  { label: "IEPF Claim", id: 5 },
  { label: "Status of documents submitted", id: 6 },
  { label: "Name Change/ Correction", id: 7 },
  { label: "Non-receipt of New certificate (company name change)", id: 8 },
  { label: "Non-receipt of stickers  (company name change)", id: 9 },
  { label: "Non-receipt of Dividends", id: 10 },
  { label: "Non-receipt of Demat Rejected Documents", id: 11 },
  { label: "Status of demat request", id: 12 },
  { label: "Non-receipt of Rights shares", id: 13 },
  { label: "Status of IPO allotment", id: 14 },
  { label: "Status of shares", id: 15 },
  { label: "Non-receipt of annual report", id: 16 },
];

export default MiniDrawer;
