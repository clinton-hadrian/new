import React from 'react'
import Header from '../../components/layouts/Header'

const UserView = () => {
  return (
    <>
     <Header />
     
    </>
   
  )
}

export default UserView