import * as React from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import ListItemText from "@mui/material/ListItemText";
import Avatar from "@mui/material/Avatar";
import BeachAccessIcon from "@mui/icons-material/BeachAccess";
import OpenWithRoundedIcon from "@mui/icons-material/OpenWithRounded";
import Divider from "@mui/material/Divider";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { Box } from "@mui/system";
import { Button } from "@mui/material";

const ListComplaint = () => {
  return (
    <Grid container>
      <Grid item xs={12} md={12} sx={{ mb: 3 }}>
        <Box component="div" sx={{ width: "100%" }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500" }}
            gutterBottom
          >
            Recent Complaints
          </Typography>

          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
          </List>

          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
          </List>

          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
            <Button
              variant="contained"
              fullWidth
              sx={{
                borderBottomRightRadius: "15px",
                borderBottomLeftRadius: "15px",
                mt: 1,
              }}
            >
              View All
            </Button>
          </List>
        </Box>
      </Grid>

      <Grid item xs={12} md={12}>
        <Box component="div" sx={{ width: "100%" }}>
          <Typography
            variant="h4"
            sx={{ fontFamily: "Inter", fontWeight: "500" }}
            gutterBottom
          >
            Completed Complaints
          </Typography>

          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
          </List>
          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
          </List>
          <List
            sx={{
              width: "100%",
              maxWidth: 360,
              bgcolor: "background.paper",
            }}
          >
            <li>
              <Typography
                sx={{ mt: 0.5, ml: 9 }}
                color="text.secondary"
                display="block"
                variant="caption"
              >
                Ticket No - 5693
              </Typography>
            </li>
            <Divider component="li" variant="inset" />
            <ListItem>
              <ListItemAvatar>
                <Button
                  variant="contained"
                  sx={{ borderRadius: "50px", mr: 2 }}
                >
                  <OpenWithRoundedIcon />
                </Button>
              </ListItemAvatar>
              <ListItemText
                primary="S3 Companies"
                secondary="Folio - 28394829"
              />
              <ListItemText secondary="July 20, 2023 - 12:39" />
            </ListItem>
            <Button
              variant="contained"
              fullWidth
              sx={{
                borderBottomRightRadius: "15px",
                borderBottomLeftRadius: "15px",
                mt: 1,
              }}
            >
              View All
            </Button>
          </List>
        </Box>
      </Grid>
    </Grid>
  );
};

export default ListComplaint;
