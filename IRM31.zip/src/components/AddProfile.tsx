import {
  Dialog,
  DialogContent,
  DialogTitle,
  TextField,
  Box,
} from "@mui/material";
import Button from "@mui/material/Button";
import { AddOutlined,BadgeOutlined,EmailOutlined } from "@mui/icons-material";
import { useFormik } from "formik";

import React, { Fragment } from "react";
import * as Yup from "yup";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import InputAdornment from "@mui/material/InputAdornment";

interface props {
  open: boolean;
  handleClose: () => void;
}

const AddProfile: React.FC<props> = (props) => {
  const { open, handleClose } = props;
  const newUserFormik = useFormik({
    initialValues: {
      name: "",
      email: "",
    },

    validationSchema: Yup.object().shape({
      name: Yup.string().required("Name is required"),
      email: Yup.string().email("Invalid email").required("email is required"),
    }),
    onSubmit: (values) => {
      handleClose();
      console.log(values);
    },
  });

  return (
    <Fragment>
      <Dialog
        PaperProps={{
          style: {
            //   backgroundColor: 'transparent',
            boxShadow: "5",
          },
          sx: { width: "80vh" },
        }}
        open={open}
        sx={{ p: 6 }}>
        <DialogTitle>
          <Typography variant="h5">Please enter your details..</Typography>
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={3}>
            <Grid item xs={12} sx={{mt:1}}>
              <TextField
              InputProps={{
                startAdornment:<InputAdornment position="start"><BadgeOutlined /></InputAdornment>
              }}
                fullWidth
                variant="outlined"
                type="text"
                value={newUserFormik.values.name}
                name="name"
                onChange={newUserFormik.handleChange}
                onBlur={newUserFormik.handleBlur}
                helperText={
                  newUserFormik.touched.name && newUserFormik.errors.name
                }
                error={Boolean(
                  newUserFormik.touched.name && newUserFormik.errors.name
                )}
                placeholder="Enter your name"
                label="Name"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
              InputProps={{
                startAdornment:<InputAdornment position="start"><EmailOutlined /></InputAdornment>
              }}
                fullWidth
                variant="outlined"
                type="text"
                value={newUserFormik.values.email}
                name="email"
                onChange={newUserFormik.handleChange}
                onBlur={newUserFormik.handleBlur}
                helperText={
                  newUserFormik.touched.email && newUserFormik.errors.email
                }
                error={Boolean(
                  newUserFormik.touched.email && newUserFormik.errors.email
                )}
                placeholder="Enter your email"
                label="Email"
              />
            </Grid>
            <Grid item xs={12}>
              <Button
                variant="outlined"
                onClick={() => {
                  newUserFormik.handleSubmit();
                }}
                sx={{}}
                fullWidth
                endIcon={<AddOutlined />}>
                Create Account
              </Button>
            </Grid>
          </Grid>
        </DialogContent>
      </Dialog>
    </Fragment>
  );
};

export default AddProfile;


