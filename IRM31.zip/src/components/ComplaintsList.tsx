import React from "react";
import {
  Box,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Typography,
  Divider,
  Fab,
} from "@mui/material";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import { DeleteOutline, EastRounded } from "@mui/icons-material";

interface props {
  onClick: (name: string) => void;
}

const ComplaintsList: React.FC<props> = (props) => {
  const { onClick } = props;
  function handleClick(event: React.MouseEvent<HTMLButtonElement>) {
    const name = event.currentTarget.name;
    onClick(name);
  }

  return (
    <>
      <Box
        component="div"
        sx={{ width: "100%", overFlow: "auto", p: 0, justifyContent: "left" }}>
        <Typography
          variant="h4"
          sx={{
            fontFamily: "Inter",
            fontSize: "1.8rem",
            fontWeight: "300",
            ml: 2,
          }}
          gutterBottom>
          Recent Complaints
        </Typography>

        {/* <List
          sx={{
            width: "100%",
            maxWidth: "100%",
            bgcolor: "background.paper",
            alignItems: "left",
          }}>
          <ListItem>
            <ListItemAvatar>
              <Avatar>1</Avatar>
            </ListItemAvatar>
            <ListItemText
              primary="Brunch this weekend?"
              secondary={
                <React.Fragment>
                  <Typography
                    sx={{ display: "inline" }}
                    component="span"
                    variant="body2"
                    color="text.primary">
                    Ali Connors
                  </Typography>
                  {" — I'll be in your neighborhood doing errands this…"}
                </React.Fragment>
              }
            />
          </ListItem>
          <Divider variant="inset" component="li" />
        </List> */}

        <List
          sx={{
            width: "100%",

            bgcolor: "background.paper",
            alignItems: "left",
          }}>
          <li>
            <Typography
              sx={{ mt: 0.5, ml: 9, fontWeight: "800" }}
              color="text.secondary"
              display="block"
              variant="caption">
              Ticket No - 5693
            </Typography>
          </li>
          <Divider component="li" variant="inset" />
          <ListItem
            secondaryAction={
              <IconButton edge="end" aria-label="delete">
                <Fab name="complaint" onClick={handleClick} color="secondary">
                  <EastRounded />
                </Fab>
              </IconButton>
            }>
            <ListItemAvatar>
              <Avatar sx={{ backgroundColor: "#0A2647" }}>1</Avatar>
            </ListItemAvatar>

            <ListItemText primary="S3 Companies" secondary="Folio - 28394829" />
            <ListItemText
              secondary={
                <Typography sx={{ fontFamily: "Inter" }}>
                  July 20, 2023 - 12:39
                </Typography>
              }
            />
          </ListItem>
        </List>
        <List
          sx={{
            width: "100%",
            maxWidth: "100%",
            bgcolor: "background.paper",
          }}>
          <li>
            <Typography
              sx={{ mt: 0.5, ml: 9, fontWeight: "800" }}
              color="text.secondary"
              display="block"
              variant="caption">
              Ticket No - 5693
            </Typography>
          </li>
          <Divider component="li" variant="inset" />
          <ListItem
            secondaryAction={
              <IconButton edge="end" aria-label="delete">
                <Fab  color="secondary">
                  <EastRounded />
                </Fab>
              </IconButton>
            }>
            <ListItemAvatar>
              <Avatar sx={{ backgroundColor: "#0A2647" }}>2</Avatar>
            </ListItemAvatar>

            <ListItemText primary="S3 Companies" secondary="Folio - 28394829" />
            <ListItemText
              secondary={
                <Typography sx={{ fontFamily: "Inter" }}>
                  July 20, 2023 - 12:39
                </Typography>
              }
            />
          </ListItem>
        </List>
        <List
          sx={{
            width: "100%",
            maxWidth: "100%",
            bgcolor: "background.paper",
          }}>
          <li>
            <Typography
              sx={{ mt: 0.5, ml: 9, fontWeight: "800" }}
              color="text.secondary"
              display="block"
              variant="caption">
              Ticket No - 5693
            </Typography>
          </li>
          <Divider component="li" variant="inset" />
          <ListItem
            secondaryAction={
              <IconButton edge="end" aria-label="delete">
                <Fab color="secondary">
                  <EastRounded />
                </Fab>
              </IconButton>
            }>
            <ListItemAvatar>
              <Avatar sx={{ backgroundColor: "#0A2647" }}>3</Avatar>
            </ListItemAvatar>

            <ListItemText primary="S3 Companies" secondary="Folio - 28394829" />
            <ListItemText
              secondary={
                <Typography sx={{ fontFamily: "Inter" }}>
                  July 20, 2023 - 12:39
                </Typography>
              }
            />
          </ListItem>
        </List>
      </Box>
    </>
  );
};

export default ComplaintsList;
