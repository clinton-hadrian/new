import React from 'react'

const customerLogin = () => {
  return (
    <div>customerLogin</div>
  )
}

export default customerLogin