import { AnyAction } from "@reduxjs/toolkit";
import { SEND_MOBILE_OTP_FAILURE, SEND_MOBILE_OTP_REQUEST, SEND_MOBILE_OTP_SUCCESS } from "../constants/authConstant";

export const sendMobileOTPReducer=(state={},action:AnyAction)=>{
    switch(action.type){
        case SEND_MOBILE_OTP_REQUEST:
            return {loading:true}

            case SEND_MOBILE_OTP_SUCCESS:
                return {loading:false,response:action.payload}

                case SEND_MOBILE_OTP_FAILURE:
                    return {loading:false,error:action.payload}

                    default:
                        return state
    }

}