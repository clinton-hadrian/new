import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { sendMobileOTPReducer } from "./reducers/authReducer";
//import darkReducer from "./reducers/dark";
import { changeThemeReducer } from "./reducers/themeReducer";

const rootReducer = combineReducers({
  theme: changeThemeReducer,
  sendMobileOTP : sendMobileOTPReducer
});
const themeValue = localStorage.getItem("theme")
  ? localStorage.getItem("theme")
  : "light";
const initialReducer = {
  theme: { mode: themeValue },
};

const store = configureStore({
  reducer: rootReducer,
});

export default store;
