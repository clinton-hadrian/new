import axios from "axios";
import { AnyAction, Dispatch } from "redux";
import {
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS,
  SEND_MOBILE_OTP_FAILURE,
} from "../constants/authConstant";
import { API } from "../data";

export const sendMobileOTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: SEND_MOBILE_OTP_REQUEST,
    });
    const { data } = await axios.post(`${API}/Auth/sendMobileOTP`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: SEND_MOBILE_OTP_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: SEND_MOBILE_OTP_FAILURE,
      payload: error,
    });
  }
};
