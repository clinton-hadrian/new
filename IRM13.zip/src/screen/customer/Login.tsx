import React, { Fragment, useState, useEffect, Dispatch } from "react";
import { useNavigate } from "react-router-dom";
import OtpInput from "react18-input-otp";
import Countdown from "../../components/Countdown";
import {
  Box,
  Typography,
  CardContent,
  TextField,
  Paper,
  InputAdornment,
} from "@mui/material";

import SnackBar from "../../components/Snackbar";

import * as Yup from "yup";
import { useFormik } from "formik";
import DialpadOutlinedIcon from "@mui/icons-material/DialpadOutlined";
import { useDispatch, useSelector } from "react-redux";
import { sendMobileOTPAction } from "../../actions/authAction";
import LoadingButton from "@mui/lab/LoadingButton";
import {} from "../../reducers/authReducer";
import MuiAlert, { AlertProps } from "@mui/material/Alert";
import { verifyMobileOTPAction } from "../../actions/authAction";

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

interface props {
  mobile: string;
  otp: string;
}

const otpBorder = {
  width: "20%",
  margin: "0 5px",
  borderRadius: "15px",
  borderColor: "#a084dc",
  borderStyle: "solid",
  borderWidth: "2px",
  max: "9",
  min: "0",
  textAlign: "center",
};

const Login = () => {
  const navigate = useNavigate();
  const [snackOpen, setSnackOpen] = useState(false);


  const dispatch: Dispatch<any> = useDispatch();

  const sendMobileOTPSelector = useSelector((state: any) => state.sendMobileOTP);
  const verifyMobileOTPSelector = useSelector((state: any) => state.verifyMobileOTP);

  const [otpVisible, setOTPVisible] = useState<Boolean>(false);


  const mobileFormik = useFormik({
    initialValues: {
      mobile: "",
    },
    validationSchema: Yup.object().shape({
      mobile: Yup.string().required("Please enter the mobile number"),
    }),

    onSubmit: (value) => {
      dispatch(sendMobileOTPAction(value));
      setSnackOpen(true);
    },
  });

  if (sendMobileOTPSelector.response && !otpVisible) {
    setOTPVisible(true);
  }

  useEffect(() => {}, [otpVisible]);

  const otpFormik = useFormik({
    initialValues: {
      otp: "",
    },
    validationSchema: Yup.object().shape({
      otp: Yup.string().required("OTP is required"),
    }),

    onSubmit: (value) => {
      setSnackOpen(true);

      dispatch(
        verifyMobileOTPAction({
          otp: value.otp,
          mobile: sendMobileOTPSelector.response[0]["MOBILE"],
        })
      );
    },
  });


  if (verifyMobileOTPSelector.response && verifyMobileOTPSelector.response[0]["MOBILE"]) {
    navigate("/query");
  }

  return (
    <Fragment>
      {verifyMobileOTPSelector && verifyMobileOTPSelector.error ? (
        <SnackBar
          severity="error"
          handleClose={() => {
            setSnackOpen(false);
          }}
          message={verifyMobileOTPSelector.error}
          open={snackOpen}
        />
      ) : sendMobileOTPSelector && sendMobileOTPSelector.error ? (
        <SnackBar
          severity="error"
          handleClose={() => {
            setSnackOpen(false);
          }}
          message={sendMobileOTPSelector.error}
          open={snackOpen}
        />
      ) : (
        sendMobileOTPSelector &&
        sendMobileOTPSelector.response && (
          <SnackBar
            severity="success"
            handleClose={() => {
              setSnackOpen(false);
            }}
            message={"Mobile Otp Successfuly sent"}
            open={snackOpen}
          />
        )
      )}

      <Paper
        style={{
          borderRadius: "20px",
        }}
        elevation={20}
        sx={{ p: 2 }}>
        <CardContent sx={{ textAlign: "center", pb: 0 }}>
          {!otpVisible && (
            <Box
              sx={{
                "& .MuitTextField-root": {
                  margin: 1,
                  width: "100%",
                },
              }}>
              <Typography
                style={{
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom>
                SIGN IN
              </Typography>

              <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <DialpadOutlinedIcon sx={{ mr: 2 }} />
                    </InputAdornment>
                  ),
                }}
                id="mobile"
                value={mobileFormik.values.mobile}
                name="mobile"
                onBlur={mobileFormik.handleBlur}
                onChange={(e) => {
                  mobileFormik.setFieldValue("mobile", e.target.value);
                }}
                placeholder="Enter mobile number"
                fullWidth
                error={Boolean(
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                )}
                helperText={
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                }
                label="Mobile Number"
              />

              <LoadingButton
                loading={sendMobileOTPSelector.loading}
                sx={{ mt: 2, borderRadius: "10px" }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  mobileFormik.handleSubmit();
                }}>
                GET OTP
              </LoadingButton>
            </Box>
          )}

          {otpVisible && (
            <Box
              sx={{
                display: "flex",
                margin: 1,
                width: "100%",
                textAlign: "center",
                alignContent: "center",
                alignItems: "center",
                justifyContent: "center",
                alignSelf: "center",
                flexDirection: "column",
                flexWrap: "wrap",
              }}>
              <Typography
                style={{
                  fontFamily: "Nunito",
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom>
                Enter OTP
              </Typography>
              <OtpInput
                inputStyle={{
                  border: "3px solid ",
                  borderRadius: "8px",
                  width: "40.5px",
                  height: "40px",
                  fontSize: "20px",
                  color: "#090752",
                  fontWeight: "bold",
                  caretColor: "blue",
                  margin: 4,
                }}
                inputProps={{ name: "otp", readOnly: false }}
                numInputs={6}
                separator={<span style={{ width: "8px" }}></span>}
                isInputNum={true}
                shouldAutoFocus={true}
                value={otpFormik.values.otp}
                onChange={(value: number) => {
                  otpFormik.setFieldValue("otp", value);
                }}
                hasErrored={Boolean(
                  otpFormik.touched.otp && otpFormik.errors.otp
                )}
                errorStyle="error"
                focusStyle={{
                  border: "1px solid #090752",
                  outline: "none",
                }}
              />

              <LoadingButton
                sx={{ mt: 2 }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  otpFormik.handleSubmit();
                }}>
                VERIFY
              </LoadingButton>
              <Box sx={{ position: "relative", top: 15 }}>
                <Countdown />
              </Box>
            </Box>
          )}

        </CardContent>
      </Paper>
    </Fragment>
  );
};
export default Login;
