import { AnyAction } from "@reduxjs/toolkit";
import { CHANGE_THEME } from "../constants/themeConstant";



export const changeThemeReducer = (
  state = { mode: "light" },
  action: AnyAction
) => {
  switch (action.type) {
    case CHANGE_THEME:
      return { mode: action.payload.mode,};
    default:
      return state;
  }
};
