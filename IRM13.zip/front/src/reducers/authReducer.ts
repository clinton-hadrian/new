import { AnyAction } from "@reduxjs/toolkit";
import React from "react";
import { useDispatch } from "react-redux";
import {
  SEND_MOBILE_OTP_FAILED,
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS
} from "../constants/authConstant";

import { VERIFY_MOBILE_OTP_FAILED, 
  VERIFY_MOBILE_OTP_REQUEST, 
  VERIFY_MOBILE_OTP_SUCCESS } from "../constants/authConstant";

  import {
    ADD_PROFILE_REQUEST,
    ADD_PROFILE_SUCCESS,
    ADD_PROFILE_FAILED
} from "../constants/authConstant";

export const sendMobileOTPReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case SEND_MOBILE_OTP_REQUEST:
      return { loading: true };

    case SEND_MOBILE_OTP_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case SEND_MOBILE_OTP_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export const addProfileReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case ADD_PROFILE_REQUEST:
      return { loading: true };

    case ADD_PROFILE_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case ADD_PROFILE_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export const verifyMobileOTPReducer = (state = {}, action: AnyAction) => {

  switch (action.type) {
    case VERIFY_MOBILE_OTP_REQUEST:
      return { loading: true };
    case VERIFY_MOBILE_OTP_SUCCESS:
      return { loading: false, response: action.payload,  };
    //   case LOGOUT:
    //     return {loading:false, response:action.payload, }
    case VERIFY_MOBILE_OTP_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

