export const typography = {
  fontFamily: ["Nunito", "Inter"].join(","),
  h1: {
    fontFamily: "Inter",
    fontWeight: 500,
  },
  h2: {
    fontFamily: "Inter",
  },
  h3: {
    fontFamily: "Inter",
  },
  h4: {
    fontFamily: "Inter",
  },
  button: {
    fontFamily: "Nunito",
  },
};

export default typography;
