﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace irm_backend.Models
{
    public class MobileOTP
    {
        [Key]
        public int ID { get; set; }
        public int MOBILE { get; set; }
        public int OTP { get; set; }
        public DateTime CREATED_DATE { get; set; }
 
    }
}
