﻿using irm_backend.Interfaces;
using irm_backend.Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

namespace irm_backend.Services
{
    public class CustomerService :ICustomer
    {
        private readonly string _connectionString;
        public CustomerService(IConfiguration _configuration)
        {
            _connectionString = _configuration.GetConnectionString("CrestCon");
        }

        public DataTable addComplaint(customerModel customer)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        var flag = 1;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_FLAG", OracleDbType.Int32).Value = flag;
                        cmd.Parameters.Add("ARG_INVESTOR",OracleDbType.Varchar2).Value=customer.investorName;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = customer.companyName;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = customer.queryType;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = customer.query;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = customer.problemStatement;
                        cmd.Parameters.Add("ARG_MEDIA", OracleDbType.Blob).Value = customer.mediaDocument;
                        OracleDataAdapter oda= new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch(Exception e)
            {
                return null;
            }
           
        }

        public DataTable listComplaint(customerModel customer)
        {
            try
            {
                DataTable dt = new DataTable();
                using (OracleConnection con = new OracleConnection(_connectionString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "CUSTOMER_PROCEDURE";
                        cmd.Parameters.Add("ARG_INVESTOR", OracleDbType.Varchar2).Value = customer.investorName;
                        cmd.Parameters.Add("ARG_COMPANY", OracleDbType.Varchar2).Value = customer.companyName;
                        cmd.Parameters.Add("ARG_QUERY_TYPE", OracleDbType.Varchar2).Value = customer.queryType;
                        cmd.Parameters.Add("ARG_QUERY", OracleDbType.Varchar2).Value = customer.query;
                        cmd.Parameters.Add("ARG_PROBLEM_STATEMENT", OracleDbType.Varchar2).Value = customer.problemStatement;
                        cmd.Parameters.Add("ARG_MEDIA", OracleDbType.Blob).Value = customer.mediaDocument;
                        OracleDataAdapter oda = new OracleDataAdapter(cmd);
                        oda.Fill(dt);
                        con.Close();
                    }
                }
                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public DataTable updateComplaint(customerModel customer)
        {
            throw new System.NotImplementedException();
        }

        public DataTable viewComplaint(customerModel customer)
        {
            throw new System.NotImplementedException();
        }
        public DataTable recentListComplaint(customerModel customer)
        {
            throw new System.NotImplementedException();
        }
    }
}
