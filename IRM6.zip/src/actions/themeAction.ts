import { CHANGE_THEME } from "../constants/themeConstant";

export const changeThemeAction = (value: string) => (dispatch: any) => {
  try {
    dispatch({
      type: CHANGE_THEME,
      payload: { mode: value },
    });
    localStorage.setItem("theme", value);
  } catch (error) {}
};
