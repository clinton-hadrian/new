import { Alert } from "@mui/material";
import React from "react";

const Snackbar = (props:any) => {
    const [open, setOpen] = React.useState(false);
    const handleClose = () => {
        setOpen(false);
      };
  return (
    <Snackbar
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      open={open}
      onClose={props}
      message={props}
      severity={props}
      autoHideDuration={3000}>
     
    </Snackbar>
  );
};

export default Snackbar;
