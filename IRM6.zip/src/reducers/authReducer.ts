import { AnyAction } from "@reduxjs/toolkit";
import React from "react";
import { useDispatch } from "react-redux";
import {
  SEND_MOBILE_OTP_FAILURE,
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS,
  HANDLE_CLOSE
} from "../constants/authConstant";


export const sendMobileOTPReducer = (state = {showSnackbar:false, open:false,severity:"success",message:""}, action: AnyAction) => {
  

  switch (action.type) {
    case SEND_MOBILE_OTP_REQUEST:
      return { loading: true };

    case SEND_MOBILE_OTP_SUCCESS:
      return { showSnackbar:true, open:true,severity:"success", message:"OTP sent Successfully", loading: false, response: action.payload };

    case SEND_MOBILE_OTP_FAILURE:
      return {showSnackbar:true, open:true, severity:"error", message:"Something Wrong !", loading: false, error: action.payload };

      case HANDLE_CLOSE:
        return {...state, open:false}

    default:
      return state;
  }
 
};

