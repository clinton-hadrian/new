import React from 'react'

const customerComplaint = () => {
  return (
    <div>customerComplaint</div>
  )
}

export default customerComplaint