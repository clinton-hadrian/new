import {
  Card,
  CardContent,
  createTheme,
  Paper,
  TextField,
  Typography,
  Box,
} from "@mui/material";
import { ErrorMessage, Formik } from "formik";
import * as Yup from "yup";
import { useState } from "react";
import Center from "../../components/Center";
import VerifiedUserIcon from "@mui/icons-material/VerifiedUser";
import InputAdornment from "@mui/material/InputAdornment";

const Otp = () => {
  const otpValidationSchema = Yup.object().shape({
    otp1: Yup.string()
      .matches(/^\d+$/, "OTP1 must be a number")
      .required("OTP1 is required"),

    otp2: Yup.string()
      .matches(/^\d+$/, "OTP2 must be a number")
      .required("OTP2 is required"),

    otp3: Yup.string()
      .matches(/^\d+$/, "OTP3 must be a number")
      .required("OTP3 is required"),

    otp4: Yup.string()
      .matches(/^\d+$/, "OTP4 must be a number")
      .required("OTP4 is required"),
  });

  const otpBorder = {
    width: "20%",
    margin: "0 5px",
    borderRadius: "15px",
    borderColor: "#a084dc",
    borderStyle: "solid",
    borderWidth: "2px",
    max: "9",
    min: "0",
    textAlign: "center",
  };

  return (
    <Center>
      <Paper
        elevation={20}
        square={false}
        sx={{ p: 2, width: "40vh", height: "35vh", borderRadius: "25px" }}
      >
        <CardContent
          sx={{
            textAlign: "center",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Box
            component="div"
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "50%",
              height: "65px",
              width: "65px",
              backgroundColor: "#A084DC",
              fontSize: "2.5rem",
              ml: 12,
            }}
          >
            <VerifiedUserIcon
              sx={{ fontSize: "2.3rem", mt: 0.3 }}
              style={{ color: "#473967" }}
            />
          </Box>

          <Typography
            style={{
              fontFamily: "Nunito",
              fontSize: "1.8rem",
              fontWeight: "bold",
            }}
            sx={{ mt: 2.5 }}
            variant="h4"
          >
            Enter OTP code
          </Typography>

          <Box
            component="div"
            sx={{ display: "flex", justifyContent: "center", mt: 3 }}
          >
            <Formik
              initialValues={{
                otp1: "",
                otp2: "",
                otp3: "",
                otp4: "",
              }}
              validationSchema={otpValidationSchema}
              onSubmit={(values) => {
                console.log(values);
              }}
            >
              {({
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
                isSubmitting,
                touched,
                values,
              }) => (
                <>
                  <TextField
                    sx={{ ...otpBorder }}
                    id="otp1-login"
                    value={values.otp1}
                    name="otp1"
                    onBlur={handleBlur}
                    onChange={handleChange}
                    fullWidth
                    error={Boolean(touched.otp1 && errors.otp1)}
                    variant="outlined"
                    type="numeric"
                    inputProps={{
                      maxLength: 1,
                      endAdornment: (
                        <InputAdornment
                          position="end"
                          sx={{ textAlign: "center" }}
                        >
                          {values.otp1}
                        </InputAdornment>
                      ),
                    }}
                    style={{
                      fontWeight: values.otp1.length > 0 ? "bold" : "normal",
                    }}
                  />

                  <TextField
                    sx={{
                      ...otpBorder,
                    }}
                    id="otp2-login"
                    value={values.otp2}
                    name="otp2"
                    onBlur={handleBlur}
                    onChange={handleChange}
                    fullWidth
                    error={Boolean(touched.otp2 && errors.otp2)}
                    variant="outlined"
                    type="numeric"
                    inputProps={{ maxLength: 1 }}
                  />

                  <TextField
                    sx={{
                      ...otpBorder,
                    }}
                    id="otp3-login"
                    value={values.otp3}
                    name="otp3"
                    onBlur={handleBlur}
                    onChange={handleChange}
                    fullWidth
                    error={Boolean(touched.otp3 && errors.otp3)}
                    variant="outlined"
                    type="numeric"
                    inputProps={{ maxLength: 1 }}
                  />

                  <TextField
                    sx={{
                      ...otpBorder,
                    }}
                    id="otp4-login"
                    value={values.otp4}
                    name="otp4"
                    onBlur={handleBlur}
                    onChange={handleChange}
                    fullWidth
                    error={Boolean(touched.otp4 && errors.otp4)}
                    variant="outlined"
                    type="numeric"
                    inputProps={{ maxLength: 1 }}
                  />
                </>
              )}
            </Formik>
          </Box>
        </CardContent>
      </Paper>
    </Center>
  );
};

export default Otp;
