import React, { Fragment } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./screen/customer/Login";
import Complaint from "./screen/customer/Complaint";
import Otp from "./screen/customer/Otp";
import { createTheme, CssBaseline, ThemeProvider } from "@mui/material";

import Layout from "./components/Links";

// export const useStyles = makeStyles({
//   root: {
//     display: "flex",
//     justifyContent: "center",
//   },
//   textField: {
//     width: "20%",
//     margin: "0 5px",
//   },
// });

export const Theme = createTheme({
  // typography: {
  //   fontFamily: `"Nunito", "Inter"`,
  // },
  palette: {
    mode: "light",
    primary: {
      main: "#090752",
      light: "#AFA8BA",
    },
    secondary: {
      main: "#A084DC",
      light: "##CCAEFF",
    },
  },
});
function App() {
  return (
    <Fragment>
      <ThemeProvider theme={Theme}>
        <Router>
          <Routes>
            <Route path="/" element={<Layout />} />
            <Route index element={<Login />} />
            <Route path="complaint" element={<Complaint />} />
            <Route path="otp" element={<Otp />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </Fragment>
  );
}

export default App;
