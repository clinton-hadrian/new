import React, { Fragment } from "react";
import Center from "../../components/Center";
import {
  Button,
  Card,
  Box,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  CardContent,
  TextField,
  Paper,
} from "@mui/material";

import * as Yup from "yup";
import { Formik } from "formik";

const Login = () => {
  return (
    <Fragment>
      <Center>
        <Paper elevation={10} sx={{ p: 2 }}>
          <CardContent sx={{ textAlign: "center", backgroundColor: "#AFA8BA" }}>
            <Typography variant="h5" gutterBottom>
              Login
            </Typography>
            <Box
              sx={{
                "& .MuitTextField-root": {
                  margin: 1,
                  width: "100%",
                },
              }}>
              <Formik
                initialValues={{
                  phone: "1234567890",
                  otp: "123456",
                  submit: null,
                }}
                validationSchema={Yup.object().shape({
                  phone: Yup.string()
                    .matches(
                      /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/,
                      "Phone number is not valid"
                    )
                    .required("phone number is required"),
                  otp: Yup.string()
                    .matches(/^[0-9]{6}$/, "OTP must be 6 digits")
                    .required("OTP is required"),
                })}
                onSubmit={(values) => {}}>
                {({
                  errors,
                  handleBlur,
                  handleChange,
                  handleSubmit,
                  isSubmitting,
                  touched,
                  values,
                }) => (
                  <form noValidate onSubmit={handleSubmit}>
                    <Grid container spacing={3}>
                      <Grid item xs={12}>
                        <Stack spacing={1}>
                          <TextField
                            id="phone-login"
                            type="text"
                            value={values.phone}
                            name="phone"
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder="Enter email address"
                            fullWidth
                            error={Boolean(touched.phone && errors.phone)}
                            label="Phone Number"
                          />
                          {touched.phone && errors.phone && (
                            <FormHelperText
                              error
                              id="standard-weight-helper-text-email-login">
                              {errors.phone}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>
                      <Grid item xs={12}>
                        <Stack spacing={1}>
                          <TextField
                            fullWidth
                            error={Boolean(touched.otp && errors.otp)}
                            id="-otp-login"
                            type="numeric"
                            value={values.otp}
                            name="otp"
                            onBlur={handleBlur}
                            onChange={handleChange}
                            placeholder="Enter OTP"
                            label="OTP"
                          />
                          {touched.otp && errors.otp && (
                            <FormHelperText
                              error
                              id="standard-weight-helper-text-otp-login">
                              {errors.otp}
                            </FormHelperText>
                          )}
                        </Stack>
                      </Grid>

                      {errors.submit && (
                        <Grid item xs={12}>
                          <FormHelperText error>{errors.submit}</FormHelperText>
                        </Grid>
                      )}
                      <Grid item xs={12}>
                        <Button
                          disableElevation
                          disabled={isSubmitting}
                          fullWidth
                          size="large"
                          type="submit"
                          variant="contained"
                          color="primary">
                          Login
                        </Button>
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            </Box>
          </CardContent>
        </Paper>
      </Center>
    </Fragment>
  );
};
export default Login;
