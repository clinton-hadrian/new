import { Formik } from "formik";
import React, { Fragment } from "react";
import * as Yup from "yup";
import Center from "../../components/Center";

import AddIcon from "@mui/icons-material/Add";

import {
  Button,
  Fab,
  Card,
  Box,
  CardContent,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Autocomplete,
  MenuItem,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  TextField,
} from "@mui/material";


const Complaint = () => {
  const folioValidation = Yup.string()
    .matches(/^[0-9]{8}$/, "Folio must be 6 digits")
    .required("Folio or Demant A/c number is required");

  const demantValidation = Yup.string()
    .matches(/^[0-9]{16}$/, "Demat No must be 16 digits")
    .required("Folio or Demant A/c number is required");

  const folioOrDematValidation = Yup.mixed().oneOf(
    [folioValidation, demantValidation],
    "Invalid Folio or Demat number"
  );

  return (
    
    <Grid
    container
    direction="column"
    alignItems="center"
    justifyContent="center"
    sx={{
      height: "100vh",
    }}
  >
    <Grid item xs={12}>
    <Box component="div" sx={{ backgroundColor:"#fff" }}>
        <Card sx={{ width: "500px", height: "100%" }}>
          <CardContent sx={{ textAlign: "center" }}>
            <Typography variant="h5" gutterBottom>
              Query Form
            </Typography>
            <Box
              sx={{
                "& .MuiTextField-root": {
                  margin: 1,
                  width: "100%",
                },
              }}>
              <Formik
                initialValues={{
                  shareholder: "1234567890",
                  company: "123456",
                  folio: "",
                  query: "",
                  submit: null,
                }}
                validationSchema={Yup.object().shape({
                  shareholder: Yup.string().required(
                    "Shareholder / Claimant name is required "
                  ),
                  company: Yup.string()
                    .required("Company is required ")
                    .matches(/^[^|]*$/, "wrong"),
                  folio: folioOrDematValidation,
                })}
                onSubmit={(values) => {}}>
                {({
                  errors,
                  handleBlur,
                  handleChange,
                  handleSubmit,
                  isSubmitting,
                  touched,
                  values,
                }) => (
                  <form noValidate onSubmit={handleSubmit}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={6}>
                        <TextField
                          id="shareholder-login"
                          type="text"
                          value={values.shareholder}
                          name="phone"
                          onBlur={handleBlur}
                          label="Shareholder / Claimant Name"
                          onChange={handleChange}
                          placeholder="Enter Shareholder / Claimant Name"
                          fullWidth
                          error={Boolean(
                            touched.shareholder && errors.shareholder
                          )}
                          helperText={touched.shareholder && errors.shareholder}
                        />
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <TextField
                          fullWidth
                          error={Boolean(touched.company && errors.company)}
                          id="-company-login"
                          type="text"
                          value={values.company}
                          name="company"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          placeholder="Enter Company Name"
                          helperText={touched.company && errors.company}
                          label="Company on which shares held"
                        />
                      </Grid>

                      <Grid item xs={6} md={6}>
                        <TextField
                          fullWidth
                          error={Boolean(touched.folio && errors.folio)}
                          id="-company-login"
                          type="numeric"
                          value={values.folio}
                          name="folio"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          placeholder="Enter Folio No / Demat ACC No"
                          helperText={touched.folio && errors.folio}
                          label="Folio Number (or) Demat Account Number"
                        />
                      </Grid>

                      <Grid item xs={6} md={6}>
                        <Autocomplete
                          // error={Boolean(touched.query && errors.query)}
                          id="-query-login"
                          // value={values.query}
                          //name="query"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          placeholder="Select Query"
                          //helperText={touched.folio && errors.folio}
                          //label="Queries"
                          disablePortal
                          options={queries}
                          sx={{}}
                          renderInput={(params) => (
                            <TextField {...params} fullWidth label="Query" />
                          )}
                        />
                      </Grid>

                      <Grid item xs={6} md={4}>
                        <InputLabel htmlFor="upload-photo" />
                        <TextField
                          style={{ display: "none" }}
                          id="upload-photo"
                          name="upload-photo"
                          type="file"
                        />
                        <Fab
                          color="primary"
                          size="small"
                          component="span"
                          aria-label="add"
                          variant="extended">
                          <AddIcon /> Upload photo
                        </Fab>
                      </Grid>

                      {errors.submit && (
                        <Grid item xs={12}>
                          <FormHelperText error>{errors.submit}</FormHelperText>
                        </Grid>
                      )}
                      <Grid item xs={12}>
                        <Button
                          disableElevation
                          disabled={isSubmitting}
                          fullWidth
                          size="large"
                          type="submit"
                          variant="contained"
                          color="primary">
                          Submit
                        </Button>
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            </Box>
          </CardContent>
        </Card>
      </Box>
    </Grid>
  </Grid>
      
    
  );
};

const queries = [
  { label: "Updation of Change of address", id: 1 },
  { label: "Updation  of KYC", id: 2 },
  { label: "Share certificate Lost", id: 3 },
  { label: "Shareholder/s deceased", id: 4 },
  { label: "IEPF Claim", id: 5 },
  { label: "Status of documents submitted", id: 6 },
  { label: "Name Change/ Correction", id: 7 },
  { label: "Non-receipt of New certificate (company name change)", id: 8 },
  { label: "Non-receipt of stickers  (company name change)", id: 9 },
  { label: "Non-receipt of Dividends", id: 10 },
  { label: "Non-receipt of Demat Rejected Documents", id: 11 },
  { label: "Status of demat request", id: 12 },
  { label: "Non-receipt of Rights shares", id: 13 },
  { label: "Status of IPO allotment", id: 14 },
  { label: "Status of shares", id: 15 },
  { label: "Non-receipt of annual report", id: 16 },
];

export default Complaint;
