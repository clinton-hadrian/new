import Grid from '@mui/material/Grid'
import { Container } from '@mui/system'
import React,{Fragment} from 'react'
import { Outlet } from 'react-router-dom'

const CustomerLayout = () => {
  return (
    <Fragment>
      <Container maxWidth="xl">

      <Grid container sx={{
        direction:"column",
        justifyContent:"center",
        minHeight:"90vh"
      }} 
      spacing={1}>
      <Grid item xs={12} md={8}
      >
        <Outlet />
      </Grid>

    </Grid>

      </Container>
    
    </Fragment>
  )
}

export default CustomerLayout