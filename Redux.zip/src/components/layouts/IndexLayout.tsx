import { Grid } from "@mui/material";
import Container from "@mui/material/Container";
import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";

const IndexLayout = () => {
  return (
    <Fragment>
      <Container maxWidth="xl">
        <Grid
          container
          spacing={1}
          sx={{
            alignItems: "center",
            justifyContent: "center",
            minHeight: "90vh",
          }}>
          <Grid item xs={12} md={5}>
            <Outlet />
          </Grid>
        </Grid>
      </Container>
    </Fragment>
  );
};

export default IndexLayout;
