import { Grid } from "@mui/material";
import React from "react";

interface Props {
  children: React.ReactNode;
}

const Center: React.FC<Props> = (props) => {
  return (
    <Grid
      color="secondary.light"
      container
      direction="column"
      alignItems="center"
      justifyContent="center"
      sx={{
        minHeight: "100vh",
      }}>
      <Grid item xs={12}>
        {props.children}
      </Grid>
    </Grid>
  );
};

export default Center;
