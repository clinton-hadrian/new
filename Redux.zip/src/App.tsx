import React, { Fragment } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./screen/customer/Login";
import { createTheme, CssBaseline, ThemeProvider } from "@mui/material";
import IndexLayout from "./components/layouts/IndexLayout";
import UserLogin from "./screen/user/UserLogin";
import CustomerLayout from "./components/layouts/CustomerLayout";
import Complaint from "./screen/customer/Complaint";

// export const useStyles = makeStyles({
//   root: {
//     display: "flex",
//     justifyContent: "center",
//   },
//   textField: {
//     width: "20%",
//     margin: "0 5px",
//   },
// });

export const Theme = createTheme({
  // typography: {
  //   fontFamily: `"Nunito", "Inter"`,
  // },
  palette: {
    mode: "light",
    primary: {
      main: "#090752",
      light: "#AFA8BA",
    },
    secondary: {
      main: "#A084DC",
      light: "##CCAEFF",
    },
  },
});
function App() {
  return (
    <Fragment>
      <ThemeProvider theme={Theme}>
      <CssBaseline />
        <Router>
          <Routes>

            <Route path="" element={<IndexLayout />}>
              <Route path="" element={<Login />} />
              </Route>

              <Route path="/user" element={<IndexLayout />}>
                <Route path="/user" element={<UserLogin />}/>
            </Route>

            <Route path="/query" element={<CustomerLayout />}>
              <Route path="/query" element={<Complaint />} />
              </Route> 


          </Routes>
        </Router>
      </ThemeProvider>
    </Fragment>
  );
}

export default App;
