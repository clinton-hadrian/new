import React, { Fragment } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./screen/customer/Login";
import Complaint from "./screen/customer/Complaint";
import { createTheme, CssBaseline, ThemeProvider } from "@mui/material";

export const Theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#090752",
      light: "##AFA8BA",
    },
    secondary: {
      main: "##473967",
      light: "##CCAEFF",
    },
  },
});
function App() {
  return (
    <Fragment>
      <ThemeProvider theme={Theme}>
        <CssBaseline />
        <Router>
          <Routes>
            <Route path="/" element={<Login />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </Fragment>
  );
}

export default App;
