import { ErrorMessage, Formik, useFormik } from "formik";
import React, { Fragment, useState } from "react";
import * as Yup from "yup";
import {
  Button,
  Fab,
  Card,
  Box,
  CardContent,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Autocomplete,
  MenuItem,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  TextField,
} from "@mui/material";
import AddProfile from "../../components/AddProfile";
import AddComplaint from "../../components/AddComplaint";
import Header from "../../components/layouts/Header";
import ViewComplaint from "../../components/ViewComplaint";
import ListComplaint from "../../components/ListComplaint";

const Complaint = () => {
  const [addProfile, setAddProfile] = useState(false);

  return (
    <>
      <Header />
      <Box
        sx={{
          position: "inline-flex",
          direction: "row",
          marginX: 1,
          marginY: 1,
          overflow: "auto",
          justifyContent: "center",
          p: 2,
        }}
        style={{  }}>
        <AddProfile
          open={addProfile}
          handleClose={() => {
            setAddProfile(false);
          }}
        />
        <Grid container>
          <Grid item xs={12} md={8}>
            <Box
              sx={{
                display: "flex",
                direction: "row",
                justifyContent: "center",
                p: 2,
                overflow: "auto",
              }}
              style={{  }}>
              <AddComplaint customerName="Ajay" />
            </Box>
          </Grid>

          <Grid sx={{borderLeft:"solid",borderWidth:"1px"}} item xs={12} md={4}>
            <Box
              sx={{
                display: "flex",
                flex: 1,
                direction: "row",
                justifyContent: "center",
                p: 1,
                ml:2,
                overflow: "auto",
              }}
              >
              <ListComplaint />
            </Box>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default Complaint;
