import { AnyAction } from "@reduxjs/toolkit";
import {
  ADD_COMPLAINT_FAILED,
  ADD_COMPLAINT_REQUEST,
  ADD_COMPLAINT_SUCCESS,
  LIST_COMPLAINT_FAILED,
  LIST_COMPLAINT_REQUEST,
  LIST_COMPLAINT_SUCCESS,
  RECENT_LIST_COMPLAINT_FAILED,
  RECENT_LIST_COMPLAINT_REQUEST,
  RECENT_LIST_COMPLAINT_SUCCESS,
  UPDATE_COMPLAINT_FAILED,
  UPDATE_COMPLAINT_REQUEST,
  UPDATE_COMPLAINT_SUCCESS,
  VIEW_COMPLAINT_FAILED,
  VIEW_COMPLAINT_REQUEST,
  VIEW_COMPLAINT_SUCCESS,
} from "../constants/customerConstant";

export const addComplaintReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case ADD_COMPLAINT_REQUEST:
      return { loading: true };
    case ADD_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case ADD_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const listComplaintReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const recentListComplaintReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case RECENT_LIST_COMPLAINT_REQUEST:
      return { loading: true };
    case RECENT_LIST_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case RECENT_LIST_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const viewComplaintReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case VIEW_COMPLAINT_REQUEST:
      return { loading: true };
    case VIEW_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case VIEW_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};

export const updateComplaintReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case UPDATE_COMPLAINT_REQUEST:
      return { loading: true };
    case UPDATE_COMPLAINT_SUCCESS:
      return { loading: false, response: action.payload };
    case UPDATE_COMPLAINT_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};
