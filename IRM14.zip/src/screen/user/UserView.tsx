import React from "react";
import Header from "../../components/layouts/Header";
import { Box, Typography } from "@mui/material";

import Drawer from "@mui/material/Drawer";
import AppBar from "@mui/material/AppBar";
import CssBaseline from "@mui/material/CssBaseline";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";

import Divider from "@mui/material/Divider";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import LogoutIcon from "@mui/icons-material/Logout";
import HomeIcon from "@mui/icons-material/Home";
import SettingsIcon from "@mui/icons-material/Settings";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";

const headTypo={fontFamily:"Nunito",fontSize:"1.8rem",fontWeight:500}

const UserView = () => {
  const iconList = [
    { name: "home", id: 0 },
    { name: "settings", id: 1 },
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "home":
        return <HomeIcon />;
      case "settings":
        return <SettingsIcon />;

      default:
        return null;
    }
  };

  const drawerWidth = 220;
  return (
    <>
      <Header />
      <Grid container>
        <Grid item xs={1} md={2}>
          <Drawer
            variant="permanent"
            sx={{
              height: "100%",
              width: drawerWidth,
              flexShrink: 0,
              [`& .MuiDrawer-paper`]: {
                width: drawerWidth,
                boxSizing: "border-box",
              },
            }}>
            <Toolbar />
            <Box sx={{ mt: 2, overflow: "auto" }}>
              <List>
                {["Account", "settings"].map((text, index) => (
                  <ListItem key={text} disablePadding>
                    <ListItemButton>
                      <ListItemIcon>
                        {iconList
                          .filter(function (ico) {
                            return ico.id == index;
                          })
                          .map(function (icon) {
                            return getIcon(icon.name);
                          })}
                      </ListItemIcon>
                      <ListItemText primary={text} />
                    </ListItemButton>
                  </ListItem>
                ))}
              </List>
              <Divider />
              <List>
                <ListItem key="logout" disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      <LogoutIcon />
                    </ListItemIcon>
                    <ListItemText primary="Log out" />
                  </ListItemButton>
                </ListItem>
              </List>
            </Box>
          </Drawer>
        </Grid>

        <Grid item xs={1} md={10}>
          <Box component="div" sx={{ width: "100%" }}>
            <Typography
              variant="h4"
              sx={{ fontFamily: "Inter", fontWeight: "500" }}>
              Customer Queries
            </Typography>
<Box component="div" sx={{mr:4}}>

<Box
              component="div"
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-around",
                alignItems: "center",
                flexWrap: "wrap",
                m: 4,
               
              }}>
              <Card
                sx={{
                  minWidth: 290,
                  boxShadow: "12px 12px 2px 1px #0A2647",
                  borderStyle: "solid",
                  borderRadius: "15px",
                }}>
                <CardContent>
                  <Typography sx={{...headTypo}}>Current Customers</Typography>
                  <Typography>5698</Typography>
                </CardContent>
              </Card>

              <Card
                sx={{
                  minWidth: 290,
                  boxShadow: "12px 12px 2px 1px #0A2647",
                  borderStyle: "solid",
                  borderRadius: "15px",
                }}>
                <CardContent>
                  <Typography sx={{...headTypo}}>Completed Complaints</Typography>
                  <Typography>1364</Typography>
                </CardContent>
              </Card>

              <Card
                sx={{
                  minWidth: 290,
                  boxShadow: "12px 12px 2px 1px #0A2647",
                  borderStyle: "solid",
                  borderRadius: "15px",
                }}>
                <CardContent>
                  <Typography sx={{...headTypo}}>Pending Complaints</Typography>
                  <Typography>4532</Typography>
                </CardContent>
              </Card>
            </Box>

</Box>
           
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default UserView;
