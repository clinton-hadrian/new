import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import TextField from '@mui/material/TextField';

interface ExpandMoreProps extends IconButtonProps {
    expand: boolean;
  }
  
  const ExpandMore = styled((props: ExpandMoreProps) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginRight: 'auto',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
  }));
  

   
const ViewComplaint = () => {

    const [expanded, setExpanded] = React.useState(false);
  
    const handleExpandClick = () => {
      setExpanded(!expanded);
    };

 
    return (
      <Card sx={{ maxWidth: "100%", overflow:"auto" }}>
        <CardHeader
          avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
              A
            </Avatar>
          }
          action={
            <IconButton aria-label="settings">
              <MoreVertIcon />
            </IconButton>
          }
          title={<b>Shareholder Ajay</b>}
          subheader="Posted on September 14, 2016 - 12:39"
        />
        
        <CardContent>
        <Typography gutterBottom variant="h5" component="div" sx={{fontFamily:"Inter",fontWeight:"500"}}>
          Shares held on 
          <Typography variant='h5' sx={{fontFamily:"Inter",fontWeight:"200"}}>
            S3 Companies
          </Typography>
        </Typography>

        <Typography gutterBottom variant="h5" component="div" sx={{fontFamily:"Inter",fontWeight:"500"}}>
          Folio Number 
          <Typography variant='h5' sx={{fontFamily:"Inter",fontWeight:"200"}}>
            23940583
          </Typography>
          </Typography>

          <Typography gutterBottom variant="h5" component="div" sx={{fontFamily:"Inter",fontWeight:"500"}}>
          Type of query
          <Typography variant='h5' sx={{fontFamily:"Inter",fontWeight:"200"}}>
            IEPF Claim
          </Typography>
        </Typography>

        <Typography gutterBottom variant="h5" component="div" sx={{fontFamily:"Inter",fontWeight:"500"}}>
          Complaint
          <Typography variant='h6' sx={{fontFamily:"Inter",fontWeight:"200",fontSize:"8"}}>
          Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 
          </Typography>
        </Typography>

        </CardContent>
        <CardActions disableSpacing>
          <Typography sx={{fontWeight:"bold"}}>Comments</Typography>
          <ExpandMore
            expand={expanded}
            onClick={handleExpandClick}
            aria-expanded={expanded}
            aria-label="show more" 
            >  

            <ExpandMoreIcon  />

          </ExpandMore>
        </CardActions>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <CardContent>
            <Typography sx={{fontWeight:"bold"}}>Savitha (Support)</Typography>
            <Typography paragraph>
             Hi sir, your query has been solved.
            </Typography>
          <TextField sx={{width:"40%"}} variant="standard" placeholder='Type here' label="Comment" ></TextField>
          </CardContent>
        </Collapse>
      </Card>
  )
}

export default ViewComplaint
