import { AirTwoTone } from "@mui/icons-material";
import { AnyAction } from "@reduxjs/toolkit";
import { OTP_FAILED, OTP_REQUEST, OTP_SUCCESS } from "../constants/OTPConstant";


export const OTPReducer=(state={},action:AnyAction)=>{
    switch(action.type){
        case OTP_REQUEST:
            return {loading:true}
            case OTP_SUCCESS:
                return {loading:false,response:action.payload}
                case OTP_FAILED:
                    return {loading:false,response:action.payload}
                    default:
                        return state;
    }
}