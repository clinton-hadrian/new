import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { sendMobileOTPReducer } from "./reducers/authReducer";
import { userLoginReducer } from "./reducers/complaintReducer";
import { OTPReducer } from "./reducers/OTPReducer";
//import darkReducer from "./reducers/dark";
import { changeThemeReducer } from "./reducers/themeReducer";

const rootReducer = combineReducers({
  theme: changeThemeReducer,
  sendMobileOTP : sendMobileOTPReducer,
  userLogin: userLoginReducer,
  OTP:OTPReducer
});


const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
});


const themeValue = localStorage.getItem("theme")
  ? localStorage.getItem("theme")
  : "light";
const initialReducer = {
  theme: { mode: themeValue },
};






export default store;
