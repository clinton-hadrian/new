import React, { Fragment } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./screen/customer/Login";
import { createTheme, CssBaseline, ThemeProvider } from "@mui/material";
import IndexLayout from "./components/layouts/IndexLayout";
import UserLogin from "./screen/user/UserLogin";
import CustomerLayout from "./components/layouts/CustomerLayout";
import Complaint from "./screen/customer/Complaint";
import MiniDrawer from "./screen/customer/Cus/customerComplaint";
import AddProfile from "./components/AddProfile";
import UserView from "./screen/user/UserView";
import { Provider } from "react-redux";
import { useSelector } from "react-redux";
import store from "./store";

// export const useStyles = makeStyles({
//   root: {
//     display: "flex",
//     justifyContent: "center",
//   },
//   textField: {
//     width: "20%",
//     margin: "0 5px",
//   },
// });

function ThemeToggler() {
  const theme = useSelector((state: any) => state.theme);

  return (
    <ThemeProvider
      theme={createTheme({
        palette: {
          mode: theme.mode === "dark" ? "dark" : "light",
          primary: {
            main: "#0A2647",
            light: "#144272",
          },
          secondary: {
            main: "#205295",
            light: "##2C74B3",
          },
        },
      })}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="" element={<IndexLayout />}>
            <Route path="" element={<Login />} />
          </Route>

          <Route path="/user" element={<IndexLayout />}>
            <Route path="/user" element={<UserLogin />} />
          </Route>

          <Route path="/query" element={<CustomerLayout />}>
            <Route path="/query" element={<Complaint />} />
          </Route>

          <Route path="/new" element={<MiniDrawer />} />
          <Route
            path="/profile"
            element={<AddProfile open={true} handleClose={() => {}} />}
          />

          <Route path="/uview" element={<UserView />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

function App() {
  return (
    <Fragment>
      <Provider store={store}>
        <ThemeToggler />
      </Provider>
    </Fragment>
  );
}

export default App;
