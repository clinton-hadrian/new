import axios from "axios"
import { OTP_FAILED, OTP_REQUEST, OTP_SUCCESS } from "../constants/OTPConstant"
import { API } from "../data"


export const OTPAction=(otp:any)=>async(dispatch:any)=>{
    try{
        dispatch({
            type:OTP_REQUEST
        })

        const {data}=await axios.post(`${API}/Auth/OTPVerification`,
        otp,
       { headers:{"Content-Type":"application/json"}},)

       dispatch({
        type:OTP_SUCCESS,
        payload:data
       })
       console.log('====================================');
       console.log(data);
       console.log('====================================');
    }catch(error){
        dispatch({
            type:OTP_FAILED,
            payload:error
        })
    }
    
}