import React, { Fragment, useState, useEffect, Dispatch } from "react";
import { useNavigate } from "react-router-dom";
import OtpInput from "react18-input-otp";
import {
  Button,
  Box,
  Typography,
  CardContent,
  TextField,
  Paper,
  Grid,
  InputAdornment,
  Snackbar,
} from "@mui/material";

import * as Yup from "yup";
import phone from "yup-phone";
import { ErrorMessage, useFormik } from "formik";
import DialpadOutlinedIcon from "@mui/icons-material/DialpadOutlined";
import { useDispatch, useSelector } from "react-redux";
import { sendMobileOTPAction } from "../../actions/authAction";
import LoadingButton from "@mui/lab/LoadingButton";
import SnackbarContent from "@mui/material/SnackbarContent";
import {
  HANDLE_CLOSE,
  SEND_MOBILE_OTP_SUCCESS,
} from "../../constants/authConstant";
import {} from "../../reducers/authReducer";
import MuiAlert, { AlertProps } from "@mui/material/Alert";
import { OTPAction } from "../../actions/OTPAction";

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

interface props {
  mobile: string;
  otp: string;
}

const otpBorder = {
  width: "20%",
  margin: "0 5px",
  borderRadius: "15px",
  borderColor: "#a084dc",
  borderStyle: "solid",
  borderWidth: "2px",
  max: "9",
  min: "0",
  textAlign: "center",
};

const Login = () => {
  const dispatch: Dispatch<any> = useDispatch();
  const otpStatus=useSelector((state:any)=>state.OTP)
  const navigate = useNavigate();
  function handleClick() {
    if(otpStatus.response)
    {
      navigate("/query");

    }
  }

  const status = useSelector((state: any) => state.sendMobileOTP);

  const [otpVisible, setOTPVisible] = useState<Boolean>(false);
  const [otpError, setOTPError] = useState<string>("");
  const [numberAndEmail, setNumberAndEmail] = useState<props>({
    mobile: "",
    otp: "",
  });

  const [code, setCode] = useState("");


  // const handleChange = (code: any) => {
  //   setCode(code);
  //   mobileFormik.values.otp = code;
  // };

  const mobileFormik = useFormik({
    initialValues: {
      mobile: "",
 
    },
    validationSchema: Yup.object().shape({
      mobile: Yup.string().required("Please enter the mobile number"),
    }),

    onSubmit: (value) => {
      console.log(value);
      dispatch(sendMobileOTPAction(value));

      
    },
  });

  if (status.response && !otpVisible) {
    setOTPVisible(true);
  }
 
  useEffect(() => {}, [otpVisible]);
 

  const otpFormik = useFormik({
    initialValues: {
      otp: "",
    },
  validationSchema: Yup.object().shape({
    otp: Yup.string().required("OTP is required"),
  }),

    onSubmit: (value) => {
      console.log(value);

      dispatch(OTPAction(value))
    },
  });

  const handleClose = () => dispatch({ type: HANDLE_CLOSE });

  return (
    <Fragment>
      {status.showSnackbar && (
        <Snackbar
          onClose={handleClose}
          autoHideDuration={3000}
          open={status.open}>
          <Alert severity={status.severity}>{status.message}</Alert>
        </Snackbar>
      )}

      <Paper
        style={{
          borderRadius: "20px",
          borderColor: "black",
          borderStyle: "Solid",
          borderWidth: "2px",
        }}
        elevation={20}
        sx={{ p: 2 }}>
        <CardContent sx={{ textAlign: "center" }}>
          {!otpVisible && (
            <Box
              sx={{
                "& .MuitTextField-root": {
                  margin: 1,
                  width: "100%",
                },
              }}>
              <Typography
                style={{
                  fontFamily: "Nunito",
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom>
                SIGN IN
              </Typography>

              <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <DialpadOutlinedIcon sx={{ mr: 2 }} />
                    </InputAdornment>
                  ),
                }}
                // startIcon={<DialpadOutlinedIcon />}
                id="mobile"
                value={mobileFormik.values.mobile}
                name="mobile"
                onBlur={mobileFormik.handleBlur}
                onChange={(e) => {
                  mobileFormik.setFieldValue("mobile", e.target.value);
                }}
                placeholder="Enter mobile number"
                fullWidth
                error={Boolean(
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                )}
                helperText={
                  mobileFormik.touched.mobile && mobileFormik.errors.mobile
                }
                label="Mobile Number"
              />

              <LoadingButton
                loading={status.loading}
                sx={{ mt: 2, borderRadius: "10px" }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  mobileFormik.handleSubmit();
                }}>
                GET OTP
              </LoadingButton>
            </Box>
          )}

          {/* <MuiOtpInput 
           length={6}
            value={otpFormik.values.otp}
             onChange={(e)=>{otpFormik.setFieldValue("otp",e.target.value)}} 
             error={Boolean(otpFormik.touched.otp && otpFormik.errors.otp)}
             onBlur={otpFormik.handleBlur}
             helperText={otpFormik.touched.otp && otpFormik.errors.otp}
             
             /> */}
          {otpVisible && (
            <Box
              sx={{
                display: "flex",
                margin: 1,
                width: "100%",
                textAlign: "center",
                alignContent: "center",
                alignItems: "center",
                justifyContent: "center",
                alignSelf: "center",
                flexDirection: "column",
                flexWrap: "wrap",
              }}>
              <Typography
                style={{
                  fontFamily: "Nunito",
                  fontSize: "1.8rem",
                  fontWeight: "bold",
                }}
                variant="h5"
                gutterBottom>
                Enter OTP
              </Typography>
              <OtpInput
                inputStyle={{
                  border: "3px solid ",
                  borderRadius: "8px",
                  width: "40.5px",
                  height: "40px",
                  fontSize: "20px",
                  color: "#090752",
                  fontWeight: "bold",
                  caretColor: "blue",
                  margin: 4,
                }}
                inputProps={{ name: "otp", readOnly: false  }}
                numInputs={6}
                separator={<span style={{ width: "8px" }}></span>}
                isInputNum={true}
                shouldAutoFocus={true}
                value={otpFormik.values.otp}
                //  onChange={()=>{otpFormik.setFieldValue("otp",otpFormik.values.otp)}}
                onChange={(value:number) => {
                  otpFormik.setFieldValue("otp", value);
                }}
                hasErrored={Boolean(
                  otpFormik.touched.otp && otpFormik.errors.otp
                )}
                errorStyle="error"
                focusStyle={{
                  border: "1px solid #090752",
                  outline: "none",
                }}
                // helperText={otpFormik.touched.otp && otpFormik.errors.otp}
              />

              <Button
                style={{
                  fontFamily: "Inter",
                  fontSize: "1rem",
                  fontWeight: "bold",
                }}
                sx={{ mt: 2 }}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                color="primary"
                onClick={() => {
                  setOTPVisible(true);
                  handleClick();
                  otpFormik.handleSubmit();
                }}>
                VERIFY
              </Button>
            </Box>
          )}

          {/* {touched && error && <div className="error">{error}</div>} */}
        </CardContent>
      </Paper>
    </Fragment>
  );
};
export default Login;
