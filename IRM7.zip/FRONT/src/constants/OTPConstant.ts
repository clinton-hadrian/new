export const OTP_REQUEST="OTP_REQUEST";
export const OTP_SUCCESS="OTP_SUCCESS";
export const OTP_FAILED="OTP_FAILED";