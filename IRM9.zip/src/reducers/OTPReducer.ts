import { AirTwoTone } from "@mui/icons-material";
import { AnyAction } from "@reduxjs/toolkit";
import { VERIFY_MOBILE_OTP_FAILED, VERIFY_MOBILE_OTP_REQUEST, VERIFY_MOBILE_OTP_SUCCESS } from "../constants/authConstant";import { persistStore, persistReducer } from 'redux-persist';
import sessionStorage from 'redux-persist/lib/storage/session';



export const OTPReducer = (state = {}, action: AnyAction) => {

  switch (action.type) {
    case VERIFY_MOBILE_OTP_REQUEST:
      return { loading: true };
    case VERIFY_MOBILE_OTP_SUCCESS:
      return { loading: false, response: action.payload,  };
    //   case LOGOUT:
    //     return {loading:false, response:action.payload, }
    case VERIFY_MOBILE_OTP_FAILED:
      return { loading: false, error: action.payload };
    default:
      return state;
  }
};
