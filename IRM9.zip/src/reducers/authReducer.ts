import { AnyAction } from "@reduxjs/toolkit";
import React from "react";
import { useDispatch } from "react-redux";
import {
  SEND_MOBILE_OTP_FAILED,
  SEND_MOBILE_OTP_REQUEST,
  SEND_MOBILE_OTP_SUCCESS
} from "../constants/authConstant";

export const sendMobileOTPReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case SEND_MOBILE_OTP_REQUEST:
      return { loading: true };

    case SEND_MOBILE_OTP_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case SEND_MOBILE_OTP_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};
