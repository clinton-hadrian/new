import { AnyAction } from "@reduxjs/toolkit";
import React from "react";
import { useDispatch } from "react-redux";
import {
    ADD_PROFILE_REQUEST,
    ADD_PROFILE_SUCCESS,
    ADD_PROFILE_FAILED
} from "../constants/authConstant";

export const addProfileReducer = (state = {}, action: AnyAction) => {
  switch (action.type) {
    case ADD_PROFILE_REQUEST:
      return { loading: true };

    case ADD_PROFILE_SUCCESS:
      return {
        loading: false,
        response: action.payload,
      };

    case ADD_PROFILE_FAILED:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};
