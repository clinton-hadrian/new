import React, { useState, useEffect } from 'react';
import {Typography } from "@mui/material";

const Countdown = () => {
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [text,setText]=useState("Code will expire in")
  const [isCountdownActive, setIsCountdownActive] = useState(true);
  let intervalId: number | undefined;

  useEffect(() => {
    if (isCountdownActive) {
      intervalId = window.setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            setText("Code has expired");
            clearInterval(intervalId);
            setIsCountdownActive(false);
            return;
          }
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    }
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
       
      }
    };
  }, [minutes, seconds, isCountdownActive]);

  return (
    <>
    <Typography variant="h6" sx={{fontFamily:"inter",fontWeight:"400"}}>{text}</Typography>
    <div>
      {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
    </div>
    </>
    
  );
};

export default Countdown;