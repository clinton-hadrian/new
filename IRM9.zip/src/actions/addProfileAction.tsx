import axios from "axios";
import { AnyAction, Dispatch } from "redux";
import {
    ADD_PROFILE_REQUEST,
    ADD_PROFILE_SUCCESS,
    ADD_PROFILE_FAILED
} from "../constants/authConstant";
import { API } from "../data";

export const addProfileAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: ADD_PROFILE_REQUEST,    
    });
    const { data } = await axios.post(`${API}/Auth/addProfile`, form, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    dispatch({
      type: ADD_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error: any) {
    dispatch({
      type: ADD_PROFILE_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.mesaage,
    });
  }
};
