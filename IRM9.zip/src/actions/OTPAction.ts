import axios from "axios";
import { VERIFY_MOBILE_OTP_FAILED, VERIFY_MOBILE_OTP_REQUEST, VERIFY_MOBILE_OTP_SUCCESS } from "../constants/authConstant";
import { API } from "../data";

export const OTPAction = (form: any) => async (dispatch: any) => {
  try {
    dispatch({
      type: VERIFY_MOBILE_OTP_REQUEST,
    });

    const { data } = await axios.post(`${API}/Auth/OTPVerification`, form, {
      headers: { "Content-Type": "application/json" },
    });

    dispatch({
      type: VERIFY_MOBILE_OTP_SUCCESS,
      payload: data,
    });

  } catch (error: any) {
    dispatch({
      type: VERIFY_MOBILE_OTP_FAILED,
      payload:
        error && error.response && error.response.data
          ? error.response.data
          : error && error.message,
    });
  }
};
