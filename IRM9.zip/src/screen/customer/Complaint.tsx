import { ErrorMessage, Formik, useFormik } from "formik";
import React, { Fragment, useState, useRef } from "react";
import * as Yup from "yup";

import {
  Button,
  Fab,
  Card,
  
  TabScrollButton,
  Box,
  CardContent,
  Checkbox,
  Divider,
  FormControlLabel,
  FormHelperText,
  Grid,
  Autocomplete,
  MenuItem,
  Link,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  Typography,
  TextField,
} from "@mui/material";
import AddProfile from "../../components/AddProfile";
import Header from "../../components/layouts/Header";
import ViewComplaint from "../../components/ViewComplaint";
import ListComplaint from "../../components/ListComplaint";
import { Add, AnalyticsOutlined } from "@mui/icons-material";
import ComplaintsList from "../../components/ComplaintsList";
import AddComplaint from "../../components/AddComplaint";
import { useSelector } from "react-redux";



const Complaint = () => {

  const AddProfileSelector=useSelector((state:any)=>state.addProfile)


  const [addProfile, setAddProfile] = useState(true);

  const [open,setOpen]=useState("add");

  function toggle(name:string){
    if(name=="complaint"){
      setOpen("complaint")
    }
    else if(name=="view"){
      setOpen("view")
    }
else if(name=="add")
{
  setOpen("add")

}
    

  }

  return (
    <>
      <Box
        sx={{
          position: "inline-flex",
          direction: "row",
          marginX: 1,
          marginY: 1,
          overflow: "auto",
          justifyContent: "center",
          p: 1,
          filter:addProfile?"blur(8px)":"",
          transition: "filter 0.8s ease-out",
          
        }}
        style={{}}>
        <AddProfile
          open={addProfile}
          handleClose={() => {
            if(AddProfileSelector.response){
              setAddProfile(false)
            }
            setAddProfile(false);
          }}
        />
        <Grid container>
          <Grid item xs={12} md={8}>
            <Box
            className="scrol"
              sx={{
                display: "flex",
                direction: "row",
                p: 2,
                mr: 0,
                overflow: "auto",
                maxHeight: "100vh",
               
              }}>
            
             {open=="add" && <AddComplaint customerName="Ajay" />}
             {open=="view" && <ComplaintsList onClick={toggle}  />}
             {open=="complaint" && <ViewComplaint  />}
             
            </Box>
          </Grid>

          <Grid
            sx={{ borderLeft: "solid", borderWidth: "1px" }}
            item
            xs={12}
            md={4}>
            <Box
              className="scroll"
              sx={{
                display: "flex",
                flex: 1,
                direction: "row",
                justifyContent: "center",
                p: 1,
                ml: 2,
                overflow: "hidden",
                maxHeight: "100vh",
                
              }}>
             <ListComplaint  onClick={toggle} />
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box visibility={open!=="add"?"visible":"hidden"} onClick={()=>{setOpen("add")}} sx={{ bottom: 10, right: 15, position: "fixed" }}>
        <Fab name="add"  color="secondary">
          <Add />
        </Fab>
      </Box>
    </>
  );
};

export default Complaint;
